//import 'package:appspector/appspector.dart';
import 'package:clap/src/app.dart';
import 'package:clap/src/utils/clap_cubit_observer.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:hydrated_bloc/hydrated_bloc.dart';
import 'dart:io';

void main() async {
  HttpOverrides.global = MyHttpOverrides();
  WidgetsFlutterBinding.ensureInitialized();
  HydratedBloc.storage = await HydratedStorage.build();
  Bloc.observer = ClapCubitObserver();
  await Firebase.initializeApp();
  //runAppSpector();
  SystemChrome.setPreferredOrientations(
      [DeviceOrientation.portraitUp,DeviceOrientation.portraitDown])
      .then((_) => runApp(App()),
  );
  //runApp(App());
}

class MyHttpOverrides extends HttpOverrides{
  @override
  HttpClient createHttpClient(SecurityContext context){
    return super.createHttpClient(context)
      ..badCertificateCallback = (X509Certificate cert, String host, int port)=> true;
  }
}

/*

void runAppSpector() {
  final config = Config()
    ..iosApiKey = "android_NzNiMDBjNmItOWI3NS00N2ZkLTkzMTMtNzBmZjI5MzUzYzhl"
    ..androidApiKey = "android_NzNiMDBjNmItOWI3NS00N2ZkLTkzMTMtNzBmZjI5MzUzYzhl";

  // If you don't want to start all monitors you can specify a list of necessary ones
  config.monitors = [Monitors.http, Monitors.logs, Monitors.screenshot];

  AppSpectorPlugin.run(config);
}*/
