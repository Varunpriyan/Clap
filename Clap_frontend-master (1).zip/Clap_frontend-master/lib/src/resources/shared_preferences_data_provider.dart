import 'dart:convert';

import 'package:clap/src/models/celebrity.dart';
import 'package:meta/meta.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SharedPreferencesDataProvider {
  static const String TOKEN = 'authorization_token';
  static const String SKIP = 'is_skipped_login';
  static const String CELEBRITY = 'celebrity';
  static const String ACTION_TYPE = 'type';
  static const String USER_ID = 'user_id';
  static const String USER_NAME = 'user_name';
  static const String USER_MOBILE = 'user_mobile';
  static const String USER_MAIL = 'user_mail';
  static const String USER_TYPE = 'user_type';
  static const String USER_PHOTO = 'user_location_name';
  static const String USER_LOCATION_ID = 'user_location_id';

  Future<bool> saveSkipLoginStatus({@required bool status}) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setBool(SKIP, status);
    return true;
  }

  Future<bool> getSkipLoginStatus() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    bool status = prefs.getBool(SKIP) ?? false;
    return status;
  }


  Future<bool> saveActionStateCelebrity({@required Celebrity celebrity}) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString(CELEBRITY, jsonEncode(celebrity));
    return true;
  }

  Future<Celebrity> getActionStateCelebrity() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String jsonData = prefs.getString(CELEBRITY);
    print(jsonData!="null");
    Celebrity celebrity = jsonData==null||jsonData=="null" ? null : Celebrity.fromJson(json.decode(prefs.getString(CELEBRITY))) ;
    print(celebrity.toString());
    return celebrity;
  }

  Future<bool> saveActionType({@required String type}) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString(ACTION_TYPE, type);
    return true;
  }

  Future<String> getActionType() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String type = prefs.getString(ACTION_TYPE) ?? '';
    return type;
  }




  
  
///////////////////////////////////////////////////////////////
  Future<bool> saveAccessToken({@required String accessToken}) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString(TOKEN, accessToken);
    return true;
  }

  Future<String> getAccessToken() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String accessToken = prefs.getString(TOKEN) ?? '';
    return accessToken;
  }

  Future<bool> saveUserId(int id) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setInt(USER_ID, id);
    return true;
  }

  Future<int> getUserId() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    int id = prefs.getInt(USER_ID) ?? 0;
    return id;
  }

  Future<bool> saveUserName(String name) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString(USER_NAME, name);
    return true;
  }

  Future<String> getUserName() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String name = prefs.getString(USER_NAME) ?? '';
    return name;
  }

  Future<bool> saveUserMobile(String mobile) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString(USER_MOBILE, mobile);
    return true;
  }

  Future<String> getUserMobile() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String mobile = prefs.getString(USER_MOBILE) ?? '';
    return mobile;
  }

  Future<bool> saveUserMail(String mail) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString(USER_MAIL, mail);
    return true;
  }

  Future<String> getUserMail() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String mail = prefs.getString(USER_MAIL) ?? '';
    return mail;
  }
  Future<bool> saveUserProfileImage(String mail) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString(USER_PHOTO, mail);
    return true;
  }

  Future<String> getUserProfileImage() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String mail = prefs.getString(USER_PHOTO) ?? '';
    return mail;
  }
  Future<bool> saveUserLocationId(int locationId) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setInt(USER_LOCATION_ID, locationId);
    return true;
  }

  Future<int> getUserLocationId() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    int locationId = prefs.getInt(USER_LOCATION_ID) ?? 0;
    return locationId;
  }
}
