import 'dart:ffi';

import 'package:clap/src/models/analytics_response.dart';
import 'package:clap/src/models/ask_question.dart';
import 'package:clap/src/models/audition_response.dart';
import 'package:clap/src/models/categories_response.dart';
import 'package:clap/src/models/celebrity.dart';
import 'package:clap/src/models/celebrity_list_response.dart';
import 'package:clap/src/models/make_wish_response.dart';
import 'package:clap/src/models/models.dart';
import 'package:clap/src/models/occasion_response.dart';
import 'package:clap/src/models/order.dart';
import 'package:clap/src/models/payment.dart';
import 'package:clap/src/models/profile_response.dart';
import 'package:clap/src/models/search_response.dart';
import 'package:clap/src/models/success.dart';
import 'package:firebase_auth/firebase_auth.dart' as fireBaseAuth;
import 'api_provider.dart';
import 'firebase_auth_service.dart';
import 'shared_preferences_data_provider.dart';
import 'package:clap/src/models/portfolio_upload_response.dart';
import 'package:clap/src/models/audition_apply_response.dart';
import 'package:clap/src/models/applied_auditions_response.dart';
import 'dart:io';
class Repository {
  final FirebaseAuthService _firebaseAuthService = FirebaseAuthService();
  final _sharedPreferenceProvider = SharedPreferencesDataProvider();
  final _apiProviderProfile = ApiProvider();

  ///Firebase Services
  verifyFirebasePhone(String mobile,
      {PhoneVerificationCompleted verificationCompleted,
        PhoneCodeSent codeSent}) =>
      _firebaseAuthService.verifyPhone(
          mobile: mobile,
          verificationCompleted: verificationCompleted,
          codeSent: codeSent);

  verifyFirebaseOtp(String verificationId, String otp,
      {PhoneVerificationCompleted verificationCompleted}) =>
      _firebaseAuthService.verifyOtp(verificationId, otp,
          verificationCompleted: verificationCompleted);

  Future<String> getFirebaseToken() => _firebaseAuthService.getFirebaseToken();
  Future<void> logoutFromFirebase() => _firebaseAuthService.logout();

  ///Shared Preferences
  Future<bool> saveSkipLoginStatus(bool status) =>
      _sharedPreferenceProvider.saveSkipLoginStatus(status: status);
  
  Future<bool> getSkipLoginStatus() => _sharedPreferenceProvider.getSkipLoginStatus();

  ///// save action state if not logged in
  
  Future<bool> saveActionStateCelebrity(Celebrity celebrity) =>
      _sharedPreferenceProvider.saveActionStateCelebrity(celebrity: celebrity);

  Future<Celebrity> getActionStateCelebrity() => _sharedPreferenceProvider.getActionStateCelebrity();

  Future<bool> saveActionType(String type) =>
      _sharedPreferenceProvider.saveActionType(type: type);

  Future<String> getActionType() => _sharedPreferenceProvider.getActionType();


  ////////////////////////////


  
  Future<bool> saveAccessToken(String accessToken) =>
      _sharedPreferenceProvider.saveAccessToken(accessToken: accessToken);

  Future<String> getAccessToken() => _sharedPreferenceProvider.getAccessToken();


  Future<bool> saveUserName(String name) =>
      _sharedPreferenceProvider.saveUserName(name);

  Future<String> getUserName() => _sharedPreferenceProvider.getUserName();

  Future<bool> saveUserMobile(String mobile) =>
      _sharedPreferenceProvider.saveUserMobile(mobile);

  Future<String> getUserMobile() => _sharedPreferenceProvider.getUserMobile();

  Future<bool> saveUserMail(String mail) =>
      _sharedPreferenceProvider.saveUserMail(mail);

  Future<String> getUserMail() => _sharedPreferenceProvider.getUserMail();

  Future<bool> saveUserProfileImage(String photoUrl) =>
      _sharedPreferenceProvider.saveUserProfileImage(photoUrl);

  Future<String> getUserProfileImage() => _sharedPreferenceProvider.getUserProfileImage();


  Future<void> saveUser(fireBaseAuth.User user) async {
    String token =  await user.getIdToken();
    print(token);
    saveUserName(user.displayName);
    saveAccessToken(token);
    saveUserMobile(user.phoneNumber);
    saveUserMail(user.email);
    saveUserProfileImage(user.photoURL);
    saveSkipLoginStatus(false);
  }

  Future<void> saveUserFromProfile(Profile profile) async {
    saveUserName(profile.displayName);
    saveUserMobile(profile.phoneNumber);
    saveUserMail(profile.email);
    saveUserProfileImage(profile.profile);
  }

  Future<Profile> getUserFromCache() async {
    Profile profile = Profile();
    profile.displayName = await getUserName();
    profile.phoneNumber = await getUserMobile();
    profile.email = await getUserMail();
    profile.profile = await getUserProfileImage();
    return profile;
  }


  Future<void> logoutUser() async {
    saveUserName(null);
    saveAccessToken(null);
    saveUserMobile(null);
    saveUserMail(null);
    saveUserProfileImage(null);
  }



  Future<Profile> getUser() async {
    String token = await getFirebaseToken();
    return _apiProviderProfile.getUser(token: token);
  }

  Future<bool> checkPhoneNUmber(String mobile) async {
    return _apiProviderProfile.checkPhoneNUmber(mobile:mobile);
  }

  Future<Profile> updateProfile(
      {String name, String email,int age,String gender,String height,String weight,String complexion,String hairColor,String aboutMe,bool isCreate = false}) async {
    String token = await getFirebaseToken();
    return _apiProviderProfile.updateProfile(
        token: token, name: name, email: email,age: age,gender: gender,height: height,weight: weight,complexion: complexion,hairColor: hairColor,aboutMe: aboutMe,isCreate: isCreate);
  }

  Future<Profile> updateProfilePicture(
      {String path}) async {
    String token = await getFirebaseToken();
    return _apiProviderProfile.updateProfilePicture(
        token: token, filePath: path);
  }

  Future<CategoriesResponse> getCategories() async {
    //String token = await getFirebaseToken();
    return _apiProviderProfile.getCategories();
  }

  Future<CelebrityListResponse> getCelebritiesInCategory({Category category,int offset}) async {
   // String token = await getFirebaseToken();
    return _apiProviderProfile.getCelebritiesInCategory(/*token: token,*/category:category,offset: offset);
  }

  Future<Celebrity> getCelebrityDetail(Celebrity celebrity) async {
   // String token = await getFirebaseToken();
    return _apiProviderProfile.getCelebrityDetail(/*token: token,*/celebrity:celebrity);
  }


  Future<PaymentResponse> updatePayment(
      {int orderId, String paymentId, String paymentStatus,String amount}) async {
    String token = await getFirebaseToken();
    return _apiProviderProfile.updatePayment(
      token: token,
      orderId: orderId,
      paymentId: paymentId,
      paymentStatus: paymentStatus,
        amount:amount
    );
  }

  /////////// ask question

  Future<AskQuestionResponse> askQuestion(Celebrity celebrity,String question,String phone, String email,) async {
    String token = await getFirebaseToken();
    return _apiProviderProfile.askQuestion(token: token,celebrity:celebrity,question:question,phone:phone,email:email);
  }

  /////////// make Wish

  Future<MakeWishResponse> makeWish(MakeWish makeWish,String phone, String email,) async {
    String token = await getFirebaseToken();
    return _apiProviderProfile.makeWish(token: token,makeWish:makeWish,phone:phone,email:email);
  }

  ///////////  orders

  Future<OrderResponse> getAllOrders({int offset}) async {
    String token = await getFirebaseToken();
    return _apiProviderProfile.getAllOrders(token: token, offset: offset);
  }

  Future<Order> getOrderDetails(int order) async {
    String token = await getFirebaseToken();
    return _apiProviderProfile.getOrderDetails(token: token,order:order);
  }


  //////  occasions

  Future<OccasionResponse> getOccasions() async {
    String token = await getFirebaseToken();
    return _apiProviderProfile.getOccasions(token: token);
  }


  Future<SearchResponse> search({String query}) async {
    String token = await getFirebaseToken();
    return _apiProviderProfile.search(token: token,query:query);
  }


  // phase 2

  Future<PortfolioUploadResponse> addPortfolio(
      {List<File> files,Function onProgress}) async {
    String token = await getFirebaseToken();
    return _apiProviderProfile.addPortfolio(
        token: token, files: files,onProgress: onProgress);
  }


  Future<bool> deletePortfolio(
      {int id}) async {
    String token = await getFirebaseToken();
    return _apiProviderProfile.deletePortfolio(
        token: token, id: id);
  }


  Future<AuditionResponse> getAllAudition({int offset}) async {
    String token = await getFirebaseToken();
    return _apiProviderProfile.getAllAudition(token: token, offset: offset);
  }

  Future<Audition> getAuditionDetails(int audition) async {
    String token = await getFirebaseToken();
    return _apiProviderProfile.getAuditionDetails(token: token,audition:audition);
  }

  Future<AuditionApplyResponse> submitApplication(
      {List<String> path,int audition}) async {
    String token = await getFirebaseToken();
    return _apiProviderProfile.submitApplication(
        token: token, filePath: path,audition: audition);
  }


  Future<AppliedAuditionsResponse> getAppliedAuditions({int offset}) async {
    String token = await getFirebaseToken();
    return _apiProviderProfile.getAppliedAuditions(token: token, offset: offset);
  }


  Future<AnalyticsResponse> getAnalytics() async {
    String token = await getFirebaseToken();
    return _apiProviderProfile.getAnalytics(token: token);
  }

  Future<bool> deleteProfile() async {
    String token = await getFirebaseToken();
    return _apiProviderProfile.deleteProfile(
        token: token);
  }
}
