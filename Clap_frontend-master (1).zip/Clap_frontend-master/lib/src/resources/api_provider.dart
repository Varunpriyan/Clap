import 'dart:convert';
import 'package:clap/src/models/analytics_response.dart';
import 'package:clap/src/models/ask_question.dart';
import 'package:clap/src/models/audition_response.dart';
import 'package:clap/src/models/categories_response.dart';
import 'package:clap/src/models/celebrity.dart';
import 'package:clap/src/models/celebrity_list_response.dart';
import 'package:clap/src/models/make_wish_response.dart';
import 'package:clap/src/models/models.dart';
import 'package:clap/src/models/occasion_response.dart';
import 'package:clap/src/models/order.dart';
import 'package:clap/src/models/payment.dart';
import 'package:clap/src/models/profile_response.dart';
import 'package:clap/src/models/search_response.dart';
import 'package:clap/src/models/portfolio_upload_response.dart';
import 'package:clap/src/models/audition_apply_response.dart';
import 'package:clap/src/models/applied_auditions_response.dart';
import 'package:clap/src/utils/constants.dart';
import 'package:dio/dio.dart';
import 'package:http/http.dart' as http;
import 'dart:io';
import 'package:http_parser/http_parser.dart';

class ApiProvider {
  static const int SUCCESS = 200;
  static const int UNAUTHORIZED = 401;

  Map<String, String> header = {
    'Accept': 'application/json',
    'Content-Type': 'application/json',
  };

  Future<Profile> getUser({String token}) async {
    print("calling");
    header['Authorization'] = 'Bearer ' + token;
    final response = await http.get(Constants.USER, headers: header);
    print("calling");
    print(token);
    print(response.statusCode);
    print(response.body);
    if (response.statusCode == SUCCESS) {
      final responseString = jsonDecode(response.body);
      responseString['code'] = response.statusCode;
      return Profile.fromJson(responseString);
    } else {
      throw Exception('failed to load');
    }
  }

  Future<bool> checkPhoneNUmber({String mobile}) async {
    Map<String, dynamic> body = {
      'phone_number': mobile
    };
    final response = await http.post(Constants.CHECK_PHONE,
        headers: header, body: jsonEncode(body).toString());
    print(response.body);
    if (response.statusCode == SUCCESS||response.statusCode==404) {
      final responseString = jsonDecode(response.body);
      return responseString['status']==1 ? true : false;
    } else {
      throw Exception('failed to load');
    }
  }

  Future<Profile> updateProfile(
      {String token, String name, String email,int age,String gender,String height,String weight,String complexion,String hairColor,String aboutMe, bool isCreate=false}) async {
    header['Authorization'] = 'Bearer ' + token;
    Map<String, dynamic> body;
    if(isCreate){
       body = {
        'display_name': name,
        'email': email,
      };
    }else{
       body = {
        'display_name': name,
        'email': email,
        'age':age,
        'gender':gender,
        'height':height,
        'weight':weight,
        'location':complexion,
        'is_completed':true,
        'hair_colour':hairColor,
        'about_me':aboutMe
      };
    }

    final response = await http.put(Constants.UPDATE_PROFILE,
        headers: header, body: jsonEncode(body).toString());
    print(response.body);
    if (response.statusCode == SUCCESS) {
      final responseString = jsonDecode(response.body);
      responseString['code'] = response.statusCode;
      return Profile.fromJson(responseString);
    } else if (response.statusCode == 400) {
      final responseString = jsonDecode(response.body);
      responseString['code'] = response.statusCode;
      return Profile.fromJson(responseString);
    } else {
      throw Exception('failed to load');
    }
  }


  Future<Profile> updateProfilePicture({
    String token,
    String filePath,
  }) async {
    header['Authorization'] = 'Bearer ' + token;
    var request =
    http.MultipartRequest('PATCH', Uri.parse(Constants.UPDATE_PROFILE));
    request.headers.addAll(header);
      request.files
          .add(await http.MultipartFile.fromPath('profile', filePath));

    final response = await request.send();
    if (response.statusCode == SUCCESS) {
      var responseData = await response.stream.toBytes();
      var responseChar = String.fromCharCodes(responseData);
      var responseString = jsonDecode(responseChar);
      responseString['code'] = response.statusCode;
      return Profile.fromJson(responseString);
    } else {
      throw Exception('failed to load');
    }
  }

  Future<CategoriesResponse> getCategories(/*{String token}*/) async {
   // header['Authorization'] = 'Bearer ' + token;
    final response = await http.get(Constants.CATEGORIES, headers: header);
    print(response.body);
    if (response.statusCode == SUCCESS) {
      final responseString = jsonDecode(response.body);
      responseString['code'] = response.statusCode;
      return CategoriesResponse.fromJson(responseString);
    } else {
      throw Exception('failed to load');
    }
  }

  Future<CelebrityListResponse> getCelebritiesInCategory(
      {/*String token, */Category category, int offset = 0, int limit = 6}) async {
   // header['Authorization'] = 'Bearer ' + token;
    final response = await http.get(
        Constants.CELEBRITIES +
            "?category=" +
            category.id.toString() +
            "&limit=$limit&offset=$offset",
        headers: header);
    print(response.body);
    if (response.statusCode == SUCCESS) {
      final responseString = jsonDecode(response.body);
      responseString['code'] = response.statusCode;
      return CelebrityListResponse.fromJson(responseString);
    } else {
      throw Exception('failed to load');
    }
  }

  Future<Celebrity> getCelebrityDetail(
      {/*String token, */Celebrity celebrity}) async {
    //header['Authorization'] = 'Bearer ' + token;
    final response = await http.get(
        Constants.CELEBRITIES + celebrity.id.toString() + "/",
        headers: header);
    print(response.body);
    if (response.statusCode == SUCCESS) {
      final responseString = jsonDecode(response.body);
      responseString['code'] = response.statusCode;
      return Celebrity.fromJson(responseString);
    } else {
      throw Exception('failed to load');
    }
  }

  Future<PaymentResponse> updatePayment(
      {String token,
      int orderId,
      String paymentId,
      String paymentStatus,
      String amount}) async {
    header['Authorization'] = 'Bearer ' + token;
    Map<String, dynamic> body = {
      'order': orderId,
      'amount': amount,
    };
    final response = await http.post(Constants.UPDATE_PAYMENT,
        headers: header, body: jsonEncode(body).toString());
    print(response.body);
    print(response.statusCode);
    if (response.statusCode == 201||response.statusCode == 200) {
      final responseString = jsonDecode(response.body);
      responseString['code'] = response.statusCode;
      return PaymentResponse.fromJson(responseString);
    } else {
      throw Exception('failed to load');
    }
  }

  ////////// ask question

  Future<AskQuestionResponse> askQuestion(
      {String token, Celebrity celebrity, String question,String phone, String email,}) async {
    header['Authorization'] = 'Bearer ' + token;
    Map<String, dynamic> body = {
      'celebrity': celebrity.id,
      'question': question,
      'phone': phone,
      'email': email,
    };
    final response = await http.post(Constants.ASK_QUESTION,
        headers: header, body: jsonEncode(body).toString());
    print(response.body);
    if (response.statusCode == 201||response.statusCode == 200) {
      final responseString = jsonDecode(response.body);
      responseString['code'] = response.statusCode;
      return AskQuestionResponse.fromJson(responseString);
    } else {
      throw Exception('failed to load');
    }
  }


  ////////// make wish

  Future<MakeWishResponse> makeWish(
      {String token, MakeWish makeWish,String phone, String email,}) async {
    header['Authorization'] = 'Bearer ' + token;
    Map<String, dynamic> body = {
      'celebrity': makeWish.celebrity.id,
      'booking_for': makeWish.forWho,
      'occasions': makeWish.occasion.id,
      'indroduction': makeWish.introduction,
      'instruction': makeWish.instruction,
      'other_informations': makeWish.otherInfo,
      'phone': phone,
      'email': email,
    };
    final response = await http.post(Constants.MAKE_WISH,
        headers: header, body: jsonEncode(body).toString());
    print(response.body);
    if (response.statusCode == 201||response.statusCode == 200) {
      final responseString = jsonDecode(response.body);
      responseString['code'] = response.statusCode;
      return MakeWishResponse.fromJson(responseString);
    } else {
      throw Exception('failed to load');
    }
  }

  ///////  orders


  Future<OrderResponse> getAllOrders(
      {String token, Category category, int offset = 0, int limit = 10}) async {
    header['Authorization'] = 'Bearer ' + token;
    final response = await http.get(
        Constants.ORDERS +
            "?limit=$limit&offset=$offset",
        headers: header);
    print(response.body);
    if (response.statusCode == SUCCESS) {
      final responseString = jsonDecode(response.body);
      responseString['code'] = response.statusCode;
      return OrderResponse.fromJson(responseString);
    } else {
      throw Exception('failed to load');
    }
  }



  Future<Order> getOrderDetails(
      {String token, int order}) async {
    header['Authorization'] = 'Bearer ' + token;
    final response = await http.get(
        Constants.ORDERS + order.toString() + "/",
        headers: header);
    print(response.body);
    if (response.statusCode == SUCCESS) {
      final responseString = jsonDecode(response.body);
      responseString['code'] = response.statusCode;
      return Order.fromJson(responseString);
    } else {
      throw Exception('failed to load');
    }
  }


  Future<OccasionResponse> getOccasions({String token}) async {
    header['Authorization'] = 'Bearer ' + token;
    final response = await http.get(Constants.OCCASIONS, headers: header);
    print(response.body);
    if (response.statusCode == SUCCESS) {
      final responseString = jsonDecode(response.body);
      responseString['code'] = response.statusCode;
      return OccasionResponse.fromJson(responseString);
    } else {
      throw Exception('failed to load');
    }
  }

  Future<SearchResponse> search({String token,String query}) async {
    header['Authorization'] = 'Bearer ' + token;
    final response = await http.get(Constants.SEARCH+"?search="+query, headers: header);
    print(response.body);
    if (response.statusCode == SUCCESS) {
      final responseString = jsonDecode(response.body);
      responseString['code'] = response.statusCode;
      return SearchResponse.fromJson(responseString);
    } else {
      throw Exception('failed to load');
    }
  }



  /// phase 2

  Future<PortfolioUploadResponse> addPortfolio({
    String token,
    List<File> files,
    Function onProgress
  }) async {
    /*var request =
    http.MultipartRequest('POST', Uri.parse(Constants.ADD_PORTFOLIO));
    request.headers.addAll(header);
    for (var i = 0; i < files.length; i++) {
      request.files
          .add(await http.MultipartFile.fromPath('_file_$i', files[i].path));
    }
    final response = await request.send();
    if (response.statusCode == SUCCESS) {
      var responseData = await response.stream.toBytes();
      var responseChar = String.fromCharCodes(responseData);
      var responseString = jsonDecode(responseChar);
      responseString['code'] = response.statusCode;
      return PortfolioUploadResponse.fromJson(responseString);
    } else {
      throw Exception('failed to load');
    }*/

    Map<String, String> head = {
      //'Accept': 'application/json',
      //'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + token,
    };
    // dio
    var formData = FormData();
    for (var i = 0; i < files.length; i++) {
      formData.files
          .add(MapEntry('_file_$i',
        await MultipartFile.fromFile(files[i].path,filename: files[i].path.split("/").last,contentType: MediaType("image", "jpeg")),
      ));
    }
    var dio = Dio();
    Response response = await dio.post(
        "myportfolio/",
      options: RequestOptions(headers: head,method: "POST",contentType: 'multipart/form-data',baseUrl: Constants.SERVER),
      data: formData,
      onSendProgress: (int sent, int total) {
        if (total != -1) {
          print((sent / total * 100).toStringAsFixed(0) + '%');
          onProgress.call(int.parse((sent / total * 100).toStringAsFixed(0)));
        }
      },
    );

    print(response.statusCode);
    print(response.data);
    if (response.statusCode == SUCCESS) {
      var responseString = response.data;
      responseString['code'] = response.statusCode;
      return PortfolioUploadResponse.fromJson(responseString);
    } else {
      throw Exception('failed to load');
    }
  }



  Future<bool> deletePortfolio({String token,int id}) async {
    header['Authorization'] = 'Bearer ' + token;
    final response = await http.delete(Constants.DELETE_PORTFOLIO+id.toString()+"/", headers: header);
    if (response.statusCode == 204) {
      return true;
    } else {
      throw Exception('failed to load');
    }
  }




  Future<AuditionResponse> getAllAudition(
      {String token, int offset = 0, int limit = 10}) async {
    header['Authorization'] = 'Bearer ' + token;
    final response = await http.get(
        Constants.API_AUDITIONS +
            "?limit=$limit&offset=$offset",
        headers: header);
    print(response.body);
    if (response.statusCode == SUCCESS) {
      final responseString = jsonDecode(response.body);
      responseString['code'] = response.statusCode;
      return AuditionResponse.fromJson(responseString);
    } else {
      throw Exception('failed to load');
    }
  }



  Future<Audition> getAuditionDetails(
      {String token, int audition}) async {
    header['Authorization'] = 'Bearer ' + token;
    final response = await http.get(
        Constants.API_AUDITIONS + audition.toString() + "/",
        headers: header);
    print(response.body);
    if (response.statusCode == SUCCESS) {
      final responseString = jsonDecode(response.body);
      responseString['code'] = response.statusCode;
      return Audition.fromJson(responseString);
    } else {
      throw Exception('failed to load');
    }
  }

  Future<AuditionApplyResponse> submitApplication({
    String token,
    List<String> filePath,
    int audition
  }) async {
    header['Authorization'] = 'Bearer ' + token;
    var request =
    http.MultipartRequest('POST', Uri.parse(Constants.APPLY_AUDITION));
    request.headers.addAll(header);

    Map<String, String> body = {
      'audition': '$audition',
    };
    print(audition);
    request.fields.addAll(body);
    if(filePath!=null)
    if(filePath.length>0)
      for (var i = 0; i < filePath.length; i++){
        request.files.add(await http.MultipartFile.fromPath('file_${i+1}', filePath[i]));
      }


    final response = await request.send();
    print(response.statusCode);
    if (response.statusCode == 201) {
      var responseData = await response.stream.toBytes();
      var responseChar = String.fromCharCodes(responseData);
      print(responseChar);
      var responseString = jsonDecode(responseChar);
      responseString['code'] = response.statusCode;
      return AuditionApplyResponse.fromJson(responseString);
    } else {
      print('else triggered');
      throw Exception('failed to load');
    }
  }

  Future<AppliedAuditionsResponse> getAppliedAuditions(
      {String token, int offset = 0, int limit = 10}) async {
    header['Authorization'] = 'Bearer ' + token;
    final response = await http.get(
        Constants.APPLY_AUDITION +
            "?limit=$limit&offset=$offset",
        headers: header);
    print(response.body);
    if (response.statusCode == SUCCESS) {
      final responseString = jsonDecode(response.body);
      responseString['code'] = response.statusCode;
      return AppliedAuditionsResponse.fromJson(responseString);
    } else {
      throw Exception('failed to load');
    }
  }


  Future<AnalyticsResponse> getAnalytics({String token}) async {
    header['Authorization'] = 'Bearer ' + token;
    final response = await http.get(Constants.ANALYTICS, headers: header);
    print(response.statusCode);
    print(response.body);
    if (response.statusCode == SUCCESS) {
      final responseString = jsonDecode(response.body);
      responseString['code'] = response.statusCode;
      return AnalyticsResponse.fromJson(responseString);
    } else {
      throw Exception('failed to load');
    }
  }

  Future<bool> deleteProfile({String token,int id}) async {
    header['Authorization'] = 'Bearer ' + token;
    final response = await http.get(Constants.PROFILE_DELETE, headers: header);
    print(response.statusCode);
    print(response.body);
    if (response.statusCode == 204 || response.statusCode==200) {
      return true;
    } else {
      throw Exception('failed to load');
    }
  }
}
