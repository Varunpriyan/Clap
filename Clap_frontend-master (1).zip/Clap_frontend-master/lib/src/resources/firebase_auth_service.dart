import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';

class FirebaseAuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  int token;

  verifyPhone({@required String mobile,
    @required PhoneVerificationCompleted verificationCompleted,
    @required PhoneCodeSent codeSent}) {
    FirebaseAuth _auth = FirebaseAuth.instance;
    _auth.verifyPhoneNumber(
        phoneNumber: mobile,
        timeout: Duration(seconds: 60),
        verificationCompleted: (AuthCredential credential) {
          getToken(verificationCompleted, credential);
        },
        verificationFailed: (FirebaseAuthException authException) {
          if (verificationCompleted != null)
            verificationCompleted(null);
          print(authException.message);
        },
        codeSent: (String verificationId, [int forceResendingToken]) {
          token = forceResendingToken;
          if (codeSent != null) codeSent(verificationId);
        },
        codeAutoRetrievalTimeout: (message){});
  }

  verifyOtp(String verificationId, String otp,
      {@required PhoneVerificationCompleted verificationCompleted}) async {
    final String code = otp.trim();
    AuthCredential credential = PhoneAuthProvider.getCredential(
        verificationId: verificationId, smsCode: code);
    return getToken(verificationCompleted, credential);
  }

  void getToken(PhoneVerificationCompleted verificationCompleted,
      AuthCredential credential) async {
    UserCredential result = await _auth.signInWithCredential(credential);
    User user = result.user;
    if (user != null) {
      final User user = _auth.currentUser;
      IdTokenResult uid = await user.getIdTokenResult();
      if (verificationCompleted != null) verificationCompleted(user); //uid.token
    } else {
      if (verificationCompleted != null) verificationCompleted(null);
    }
  }

  getFirebaseToken(){
     return _auth.currentUser.getIdToken(); //true
  }

  logout(){
    return _auth.signOut();
  }



  resendOtp({@required String mobile,
    @required PhoneVerificationCompleted verificationCompleted,
    @required PhoneCodeSent codeSent}) {
    FirebaseAuth _auth = FirebaseAuth.instance;
    _auth.verifyPhoneNumber(
        phoneNumber: mobile,
        timeout: Duration(seconds: 60),
        verificationCompleted: (AuthCredential credential) {
          getToken(verificationCompleted, credential);
        },
        verificationFailed: (FirebaseAuthException authException) {
          if (verificationCompleted != null)
            verificationCompleted(null);
          print(authException.message);
        },
        codeSent: (String verificationId, [int forceResendingToken]) {
          token = forceResendingToken;
          if (codeSent != null) codeSent(verificationId);
        },
        forceResendingToken: token,
        codeAutoRetrievalTimeout: (message){});
  }

}

typedef void PhoneVerificationCompleted(User user);
typedef void PhoneCodeSent(String verificationId);
