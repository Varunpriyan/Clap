final _successString = 'success';
class SuccessResponse {
  String status;
  String code;
  String comments;
  bool success;

  SuccessResponse({this.status, this.code, this.comments});

  SuccessResponse.fromJson(Map<String, dynamic> json) {
    print(json.toString());
    status = json['status'];
    success = status == _successString;
    code = json['code'];
    comments = json['comments'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['code'] = this.code;
    data['comments'] = this.comments;
    return data;
  }
}
