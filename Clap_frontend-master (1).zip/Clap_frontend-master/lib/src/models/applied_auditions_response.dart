import 'package:clap/src/models/audition_response.dart';
import 'package:clap/src/models/audition_apply_response.dart';
class AppliedAuditionsResponse {
  int count;
  String next;
  bool success;
  String previous;
  List<Application> applications;

  AppliedAuditionsResponse(
      {this.count, this.next, this.previous, this.applications,this.success});

  AppliedAuditionsResponse.fromJson(Map<String, dynamic> json) {
    count = json['count'];
    success = json['code']==200 ? true : false;
    next = json['next'];
    previous = json['previous'];
    if (json['results'] != null) {
      applications = new List<Application>();
      json['results'].forEach((v) {
        applications.add(new Application.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['count'] = this.count;
    data['next'] = this.next;
    data['previous'] = this.previous;
    if (this.applications != null) {
      data['results'] = this.applications.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Application {
  int id;
  Audition audition;
  String status;
  String createdAt;
  List<Clips> clips;

  Application({this.id, this.audition, this.status, this.createdAt, this.clips});

  Application.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    audition = json['audition'] != null
        ? new Audition.fromJson(json['audition'])
        : null;
    status = json['status'].toString();
    createdAt = json['created_at'];
    if (json['clips'] != null) {
      clips = new List<Clips>();
      json['clips'].forEach((v) {
        clips.add(new Clips.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    if (this.audition != null) {
      data['audition'] = this.audition.toJson();
    }
    data['status'] = this.status;
    data['created_at'] = this.createdAt;
    if (this.clips != null) {
      data['clips'] = this.clips.map((v) => v.toJson()).toList();
    }
    return data;
  }
}


