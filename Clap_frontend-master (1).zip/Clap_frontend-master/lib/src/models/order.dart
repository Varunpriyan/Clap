import 'package:clap/src/models/ask_question.dart';
import 'package:clap/src/models/celebrity.dart';

class OrderResponse {
  int count;
  String next;
  String previous;
  bool success;
  List<Order> orders;

  OrderResponse({this.count, this.next, this.previous, this.orders,this.success});

  OrderResponse.fromJson(Map<String, dynamic> json) {
    count = json['count'];
    next = json['next'];
    success = json['code']==201||json['code']==200 ? true:false;
    previous = json['previous'];
    if (json['results'] != null) {
      orders = new List<Order>();
      json['results'].forEach((v) {
        orders.add(new Order.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['count'] = this.count;
    data['next'] = this.next;
    data['previous'] = this.previous;
    if (this.orders != null) {
      data['results'] = this.orders.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Order {
  int id;
  String orderId;
  Question booking;
  String amount;
  Question question;
  String responseChoice;
  String phone;
  String email;
  bool placed;
  bool recived;
  bool declined;
  bool approved;
  bool delivered;
  bool refund;
  String rzpOrderid;
  String date;
  String status;
  Keys keys;

  Order(
      {this.id,
        this.orderId,
        this.booking,
        this.amount,
        this.question,
        this.responseChoice,
        this.phone,
        this.email,
        this.placed,
        this.recived,
        this.declined,
        this.approved,
        this.delivered,
        this.refund,
        this.keys,
        this.rzpOrderid,
        this.status,
        this.date});

  Order.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    orderId = json['order_id'];
    amount = json['amount'].toString();
    //booking = json['booking'];
    booking = json['booking'] != null
        ? new Question.fromJson(json['booking'])
        : null;
    question = json['question'] != null
        ? new Question.fromJson(json['question'])
        : null;
    responseChoice = json['response_choice'];
    phone = json['phone'];
    email = json['email'];
    placed = json['placed'];
    recived = json['recived'];
    declined = json['declined'];
    approved = json['approved'];
    delivered = json['delivered'];
    refund = json['refund'];
    rzpOrderid = json['rzp_orderid'];
    date = json['date'];
    keys = json['keys'] != null ? new Keys.fromJson(json['keys']) : null;
    // set status
    status = "Order Placed"; // default
    if(placed!=null&&placed){
      status = "Order Placed";
    }
    if(recived!=null){
      status = recived ? "Order Received" : "Payment Failed";
    }else{
      status = "Payment Failed";
    }
    if(approved!=null){
      status = approved ? "Order Approved" : "Order Declined";
    }
    if(delivered!=null){
      status = delivered ? "Order Delivered" : "Order Not Delivered";
    }
    if(refund!=null){
      status = refund ? "Refund Processed" : "Refund Not Processed";
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['order_id'] = this.orderId;
    data['booking'] = this.booking;
    if (this.question != null) {
      data['question'] = this.question.toJson();
    }
    data['response_choice'] = this.responseChoice;
    data['phone'] = this.phone;
    data['email'] = this.email;
    data['placed'] = this.placed;
    data['recived'] = this.recived;
    data['declined'] = this.declined;
    data['approved'] = this.approved;
    data['delivered'] = this.delivered;
    data['rzp_orderid'] = this.rzpOrderid;
    data['date'] = this.date;
    return data;
  }
}

class Question {
  int id;
  Celebrity celebrity;
  String question;
  String phone;
  String email;
  String date;

  Question(
      {this.id,
        this.celebrity,
        this.question,
        this.phone,
        this.email,
        this.date});

  Question.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    celebrity = json['celebrity'] != null
        ? new Celebrity.fromJson(json['celebrity'])
        : null;
    question = json['question'];
    phone = json['phone'];
    email = json['email'];
    date = json['date'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    if (this.celebrity != null) {
      data['celebrity'] = this.celebrity.toJson();
    }
    data['question'] = this.question;
    data['phone'] = this.phone;
    data['email'] = this.email;
    data['date'] = this.date;
    return data;
  }
}



