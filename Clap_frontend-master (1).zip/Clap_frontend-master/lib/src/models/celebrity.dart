import 'package:clap/src/models/categories_response.dart';

class Celebrity {
  int id;
  String name;
  String profession;
  List<Category> category;
  String image;
  String info;
  String description;
  String responseTime;
  String makeWishPrice;
  String askQuestionPrice;
  String url;
  List<Celebrity> relatedCelebrity;
  List<Video> sampleWishes;

  Celebrity(
      {this.id,
        this.name,
        this.profession,
        this.category,
        this.image,
        this.info,
        this.description,
        this.responseTime,
        this.makeWishPrice,
        this.askQuestionPrice,
        this.relatedCelebrity,
        this.url});

  Celebrity.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    profession = json['profession']!=null ? json['profession'] : "";
    if (json['category'] != null) {
      category = new List<Category>();
      json['category'].forEach((v) {
        category.add(new Category.fromJson(v));
      });
    }
    image = json['image'];
    info = json['info'];
    description = json['description'];
    responseTime = json['response_time'];
    makeWishPrice = json['make_wish_price'];
    askQuestionPrice = json['ask_question_price'];
    url = json['url'];
    if (json['related_celebrity'] != null) {
      relatedCelebrity = new List<Celebrity>();
      json['related_celebrity'].forEach((v) {
        relatedCelebrity.add(new Celebrity.fromJson(v));
      });
    }

    if (json['sample_wishes'] != null) {
      if (json['sample_wishes'] != false) {
        sampleWishes = new List<Video>();
        json['sample_wishes'].forEach((v) {
          sampleWishes.add(new Video.fromJson(v));
        });
      }
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['profession'] = this.profession;
    if (this.category != null) {
      data['category'] = this.category.map((v) => v.toJson()).toList();
    }
    data['image'] = this.image;
    data['info'] = this.info;
    data['description'] = this.description;
    data['response_time'] = this.responseTime;
    data['make_wish_price'] = this.makeWishPrice;
    data['ask_question_price'] = this.askQuestionPrice;
    data['url'] = this.url;
    return data;
  }
}

class Video {
  String user;
  String url;

  Video({this.user, this.url});

  Video.fromJson(Map<String, dynamic> json) {
    user = json['user'];
    url = json['url'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['user'] = this.user;
    data['url'] = this.url;
    return data;
  }
}

