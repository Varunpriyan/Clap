import 'package:clap/src/models/profile_response.dart';
class PortfolioUploadResponse {
  List<Media> images;
  List<Media> videos;
  bool success;
  String error;
  PortfolioUploadResponse({this.images,this.videos,this.success,this.error});

  PortfolioUploadResponse.fromJson(Map<String, dynamic> json) {
    success = json['code']==200 ? true : false;
    error =  json['code']==200 ? null : json['detail'];
    if (json['uploads'] != null) {
      images = new List<Media>();
      videos = new List<Media>();
      json['uploads'].forEach((v) {
        if(v['_file'].toString().toLowerCase().endsWith(".mp4")){
          videos.add(new Media.fromJson(v));
        }else{
          images.add(new Media.fromJson(v));
        }

      });
    }
  }
}
