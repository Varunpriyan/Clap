class AskQuestionResponse {
  bool success;
  int id;
  String celebrity;
  String question;
  String razorId;
  int order;
  Keys keys;
  bool paymentStatus;

  AskQuestionResponse(
      {this.id,
        this.success,
        this.celebrity,
        this.question,
        this.razorId,
        this.order,
        this.paymentStatus=false,
        this.keys});

  AskQuestionResponse.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    success = json['code']==201||json['code']==200 ? true:false;
    celebrity = json['celebrity'].toString();
    question = json['question'];
    razorId = json['razor_id'];
    order = json['order'];
    paymentStatus = false;
    keys = json['keys'] != null ? new Keys.fromJson(json['keys']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['celebrity'] = this.celebrity;
    data['question'] = this.question;
    data['razor_id'] = this.razorId;
    data['order'] = this.order;
    if (this.keys != null) {
      data['keys'] = this.keys.toJson();
    }
    return data;
  }
}

class Keys {
  String test;
  String secret;

  Keys({this.test, this.secret});

  Keys.fromJson(Map<String, dynamic> json) {
    test = json['test'];
    secret = json['secret'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['test'] = this.test;
    data['secret'] = this.secret;
    return data;
  }
}
