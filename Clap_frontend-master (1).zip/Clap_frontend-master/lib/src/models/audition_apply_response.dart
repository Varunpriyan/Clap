class AuditionApplyResponse {
  int id;
  int audition;
  String status;
  bool success;
  String createdAt;
  List<Clips> clips;

  AuditionApplyResponse(
      {this.id, this.audition, this.status, this.createdAt, this.clips,this.success});

  AuditionApplyResponse.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    success = json['code']==201 ? true : false;
    audition = json['audition'];
    status = json['status'];
    createdAt = json['created_at'];
    if (json['clips'] != null) {
      clips = new List<Clips>();
      json['clips'].forEach((v) {
        clips.add(new Clips.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['audition'] = this.audition;
    data['status'] = this.status.toString();
    data['created_at'] = this.createdAt;
    if (this.clips != null) {
      data['clips'] = this.clips.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Clips {
  int id;
  String sFile;

  Clips({this.id, this.sFile});

  Clips.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    sFile = json['_file'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['_file'] = this.sFile;
    return data;
  }
}
