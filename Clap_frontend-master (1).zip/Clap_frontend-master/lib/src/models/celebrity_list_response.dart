import 'package:clap/src/models/celebrity.dart';

class CelebrityListResponse {
  int count;
  String next;
  String previous;
  List<Celebrity> celebrities;

  CelebrityListResponse({this.count, this.next, this.previous, this.celebrities});

  CelebrityListResponse.fromJson(Map<String, dynamic> json) {
    count = json['count'];
    next = json['next'];
    previous = json['previous'];
    if (json['results'] != null) {
      celebrities = new List<Celebrity>();
      json['results'].forEach((v) {
        celebrities.add(new Celebrity.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['count'] = this.count;
    data['next'] = this.next;
    data['previous'] = this.previous;
    if (this.celebrities != null) {
      data['results'] = this.celebrities.map((v) => v.toJson()).toList();
    }
    return data;
  }
}
