class AnalyticsResponse {
  int profileViewCount;
  bool success;
  List<ViewedUsers> viewedUsers;

  AnalyticsResponse({this.profileViewCount, this.viewedUsers,this.success});

  AnalyticsResponse.fromJson(Map<String, dynamic> json) {
    success = json['code']==200 ? true : false;
    profileViewCount = json['profile_view_count'];
    if (json['viewed_users'] != null) {
      viewedUsers = new List<ViewedUsers>();
      json['viewed_users'].forEach((v) {
        viewedUsers.add(new ViewedUsers.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['profile_view_count'] = this.profileViewCount;
    if (this.viewedUsers != null) {
      data['viewed_users'] = this.viewedUsers.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class ViewedUsers {
  String user;
  int count;

  ViewedUsers({this.user, this.count});

  ViewedUsers.fromJson(Map<String, dynamic> json) {
    user = json['user'];
    count = json['count'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['user'] = this.user;
    data['count'] = this.count;
    return data;
  }
}
