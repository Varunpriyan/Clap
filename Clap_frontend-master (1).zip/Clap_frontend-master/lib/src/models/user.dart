class User {
  int adminId;
  String fullName;
  String gender;
  String address;
  String email;
  String mobileNum;
  String photo;
  int loginStatus;
  int locationId;
  String userId;
  String locationName;

  User(
      {this.adminId,
        this.fullName,
        this.gender,
        this.address,
        this.email,
        this.mobileNum,
        this.photo,
        this.loginStatus,
        this.locationId,
        this.userId,
        this.locationName});

  User.fromJson(Map<String, dynamic> json) {
    adminId = json['admin_id'];
    fullName = json['full_name'];
    gender = json['gender'];
    address = json['address'];
    email = json['email'];
    mobileNum = json['mobile_num'];
    photo = json['photo'];
    loginStatus = json['login_status'];
    locationId = json['location_id'];
    userId = json['user_id'];
    locationName = json['location_name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['admin_id'] = this.adminId;
    data['full_name'] = this.fullName;
    data['gender'] = this.gender;
    data['address'] = this.address;
    data['email'] = this.email;
    data['mobile_num'] = this.mobileNum;
    data['photo'] = this.photo;
    data['login_status'] = this.loginStatus;
    data['location_id'] = this.locationId;
    data['user_id'] = this.userId;
    data['location_name'] = this.locationName;
    return data;
  }
}
