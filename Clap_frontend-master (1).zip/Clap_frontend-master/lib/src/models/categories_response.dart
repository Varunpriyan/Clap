import 'package:clap/src/models/celebrity.dart';
class CategoriesResponse {
  int count;
  int next;
  int previous;
  List<Category> categories;

  CategoriesResponse({this.count, this.next, this.previous, this.categories});

  CategoriesResponse.fromJson(Map<String, dynamic> json) {
    count = json['count'];
    next = json['next'];
    previous = json['previous'];
    if (json['results'] != null) {
      categories = new List<Category>();
      json['results'].forEach((v) {
        categories.add(new Category.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['count'] = this.count;
    data['next'] = this.next;
    data['previous'] = this.previous;
    if (this.categories != null) {
      data['results'] = this.categories.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Category {
  int id;
  String name;
  List<Celebrity> celebrities;

  Category({this.id, this.name, this.celebrities});

  Category.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    if (json['celebrities'] != null) {
      celebrities = new List<Celebrity>();
      json['celebrities'].forEach((v) {
        celebrities.add(new Celebrity.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    if (this.celebrities != null) {
      data['celebrities'] = this.celebrities.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

