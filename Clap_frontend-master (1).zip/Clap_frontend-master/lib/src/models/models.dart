import 'package:clap/src/models/celebrity.dart';
import 'package:clap/src/models/occasion_response.dart';
import 'package:clap/src/models/profile_response.dart';

class OtpData{
  String mobile;
  String token;
  bool isRegister;

  OtpData({this.mobile,this.isRegister,this.token});
}

class MakeWish{
  Celebrity celebrity;
  Profile user;
  String forWho;
  Occasion occasion;
  String otherInfo;
  String introduction;
  String instruction;
  MakeWish({this.celebrity,this.user,this.forWho,this.occasion,this.otherInfo});
}

class AskQuestion{
  Celebrity celebrity;
  Profile user;
  String question;
  AskQuestion({this.celebrity,this.user,this.question});
}

class TempOrder{
  int order;
  bool status;
  TempOrder({this.order,this.status});
}

class ActionState{
  Celebrity celebrity;
  String actionType;
  ActionState({this.celebrity,this.actionType});
}