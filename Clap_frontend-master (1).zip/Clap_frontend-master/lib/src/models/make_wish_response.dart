import 'package:clap/src/models/ask_question.dart';

class MakeWishResponse {
  int id;
  String celebrity;
  CelebrityDetails celebrityDetails;
  String occasions;
  String indroduction;
  String instruction;
  String bookingFor;
  String razorId;
  int order;
  Keys keys;
  bool success;
  bool paymentStatus;

  MakeWishResponse(
      {this.id,
        this.celebrity,
        this.celebrityDetails,
        this.occasions,
        this.indroduction,
        this.instruction,
        this.bookingFor,
        this.razorId,
        this.order,
        this.success,
        this.paymentStatus,
        this.keys});

  MakeWishResponse.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    success = json['code']==201||json['code']==200 ? true:false;
    paymentStatus = false;
    celebrity = json['celebrity'].toString();
    celebrityDetails = json['celebrity_details'] != null
        ? new CelebrityDetails.fromJson(json['celebrity_details'])
        : null;
    occasions = json['occasions'].toString();
    indroduction = json['indroduction'];
    instruction = json['instruction'];
    bookingFor = json['booking_for'];
    razorId = json['razor_id'];
    order = json['order'];
    keys = json['keys'] != null ? new Keys.fromJson(json['keys']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['celebrity'] = this.celebrity;
    if (this.celebrityDetails != null) {
      data['celebrity_details'] = this.celebrityDetails.toJson();
    }
    data['occasions'] = this.occasions;
    data['indroduction'] = this.indroduction;
    data['instruction'] = this.instruction;
    data['booking_for'] = this.bookingFor;
    data['razor_id'] = this.razorId;
    data['order'] = this.order;
    if (this.keys != null) {
      data['keys'] = this.keys.toJson();
    }
    return data;
  }
}

class CelebrityDetails {
  int id;
  String name;

  CelebrityDetails({this.id, this.name});

  CelebrityDetails.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    return data;
  }
}

