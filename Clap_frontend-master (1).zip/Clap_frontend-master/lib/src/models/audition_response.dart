class AuditionResponse {
  int count;
  bool success;
  String next;
  String previous;
  List<Audition> auditions;

  AuditionResponse({this.count, this.next, this.previous, this.auditions,this.success});

  AuditionResponse.fromJson(Map<String, dynamic> json) {
    success = json['code']==200 ? true : false;
    count = json['count'];
    next = json['next'];
    previous = json['previous'];
    if (json['results'] != null) {
      auditions = new List<Audition>();
      json['results'].forEach((v) {
        auditions.add(new Audition.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['count'] = this.count;
    data['next'] = this.next;
    data['previous'] = this.previous;
    if (this.auditions != null) {
      data['results'] = this.auditions.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Audition {
  int id;
  String name;
  String image;
  String info;
  String production;
  String otherInfo;
  bool expired;
  CreatedBy createdBy;
  String createdAt;
  bool auditionClip;
  bool isProfileComplete;
  bool applied;
  int nextAudition;
  String status;

  Audition(
      {this.id,
        this.name,
        this.image,
        this.info,
        this.production,
        this.otherInfo,
        this.expired,
        this.createdBy,
        this.createdAt,
        this.auditionClip,
        this.applied,
        this.nextAudition,
        this.status,
      this.isProfileComplete});

  Audition.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    image = json['image'];
    info = json['info'];
    production = json['production'];
    otherInfo = json['other_info'];
    expired = json['expired'];
    createdBy = json['created_by'] != null
        ? json['created_by'].toString().length>4 ? new CreatedBy.fromJson(json['created_by']) : null
        : null;
    createdAt = json['created_at'];
    auditionClip = json['audition_clip'];
    applied = json['applied'];
    nextAudition = json['next_url'];
    status = json['status'];
    isProfileComplete = json.containsKey('profile_completed') ? json['profile_completed'] : false;
    print(json['profile_completed']);
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['image'] = this.image;
    data['info'] = this.info;
    data['production'] = this.production;
    data['other_info'] = this.otherInfo;
    data['expired'] = this.expired;
    if (this.createdBy != null) {
      data['created_by'] = this.createdBy.toJson();
    }
    data['created_at'] = this.createdAt;
    data['audition_clip'] = this.auditionClip;
    data['applied'] = this.applied;
    data['next_url'] = this.nextAudition;
    data['status'] = this.status;
    return data;
  }
}

class CreatedBy {
  String displayName;
  String profile;

  CreatedBy({this.displayName, this.profile});

  CreatedBy.fromJson(Map<String, dynamic> json) {
    displayName = json['display_name'];
    profile = json['profile'].toString();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['display_name'] = this.displayName;
    data['profile'] = this.profile;
    return data;
  }
}
