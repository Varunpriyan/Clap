class PaymentResponse {
  int id;
  int order;
  String amount;
  String date;
  bool success;

  PaymentResponse({this.id, this.order, this.amount, this.date,this.success});

  PaymentResponse.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    success = json['code']==201||json['code']==200 ? true:false;
    order = json['order'];
    amount = json['amount'];
    date = json['date'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['order'] = this.order;
    data['amount'] = this.amount;
    data['date'] = this.date;
    return data;
  }
}
