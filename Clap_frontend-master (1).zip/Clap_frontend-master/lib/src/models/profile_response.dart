class Profile {
  int id;
  bool success;
  String displayName;
  String phoneNumber;
  String email;
  String profile;
  String address;
  String lastName;
  String aboutMe;
  bool isAudition;
  bool isCompleted;
  int age;
  String gender;
  String height;
  String weight;
  String location;
  String hairColour;
  Portfolio portfolio;

  Profile(
      {this.id,
        this.success,
        this.displayName,
        this.phoneNumber,
        this.email,
        this.profile,
        this.address,
        this.lastName,
        this.aboutMe,
        this.isAudition,
        this.isCompleted,
        this.age,
        this.gender,
        this.height,
        this.weight,
        this.location,
        this.hairColour,
        this.portfolio});

  Profile.fromJson(Map<String, dynamic> json) {
    id = json.containsKey('id') ? json['id'] : null;
    success = json['code']==200 ? true : false;
    displayName = json.containsKey('display_name') ? json['display_name'] : "";
    phoneNumber = json.containsKey('phone_number') ? json['phone_number'] : "";
    email = json['code']==200 ? json.containsKey('email') ? json['email'] : "" : json['email'].reduce((value, element) => value + ',' + element);
    profile = json.containsKey('profile') ? json['profile'] : null;
    address = json.containsKey('address') ? json['address'] : "";
    lastName = json.containsKey('last_name') ? json['last_name'] : "";
    aboutMe = json['about_me'];
    isAudition = json['is_audition'];
    isCompleted = json['is_completed'];
    age = json['age'];
    gender = json['gender'];
    height = json['height'];
    weight = json['weight'];
    location = json['location'];
    hairColour = json['hair_colour'];
    portfolio = json['portfolio'] != null
        ? new Portfolio.fromJson(json['portfolio'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['display_name'] = this.displayName;
    data['phone_number'] = this.phoneNumber;
    data['email'] = this.email;
    data['profile'] = this.profile;
    data['address'] = this.address;
    data['last_name'] = this.lastName;
    data['about_me'] = this.aboutMe;
    data['is_audition'] = this.isAudition;
    data['is_completed'] = this.isCompleted;
    data['age'] = this.age;
    data['gender'] = this.gender;
    data['height'] = this.height;
    data['weight'] = this.weight;
    data['location'] = this.location;
    data['hair_colour'] = this.hairColour;
    if (this.portfolio != null) {
      data['portfolio'] = this.portfolio.toJson();
    }
    return data;
  }
}

class Portfolio {
  List<Media> video;
  List<Media> image;

  Portfolio({this.video, this.image});

  Portfolio.fromJson(Map<String, dynamic> json) {
    if (json['video'] != null) {
      video = new List<Media>();
      json['video'].forEach((v) {
        video.add(new Media.fromJson(v));
      });
    }
    if (json['image'] != null) {
      image = new List<Media>();
      json['image'].forEach((v) {
        image.add(new Media.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.video != null) {
      data['video'] = this.video.map((v) => v.toJson()).toList();
    }
    if (this.image != null) {
      data['image'] = this.image.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Media {
  int id;
  String file;

  Media({this.id, this.file});

  Media.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    file = json['_file'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['_file'] = this.file;
    return data;
  }
}
