import 'package:clap/src/models/categories_response.dart';
import 'package:clap/src/models/celebrity.dart';

class SearchResponse {
  bool success;
  List<Category> categories;
  List<Celebrity> celebrities;

  SearchResponse({this.categories, this.celebrities});

  SearchResponse.fromJson(Map<String, dynamic> json) {
    success = json['code']==200 ? true:false;
    categories = [];
    celebrities = [];
    if (json['categories'] != null) {
      categories = new List<Category>();
      json['categories'].forEach((v) {
        categories.add(new Category.fromJson(v));
      });
    }
    if (json['celebrities'] != null) {
      celebrities = new List<Celebrity>();
      json['celebrities'].forEach((v) {
        celebrities.add(new Celebrity.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.categories != null) {
      data['categories'] = this.categories.map((v) => v.toJson()).toList();
    }
    if (this.celebrities != null) {
      data['celebrities'] = this.celebrities.map((v) => v.toJson()).toList();
    }
    return data;
  }
}
