part of 'order_cubit.dart';

abstract class OrderState extends Equatable {
  const OrderState();
}

class OrderInitial extends OrderState {
  @override
  List<Object> get props => [];
}


class OrdersLoading extends OrderState {
  @override
  List<Object> get props => [];
}

class OrdersLoadSuccess extends OrderState {
  final List<Order> orders;

  OrdersLoadSuccess(this.orders);

  @override
  List<Object> get props => [orders];
}

class OrdersLoadEmpty extends OrderState {
  final List<Order> orders;

  OrdersLoadEmpty(this.orders);

  @override
  List<Object> get props => [orders];
}

class OrdersLoadError extends OrderState {
  @override
  List<Object> get props => [];
}



class OrderDetailsLoading extends OrderState {
  @override
  List<Object> get props => [];
}

class OrderDetailsLoadSuccess extends OrderState {
  final Order order;
  final Profile user;

  OrderDetailsLoadSuccess(this.order,this.user);

  @override
  List<Object> get props => [order,user];
}

class OrderDetailsLoadEmpty extends OrderState {
  @override
  List<Object> get props => [];
}

class OrderDetailsLoadError extends OrderState {
  @override
  List<Object> get props => [];
}
