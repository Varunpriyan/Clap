import 'package:bloc/bloc.dart';
import 'package:clap/src/models/order.dart';
import 'package:clap/src/resources/repository.dart';
import 'package:equatable/equatable.dart';
import 'package:clap/src/models/profile_response.dart';
part 'order_state.dart';

class OrderCubit extends Cubit<OrderState> {
  OrderCubit() : super(OrderInitial());
  final Repository _repository = Repository();
  OrdersLoadSuccess _currentOrdersLoadSuccessState;

  void getAllOrders() async {
    _currentOrdersLoadSuccessState = null;
    emit(OrdersLoading());
    try {
      OrderResponse response = await _repository.getAllOrders();
      if (response.success) {
        if (response.orders.length > 0) {
          emit(OrdersLoadSuccess(response.orders));
          _currentOrdersLoadSuccessState = state;
        } else
          emit(OrdersLoadEmpty(null));
      } else {
        emit(OrdersLoadError());
      }
    } catch (e) {
      print(e.toString());
      emit(OrdersLoadError());
    }
  }

  void getAllOrdersNext() async {
    if (_currentOrdersLoadSuccessState != null &&
        _currentOrdersLoadSuccessState is OrdersLoadSuccess) {
      emit(OrdersLoading());
      try {
        OrderResponse response = await _repository.getAllOrders(
            offset: _currentOrdersLoadSuccessState.orders.length);
        if (response.success) {
          if (response.orders.length > 0) {
            emit(OrdersLoadSuccess(
                (_currentOrdersLoadSuccessState != null
                    ? _currentOrdersLoadSuccessState.orders
                    : List<Order>()) +
                    response.orders));
            _currentOrdersLoadSuccessState = state;
          } else {
            emit(
                OrdersLoadEmpty(_currentOrdersLoadSuccessState.orders));
          }
        } else {
          emit(OrdersLoadError());
        }
      } catch (e) {
        emit(OrdersLoadError());
        print(e);
      }
    } else
      emit(OrdersLoadEmpty(null));
  }

  void getOrderDetails(int order) async {
    emit(OrderDetailsLoading());
    try {
      Order response =
      await _repository.getOrderDetails(order);
        if (response != null) {
          Profile profile = await _repository.getUserFromCache();
          emit(OrderDetailsLoadSuccess(response,profile));
        } else
          emit(OrderDetailsLoadEmpty());

    } catch (e) {
      emit(OrderDetailsLoadError());
    }
  }
}
