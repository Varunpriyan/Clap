part of 'make_wish_cubit.dart';

abstract class MakeWishState extends Equatable {
  const MakeWishState();
}

class MakeWishInitial extends MakeWishState {
  @override
  List<Object> get props => [];
}


class MakeWishBusy extends MakeWishState {
  @override
  List<Object> get props => [];
}

class MakeWishValidationError extends MakeWishState {
  final int field;

  MakeWishValidationError(this.field);
  @override
  List<Object> get props => [field];
}

class MakeWishValidationSuccess extends MakeWishState {
  @override
  List<Object> get props => [];
}


class MakeWishError extends MakeWishState {
  @override
  List<Object> get props => [];
}

class MakeWishSuccess extends MakeWishState {
  final MakeWishResponse makeWishResponse;
  final MakeWish makeWish;

  MakeWishSuccess(this.makeWishResponse,this.makeWish);
  @override
  List<Object> get props => [makeWishResponse,makeWish];
}

class PaymentUpdating extends MakeWishState {
  @override
  List<Object> get props => [];
}

class PaymentUpdateSuccess extends MakeWishState {
  final MakeWishResponse makeWishResponse;

  PaymentUpdateSuccess(this.makeWishResponse);

  @override
  List<Object> get props => [makeWishResponse];
}

class PaymentUpdateFailed extends MakeWishState {
  final MakeWishResponse makeWishResponse;

  PaymentUpdateFailed(this.makeWishResponse);

  @override
  List<Object> get props => [makeWishResponse];
}

class PaymentUpdateError extends MakeWishState {
  final MakeWishResponse makeWishResponse;

  PaymentUpdateError(this.makeWishResponse);

  @override
  List<Object> get props => [makeWishResponse];
}
