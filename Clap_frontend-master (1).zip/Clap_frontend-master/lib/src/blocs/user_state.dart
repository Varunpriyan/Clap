part of 'user_cubit.dart';

abstract class UserState extends Equatable {
  const UserState();
}

class UserInitial extends UserState {
  @override
  List<Object> get props => [];
}

class LoggedInStatusCheckInProgress extends UserState {
  @override
  List<Object> get props => [];
}

class RegisteredUser extends UserState {
  final bool registrationRequired;

  RegisteredUser(this.registrationRequired);
  @override
  List<Object> get props => [registrationRequired];
}

class RegistrationRequired extends UserState {
  @override
  List<Object> get props => [];
}

class LoginRequired extends UserState {
  @override
  List<Object> get props => [];
}

class SkippedLogin extends UserState {
  @override
  List<Object> get props => [];
}