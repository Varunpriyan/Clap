import 'dart:developer';

import 'package:bloc/bloc.dart';
import 'package:clap/src/models/profile_response.dart';
import 'package:clap/src/resources/repository.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';

part 'user_state.dart';

class UserCubit extends Cubit<UserState> {
  UserCubit() : super(UserInitial());
  final Repository _repository = Repository();

  Future<void> checkUserLoggedInStatus() async {
    emit(LoggedInStatusCheckInProgress());
   bool status = await _repository.getSkipLoginStatus();
   print("status"+status.toString());
   if(!status){
     try{
       String token = await _repository.getFirebaseToken();
       debugPrint(token);
       if (token != null && token.isNotEmpty) {
         Profile profile = await _repository.getUserFromCache();
         emit(RegisteredUser(profile.displayName==""||profile.displayName==null));
       } else {
         //Future.delayed(const Duration(seconds: 2), () {
         emit(LoginRequired());
         //  });
       }
     }catch(_){
       Future.delayed(const Duration(seconds: 2), () {
         emit(LoginRequired());
       });
     }
   }else{
     emit(RegisteredUser(false));
   }


  }


  void skipLogin()async{
    await _repository.saveSkipLoginStatus(true);
    emit(SkippedLogin());
  }

  Future<bool> getSkipLoginStatus()async{
   bool status = await _repository.getSkipLoginStatus();
   print("cubit status"+status.toString());
   return status;
  }



}
