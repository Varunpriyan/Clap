part of 'ask_question_cubit.dart';

abstract class AskQuestionState extends Equatable {
  const AskQuestionState();
}

class AskQuestionInitial extends AskQuestionState {
  @override
  List<Object> get props => [];
}

class AskQuestionValidationError extends AskQuestionState {
  final int field;

  AskQuestionValidationError(this.field);
  @override
  List<Object> get props => [field];
}
class AskQuestionValidationSuccess extends AskQuestionState {
  final Profile user;

  AskQuestionValidationSuccess(this.user);
  @override
  List<Object> get props => [user];
}


class AskQuestionError extends AskQuestionState {
  @override
  List<Object> get props => [];
}

class AskQuestionSuccess extends AskQuestionState {
  final AskQuestionResponse askQuestionResponse;
  final Profile user;

  AskQuestionSuccess(this.askQuestionResponse,this.user);
  @override
  List<Object> get props => [askQuestionResponse,user];
}

class AskQuestionBusy extends AskQuestionState {
  @override
  List<Object> get props => [];
}


class PaymentUpdating extends AskQuestionState {
  @override
  List<Object> get props => [];
}

class PaymentUpdateSuccess extends AskQuestionState {
  final AskQuestionResponse askQuestionResponse;

  PaymentUpdateSuccess(this.askQuestionResponse);

  @override
  List<Object> get props => [askQuestionResponse];
}

class PaymentUpdateFailed extends AskQuestionState {
  final AskQuestionResponse askQuestionResponse;

  PaymentUpdateFailed(this.askQuestionResponse);

  @override
  List<Object> get props => [askQuestionResponse];
}

class PaymentUpdateError extends AskQuestionState {
  final AskQuestionResponse askQuestionResponse;

  PaymentUpdateError(this.askQuestionResponse);

  @override
  List<Object> get props => [askQuestionResponse];
}
