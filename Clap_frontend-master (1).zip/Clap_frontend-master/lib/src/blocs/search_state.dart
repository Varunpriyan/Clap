part of 'search_cubit.dart';

abstract class SearchState extends Equatable {
  const SearchState();
}

class SearchInitial extends SearchState {
  @override
  List<Object> get props => [];
}


class SearchLoading extends SearchState {
  @override
  List<Object> get props => [];
}

class SearchLoadSuccess extends SearchState {
  final SearchResponse searchResponse;

  SearchLoadSuccess(this.searchResponse);

  @override
  List<Object> get props => [searchResponse];
}


class SearchLoadEmpty extends SearchState {
  @override
  List<Object> get props => [];
}

class SearchLoadError extends SearchState {
  @override
  List<Object> get props => [];
}
