import 'package:bloc/bloc.dart';
import 'package:clap/src/models/categories_response.dart';
import 'package:clap/src/models/celebrity.dart';
import 'package:clap/src/models/celebrity_list_response.dart';
import 'package:clap/src/resources/repository.dart';
import 'package:equatable/equatable.dart';

part 'category_state.dart';

class CategoryCubit extends Cubit<CategoryState> {
  CategoryCubit() : super(CategoryInitial());

  final Repository _repository = Repository();
  CelebritiesInCategoryLoadSuccess _celebritiesInCategoryLoadSuccess;


  void getCategories() async {
    emit(CategoryLoading());
    try {
      CategoriesResponse categories = await _repository.getCategories();
      if (categories.categories.length>0) {
        emit(CategoryLoadSuccess(categories.categories));
      } else {
        emit(CategoryLoadEmpty());
      }
    } catch (_) {
      print(_.toString());
      emit(CategoryLoadError());
    }
  }

  void getCelebritiesInCategory(Category category) async {
    _celebritiesInCategoryLoadSuccess = null;
    emit(CelebritiesInCategoryLoading());
    try {
      CelebrityListResponse celebrities = await _repository.getCelebritiesInCategory(category: category);
      if (celebrities.celebrities.length>0) {
        emit(CelebritiesInCategoryLoadSuccess(celebrities.celebrities));
        _celebritiesInCategoryLoadSuccess = state;
      } else {
        emit(CelebritiesInCategoryLoadEmpty(null));
      }
    } catch (_) {
      print(_.toString());
      emit(CelebritiesInCategoryLoadError());
    }
  }


  void getCelebritiesInCategoryNext(Category category) async {
    if (_celebritiesInCategoryLoadSuccess != null &&
        _celebritiesInCategoryLoadSuccess is CelebritiesInCategoryLoadSuccess) {
      emit(CelebritiesInCategoryLoading());
      try {
        CelebrityListResponse celebrities = await _repository.getCelebritiesInCategory(
            offset: _celebritiesInCategoryLoadSuccess.celebrities.length,category: category);
          if (celebrities.celebrities.length > 0) {
            emit(CelebritiesInCategoryLoadSuccess(
                (_celebritiesInCategoryLoadSuccess != null
                    ? _celebritiesInCategoryLoadSuccess.celebrities
                    : List<Celebrity>()) +
                    celebrities.celebrities));
            _celebritiesInCategoryLoadSuccess = state;
          } else {
            emit(
                CelebritiesInCategoryLoadEmpty(_celebritiesInCategoryLoadSuccess.celebrities));
          }

      } catch (e) {
        emit(CelebritiesInCategoryLoadError());
        print(e);
      }
    } else
      emit(CelebritiesInCategoryLoadEmpty(null));
  }

}
