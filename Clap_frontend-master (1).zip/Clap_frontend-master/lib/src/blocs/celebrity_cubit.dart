import 'package:bloc/bloc.dart';
import 'package:clap/src/models/categories_response.dart';
import 'package:clap/src/models/celebrity.dart';
import 'package:clap/src/resources/repository.dart';
import 'package:equatable/equatable.dart';

part 'celebrity_state.dart';

class CelebrityCubit extends Cubit<CelebrityState> {
  CelebrityCubit() : super(CelebrityInitial());

  final Repository _repository = Repository();

  void getCelebrityDetail(Celebrity celebrity) async {
    emit(CelebrityLoading());
    try {
      Celebrity celebrityResponse = await _repository.getCelebrityDetail(celebrity);
      if (celebrityResponse!=null) {
        emit(CelebrityLoadSuccess(celebrityResponse));
      } else {
        emit(CelebrityLoadEmpty());
      }
    } catch (_) {
      emit(CelebrityLoadError());
    }
  }

  void saveCelebrityActionState({Celebrity celebrity,String actionType,String authType}) async{
    emit(CelebrityActionStateSaving());
   await _repository.saveActionStateCelebrity(celebrity);
   await _repository.saveActionType(actionType);
   emit(CelebrityActionStateSaved(celebrity, actionType,authType));
  }

  void clearCelebrityActionState() async{
    await _repository.saveActionStateCelebrity(null);
    await _repository.saveActionType(null);
  }
}
