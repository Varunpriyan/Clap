import 'package:bloc/bloc.dart';
import 'package:clap/src/models/search_response.dart';
import 'package:clap/src/resources/repository.dart';
import 'package:equatable/equatable.dart';

part 'search_state.dart';

class SearchCubit extends Cubit<SearchState> {
  SearchCubit() : super(SearchInitial());
  final Repository _repository = Repository();

  void search(query) async {
    emit(SearchLoading());
    try {
      SearchResponse searchResponse = await _repository.search(query:query);
      if (searchResponse.celebrities.length>0||searchResponse.categories.length>0) {
        emit(SearchLoadSuccess(searchResponse));
      } else {
        emit(SearchLoadEmpty());
      }
    } catch (_) {
      emit(SearchLoadError());
    }
  }
}
