import 'package:clap/src/models/analytics_response.dart';
import 'package:clap/src/models/celebrity.dart';
import 'package:clap/src/models/models.dart';
import 'package:clap/src/models/profile_response.dart';
import 'package:clap/src/models/success.dart';
import 'package:clap/src/models/user.dart';
import 'package:clap/src/resources/repository.dart';
import 'package:clap/src/utils/validator.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:hydrated_bloc/hydrated_bloc.dart';
import 'package:clap/src/models/portfolio_upload_response.dart';
import 'dart:io';
part 'profile_state.dart';


class ProfileCubit extends Cubit<ProfileState> {
  ProfileCubit() : super(ProfileInitial());
  final Repository _repository = Repository();

  void getProfile({bool showLoader = false}) async {
    try {
      if(showLoader)
        emit(ProfileLoading());
      Profile profile = await _repository.getUser();
      if (profile != null) {
        emit(ProfileLoadSuccess(profile));
      } else {
        emit(ProfileError("Something went wrong"));
      }
    } catch (_) {
      print("exe"+_.toString());
      emit(ProfileError("Something went wrong"));
    }
  }

  void updateProfile({String name, String email,int age,String gender,String height,String weight,String complexion,String hairColor,String aboutMe,bool isCreate = false}) async {
    emit(ProfileBusy());
    if (validateFields(name: name, email: email,age: age,gender: gender,height: height,weight: weight,complexion: complexion,hairColor: hairColor,aboutMe: aboutMe,isCreate:isCreate)) {
      try{
        Profile response = await _repository.updateProfile(name: name, email: email,age: age,gender: gender,height: height,
            weight: weight,complexion: complexion,hairColor: hairColor,aboutMe: aboutMe,isCreate: isCreate);
        if (response.success) {
          _repository.saveUserFromProfile(response);
          Celebrity celebrity = await _repository.getActionStateCelebrity();
          String actionType = await _repository.getActionType();
          ActionState actionState = celebrity!=null ? ActionState(celebrity: celebrity,actionType: actionType) : null;
          emit(ProfileSuccess(actionState: actionState));
        } else {
          emit(ProfileError(response.email));
        }}catch(e){
        emit(ProfileError(e.message));
      }
    }
  }

  bool validateFields({String name, String email,int age,String gender,String height,String weight,String complexion,String hairColor,String aboutMe, bool isCreate}) {
    if (name == null || name.isEmpty || !Validator.validateName(name)) {
      emit(ProfileValidationError(1));
      return false;
    }
    if (email == null || email.isEmpty || !Validator.validateMail(email)) {
      emit(ProfileValidationError(2));
      return false;
    }
    if(!isCreate){
      if (age == null  || age==0) {
        emit(ProfileValidationError(3));
        return false;
      }
      if (gender == null || gender.isEmpty ) {
        emit(ProfileValidationError(4));
        return false;
      }
      if (height == null || height.isEmpty ) {
        emit(ProfileValidationError(5));
        return false;
      }
      if (weight == null || weight.isEmpty) {
        emit(ProfileValidationError(6));
        return false;
      }
      if (complexion == null || complexion.isEmpty) {
        emit(ProfileValidationError(7));
        return false;
      }
      if (hairColor == null || hairColor.isEmpty) {
        emit(ProfileValidationError(8));
        return false;
      }
      if (aboutMe == null || aboutMe.isEmpty) {
        emit(ProfileValidationError(9));
        return false;
      }
    }
    return true;
  }

  void logout() async{
   await _repository.logoutUser();
   await  _repository.logoutFromFirebase();
   await  _repository.saveSkipLoginStatus(false);
   emit(ProfileInitial());
  }

  void getProfileFromCache() async {
    try {
      Profile profile = await _repository.getUserFromCache();
      if (profile != null) {
        emit(ProfileLoadSuccess(profile));
      } else {
        emit(ProfileError("Something went wrong"));
      }
    } catch (_) {
      emit(ProfileError("Something went wrong"));
    }
  }


  void updateProfilePicture({String path}) async {
    emit(ProfileBusy());
      try{
        Profile response = await _repository.updateProfilePicture(path: path);
        if (response.success) {
          _repository.saveUserFromProfile(response);
          emit(ProfileSuccess(actionState: null));
        } else {
          emit(ProfileError(response.email));
        }}catch(e){
        emit(ProfileError(e.message));
      }
  }

  void addPortfolio({List<File> files}) async {
    emit(ProfilePortfolioBusy());
    try{
      PortfolioUploadResponse response = await _repository.addPortfolio(files: files,onProgress: (progress){
        emitUploadProgress(progress: progress);
      });
      if (response.success) {
        emit(ProfilePortfolioSuccess(portfolioUploadResponse: response));
      } else {
        emit(ProfilePortfolioError(response.error));
      }}catch(e){
      print(e.toString());
      emit(ProfilePortfolioError(e.toString()));
    }
  }

  void deletePortfolio({String type,int id}) async {
    emit(ProfilePortfolioDeleteBusy());
    try{
      bool response = await _repository.deletePortfolio(id: id);
      if (response) {
        emit(ProfilePortfolioDeleteSuccess(type: type,id: id));
      } else {
        emit(ProfilePortfolioDeleteError("Error occurred! Try again."));
      }}catch(e){
      emit(ProfilePortfolioError(e.message));
    }
  }

  void getAnalytics() async {
    try {
      emit(ProfileAnalyticsLoading());
      AnalyticsResponse analytics = await _repository.getAnalytics();
      if (analytics != null) {
        emit(ProfileAnalyticsLoadSuccess(analytics));
      } else {
        emit(ProfileAnalyticsLoadError("Something went wrong"));
      }
    } catch (_) {
      emit(ProfileAnalyticsLoadError("Something went wrong"));
    }
  }


  void deleteProfile() async {
    emit(ProfileDeleteBusy());
    try{
      bool response = await _repository.deleteProfile();
      if (response) {
        emit(ProfileDeleteSuccess());
      } else {
        emit(ProfileDeleteError());
      }}catch(e){
      emit(ProfileDeleteError());
    }
  }

  void emitUploadProgress({int progress}){
    emit(ProfilePortfolioBusyProgress(progress: progress));
  }
}
