part of 'category_cubit.dart';

abstract class CategoryState extends Equatable {
  const CategoryState();
}

class CategoryInitial extends CategoryState {
  @override
  List<Object> get props => [];
}


class CategoryLoading extends CategoryState {
  @override
  List<Object> get props => [];
}

class CategoryLoadSuccess extends CategoryState {
  final List<Category> categories;

  CategoryLoadSuccess(this.categories);

  @override
  List<Object> get props => [categories];
}


class CategoryLoadEmpty extends CategoryState {
  @override
  List<Object> get props => [];
}

class CategoryLoadError extends CategoryState {
  @override
  List<Object> get props => [];
}

class CategoryBusy extends CategoryState {
  @override
  List<Object> get props => [];
}


//////////// celebrities in category


class CelebritiesInCategoryLoading extends CategoryState {
  @override
  List<Object> get props => [];
}

class CelebritiesInCategoryLoadSuccess extends CategoryState {
  final List<Celebrity> celebrities;

  CelebritiesInCategoryLoadSuccess(this.celebrities);

  @override
  List<Object> get props => [celebrities];
}


class CelebritiesInCategoryLoadEmpty extends CategoryState {
  final List<Celebrity> celebrities;

  CelebritiesInCategoryLoadEmpty(this.celebrities);
  @override
  List<Object> get props => [celebrities];
}

class CelebritiesInCategoryLoadError extends CategoryState {
  @override
  List<Object> get props => [];
}
