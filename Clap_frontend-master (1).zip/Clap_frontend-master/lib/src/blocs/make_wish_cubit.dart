import 'package:bloc/bloc.dart';
import 'package:clap/src/models/make_wish_response.dart';
import 'package:clap/src/models/models.dart';
import 'package:clap/src/models/occasion_response.dart';
import 'package:clap/src/models/payment.dart';
import 'package:clap/src/resources/repository.dart';
import 'package:clap/src/utils/validator.dart';
import 'package:equatable/equatable.dart';

part 'make_wish_state.dart';

class MakeWishCubit extends Cubit<MakeWishState> {
  MakeWishCubit() : super(MakeWishInitial());
  final Repository _repository = Repository();


  void validateInput({String introduction,Occasion occasion,String instruction}) async {
    emit(MakeWishBusy());
    if (validateInputFields(introduction: introduction,occasion: occasion,instruction: instruction)) {
      emit(MakeWishValidationSuccess());
    }
  }
  bool validateInputFields({String introduction,Occasion occasion,String instruction}) {
    if (introduction == null || introduction.isEmpty) {
      emit(MakeWishValidationError(1));
      return false;
    }
    if (occasion == null) {
      emit(MakeWishValidationError(2));
      return false;
    }
    if (instruction == null || instruction.isEmpty) {
      emit(MakeWishValidationError(3));
      return false;
    }
    return true;
  }


  void makeWish({
    MakeWish makeWish,
    String phone,
    String email,
  }) async {
    emit(MakeWishBusy());
    if (validateFields(mobile: phone,email: email)) {
      try {
        MakeWishResponse response =
        await _repository.makeWish(makeWish,phone,email);
        if (response.success) {
          emit(MakeWishSuccess(response, makeWish));
        } else {
          emit(MakeWishError());
        }
      } catch (_) {
        print(_.toString());
        emit(MakeWishError());
      }
    }
  }

  void updatePayment(MakeWishResponse makeWishResponse, String paymentId,
      String amount) async {
    emit(PaymentUpdating());
    try {
      PaymentResponse response = await _repository.updatePayment(
          orderId: makeWishResponse.order,
          paymentId: paymentId,
          paymentStatus: 'Payment Success',
          amount: amount);
      if (response.success) {
        makeWishResponse.paymentStatus = true;
        emit(PaymentUpdateSuccess(makeWishResponse));
      } else {
        emit(PaymentUpdateFailed(makeWishResponse));
      }
    } catch (_) {
      emit(PaymentUpdateError(makeWishResponse));
    }
  }

  bool validateFields({String mobile,String email}) {
    if (((mobile == null || mobile.isEmpty)||(email == null || email.isEmpty))) {
      emit(MakeWishValidationError(1));
      return false;
    }
    if(mobile.isNotEmpty){
      if (!Validator.validateMobile(mobile)) {
        emit(MakeWishValidationError(2));
        return false;
      }
    }

    if(email.isNotEmpty){
      if (!Validator.validateMail(email)) {
        emit(MakeWishValidationError(3));
        return false;
      }
    }
    return true;
  }
}
