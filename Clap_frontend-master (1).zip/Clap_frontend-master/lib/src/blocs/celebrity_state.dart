part of 'celebrity_cubit.dart';

abstract class CelebrityState extends Equatable {
  const CelebrityState();
}

class CelebrityInitial extends CelebrityState {
  @override
  List<Object> get props => [];
}


class CelebrityLoading extends CelebrityState {
  @override
  List<Object> get props => [];
}

class CelebrityLoadSuccess extends CelebrityState {
  final Celebrity celebrity;

  CelebrityLoadSuccess(this.celebrity);

  @override
  List<Object> get props => [celebrity];
}


class CelebrityLoadEmpty extends CelebrityState {
  @override
  List<Object> get props => [];
}

class CelebrityLoadError extends CelebrityState {
  @override
  List<Object> get props => [];
}


class CelebrityActionStateSaving extends CelebrityState {
  @override
  List<Object> get props => [];
}

class CelebrityActionStateSaved extends CelebrityState {
  final Celebrity celebrity;
  final String type;
  final String authType;

  CelebrityActionStateSaved(this.celebrity, this.type,this.authType);
  @override
  List<Object> get props => [celebrity,type];
}
