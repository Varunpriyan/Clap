import 'package:bloc/bloc.dart';
import 'package:clap/src/models/audition_response.dart';
import 'package:clap/src/models/audition_apply_response.dart';
import 'package:clap/src/models/applied_auditions_response.dart';
import 'package:clap/src/resources/repository.dart';
import 'package:equatable/equatable.dart';

part 'audition_state.dart';

class AuditionCubit extends Cubit<AuditionState> {
  AuditionCubit() : super(AuditionInitial());

  final Repository _repository = Repository();
  AuditionLoadSuccess _currentAuditionLoadSuccessState;
  AuditionAppliedLoadSuccess _currentAuditionAppliedLoadSuccessState;

  void getAllAudition() async {
    _currentAuditionLoadSuccessState = null;
    emit(AuditionLoading());
    try {
      AuditionResponse response = await _repository.getAllAudition();
      if (response.success) {
        if (response.auditions.length > 0) {
          emit(AuditionLoadSuccess(response.auditions));
          _currentAuditionLoadSuccessState = state;
        } else
          emit(AuditionLoadEmpty(null));
      } else {
        emit(AuditionLoadError());
      }
    } catch (e) {
      print(e.toString());
      emit(AuditionLoadError());
    }
  }

  void getAllAuditionNext() async {
    if (_currentAuditionLoadSuccessState != null &&
        _currentAuditionLoadSuccessState is AuditionLoadSuccess) {
      emit(AuditionLoading());
      try {
        AuditionResponse response = await _repository.getAllAudition(
            offset: _currentAuditionLoadSuccessState.auditions.length);
        if (response.success) {
          if (response.auditions.length > 0) {
            emit(AuditionLoadSuccess(
                (_currentAuditionLoadSuccessState != null
                    ? _currentAuditionLoadSuccessState.auditions
                    : List<Audition>()) +
                    response.auditions));
            _currentAuditionLoadSuccessState = state;
          } else {
            emit(
                AuditionLoadEmpty(_currentAuditionLoadSuccessState.auditions));
          }
        } else {
          emit(AuditionLoadError());
        }
      } catch (e) {
        emit(AuditionLoadError());
        print(e);
      }
    } else
      emit(AuditionLoadEmpty(null));
  }

  void getAuditionDetails(int audition) async {
    emit(AuditionDetailsLoading());
    try {
      Audition response =
      await _repository.getAuditionDetails(audition);
      if (response != null) {
        emit(AuditionDetailsLoadSuccess(response));
      } else
        emit(AuditionDetailsLoadEmpty());

    } catch (e) {
      emit(AuditionDetailsLoadError());
    }
  }

  void submitApplication({List<String> path,int audition}) async {
    emit(AuditionApplyBusy());
    try{
      AuditionApplyResponse response = await _repository.submitApplication(path: path,audition: audition);
      if (response.success) {
        emit(AuditionApplySuccess(message:"Applied successfully!"));
      } else {
        emit(AuditionApplyError("Failed to apply! try again."));
      }}catch(e){
      emit(AuditionApplyError(e.toString()));
    }
  }


  /// applied
///
  void getAppliedAuditions() async {
    _currentAuditionAppliedLoadSuccessState = null;
    emit(AuditionLoading());
    try {
      AppliedAuditionsResponse response = await _repository.getAppliedAuditions();
      if (response.success) {
        if (response.applications.length > 0) {
          emit(AuditionAppliedLoadSuccess(response.applications));
          _currentAuditionAppliedLoadSuccessState = state;
        } else
          emit(AuditionAppliedLoadEmpty(null));
      } else {
        emit(AuditionAppliedLoadError());
      }
    } catch (e) {
      print(e.toString());
      emit(AuditionAppliedLoadError());
    }
  }

  void getAppliedAuditionsNext() async {
    if (_currentAuditionAppliedLoadSuccessState != null &&
        _currentAuditionAppliedLoadSuccessState is AuditionAppliedLoadSuccess) {
      emit(AuditionLoading());
      try {
        AppliedAuditionsResponse response = await _repository.getAppliedAuditions(
            offset: _currentAuditionAppliedLoadSuccessState.applications.length);
        if (response.success) {
          if (response.applications.length > 0) {
            emit(AuditionAppliedLoadSuccess(
                (_currentAuditionAppliedLoadSuccessState != null
                    ? _currentAuditionAppliedLoadSuccessState.applications
                    : List<Application>()) +
                    response.applications));
            _currentAuditionAppliedLoadSuccessState = state;
          } else {
            emit(
                AuditionAppliedLoadEmpty(_currentAuditionAppliedLoadSuccessState.applications));
          }
        } else {
          emit(AuditionAppliedLoadError());
        }
      } catch (e) {
        emit(AuditionAppliedLoadError());
        print(e);
      }
    } else
      emit(AuditionAppliedLoadEmpty(null));
  }
}
