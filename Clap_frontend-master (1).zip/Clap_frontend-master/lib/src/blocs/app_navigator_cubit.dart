import 'package:bloc/bloc.dart';
import 'package:clap/src/models/categories_response.dart';
import 'package:clap/src/models/celebrity.dart';
import 'package:clap/src/models/models.dart';
import 'package:clap/src/models/profile_response.dart';
import 'package:clap/src/utils/constants.dart';
import 'package:equatable/equatable.dart';
import 'package:firebase_auth/firebase_auth.dart';


part 'app_navigator_state.dart';

class AppNavigatorCubit extends Cubit<AppNavigatorState> {
  AppNavigatorCubit() : super(AppNavigatorInitial());

  routeToLogin(bool isRegister,bool isLater) {
    emit(AppNavigatorLogin(isRegister,isLater: isLater));
    emit(AppNavigatorInitial());
  }

  routeToIntro() {
    emit(AppNavigatorIntro());
  }

  routeToOtpVerification(OtpData data) {
    emit(AppNavigatorOtpVerification(data));
    emit(AppNavigatorInitial());
  }

  routeToContact() {
    emit(AppNavigatorContact());
    emit(AppNavigatorInitial());
  }


  routeToTermsConditions() {
    emit(AppNavigatorTermsConditions());
    emit(AppNavigatorInitial());
  }

  routeToHome({bool showComplete = false}) {
    emit(AppNavigatorHome(showComplete ?? false));
    emit(AppNavigatorInitial());
  }

  routeToCreateProfile() {
    emit(AppNavigatorCreateProfile());
    emit(AppNavigatorInitial());
  }

  routeToCelebrityListByCategory(Category category) {
    emit(AppNavigatorCelebrityListByCategory(category));
    emit(AppNavigatorInitial());
  }

  routeToCelebrityDetail(Celebrity celebrity) {
    emit(AppNavigatorCelebrityDetail(celebrity));
    emit(AppNavigatorInitial());
  }

  routeToAskQuestion(Celebrity celebrity,{bool isLater=false}) {
    emit(AppNavigatorAskQuestion(celebrity,isLater));
    emit(AppNavigatorInitial());
  }

  routeToAskQuestionConfirm(AskQuestion askQuestion) {
    emit(AppNavigatorAskQuestionConfirm(askQuestion));
    emit(AppNavigatorInitial());
  }

  routeToMakeWishWhoFor(Celebrity celebrity,{bool isLater=false}) {
    emit(AppNavigatorMakeWishWhoFor(celebrity,isLater));
    emit(AppNavigatorInitial());
  }

  routeToMakeWishInputDetails(MakeWish makeWish) {
    emit(AppNavigatorMakeWishInputDetails(makeWish));
    emit(AppNavigatorInitial());
  }

  routeToMakeWishOccasion(MakeWish makeWish) {
    emit(AppNavigatorMakeWishOccasion(makeWish));
    emit(AppNavigatorInitial());
  }

  routeToMakeWishConfirm(MakeWish makeWish) {
    emit(AppNavigatorMakeWishConfirm(makeWish));
    emit(AppNavigatorInitial());
  }

  routeToPaymentStatus(int order,bool status) {
    emit(AppNavigatorPaymentStatus(order,status));
    emit(AppNavigatorInitial());
  }

  routeToOrderDetail(int order) {
    emit(AppNavigatorOrderDetail(order));
    emit(AppNavigatorInitial());
  }

  routeToOrders() {
    emit(AppNavigatorOrders());
    emit(AppNavigatorInitial());
  }

  routeToSearch(String query) {
    emit(AppNavigatorSearch(query));
    emit(AppNavigatorInitial());
  }

  routeToLaterAuth(Celebrity celebrity,String type) {
    emit(AppNavigatorLaterAuth(celebrity,type));
    emit(AppNavigatorInitial());
  }

  // phase 2

  routeToProfileEdit({Profile profile}) {
    emit(AppNavigatorProfileEdit(profile));
    emit(AppNavigatorInitial());
  }
  routeToAuditions() {
    emit(AppNavigatorAuditions());
    emit(AppNavigatorInitial());
  }
  routeToAuditionStatus() {
    emit(AppNavigatorAuditionStatus());
    emit(AppNavigatorInitial());
  }
  routeToAuditionDetail({int audition}) {
    emit(AppNavigatorAuditionDetail(audition));
    emit(AppNavigatorInitial());
  }
}
