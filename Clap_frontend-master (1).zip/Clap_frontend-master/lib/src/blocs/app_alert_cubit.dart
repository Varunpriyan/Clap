import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

part 'app_alert_state.dart';

class AppAlertCubit extends Cubit<AppAlertState> {
  AppAlertCubit() : super(AppAlertInitial());

  void showSnackBar(String message) {
    emit(AppAlertShowSnackBar(message));
    emit(AppAlertInitial());
  }
}
