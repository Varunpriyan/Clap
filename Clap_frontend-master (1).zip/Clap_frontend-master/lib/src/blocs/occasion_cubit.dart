import 'package:bloc/bloc.dart';
import 'package:clap/src/models/occasion_response.dart';
import 'package:clap/src/resources/repository.dart';
import 'package:equatable/equatable.dart';

part 'occasion_state.dart';

class OccasionCubit extends Cubit<OccasionState> {
  OccasionCubit() : super(OccasionInitial());

  final Repository _repository = Repository();

  void getOccasions() async {
    emit(OccasionLoading());
    try {
      OccasionResponse occasionResponse = await _repository.getOccasions();
      if (occasionResponse.occasions.length>0) {
        emit(OccasionLoadSuccess(occasionResponse.occasions));
      } else {
        emit(OccasionLoadEmpty());
      }
    } catch (_) {
      emit(OccasionLoadError());
    }
  }
}
