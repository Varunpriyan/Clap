part of 'occasion_cubit.dart';

abstract class OccasionState extends Equatable {
  const OccasionState();
}

class OccasionInitial extends OccasionState {
  @override
  List<Object> get props => [];
}


class OccasionLoading extends OccasionState {
  @override
  List<Object> get props => [];
}

class OccasionLoadSuccess extends OccasionState {
  final List<Occasion> occasions;

  OccasionLoadSuccess(this.occasions);

  @override
  List<Object> get props => [occasions];
}


class OccasionLoadEmpty extends OccasionState {
  @override
  List<Object> get props => [];
}

class OccasionLoadError extends OccasionState {
  @override
  List<Object> get props => [];
}

class OccasionBusy extends OccasionState {
  @override
  List<Object> get props => [];
}
