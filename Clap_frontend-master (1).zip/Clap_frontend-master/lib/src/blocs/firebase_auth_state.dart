part of 'firebase_auth_cubit.dart';

abstract class FirebaseAuthState extends Equatable {
  const FirebaseAuthState();
}

class FirebaseAuthInitial extends FirebaseAuthState {
  @override
  List<Object> get props => [];
}

class InvalidMobile extends FirebaseAuthState {
  @override
  List<Object> get props => [];
}

class PhoneVerificationInProgress extends FirebaseAuthState {
  @override
  List<Object> get props => [];
}

///[PhoneVerificationSuccess] state is to show
///mobile number has been verified automatically/programmatically
class PhoneVerificationSuccess extends FirebaseAuthState {
  final User user;

  PhoneVerificationSuccess(this.user);

  @override
  List<Object> get props => [user];
}

class PhoneVerificationFailure extends FirebaseAuthState {
  @override
  List<Object> get props => [];
}

class OtpVerificationInProgress extends FirebaseAuthState {
  @override
  List<Object> get props => [];
}

class OtpVerificationSuccess extends FirebaseAuthState {
  final User user;

  OtpVerificationSuccess(this.user);

  @override
  List<Object> get props => [user];
}

class OtpVerificationFailure extends FirebaseAuthState {
  @override
  List<Object> get props => [];
}

///[OtpSent] state is to show Firebase sent otp to the user number,
///[verificationId] which can further used to verify code/otp
class OtpSent extends FirebaseAuthState {
  final String verificationId;
  final String mobile;

  OtpSent({this.verificationId,this.mobile});

  @override
  List<Object> get props => [verificationId,mobile];
}
