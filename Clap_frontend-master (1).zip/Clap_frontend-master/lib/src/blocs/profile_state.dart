part of 'profile_cubit.dart';

abstract class ProfileState extends Equatable {
  const ProfileState();
}

class ProfileInitial extends ProfileState {
  @override
  List<Object> get props => [];
}

class ProfileLoading extends ProfileState {
@override
List<Object> get props => [];
}

class ProfileLoadSuccess extends ProfileState {
  final Profile profile;

  ProfileLoadSuccess(this.profile);

  @override
  List<Object> get props => [profile];
}


class ProfileLoadEmpty extends ProfileState {
  @override
  List<Object> get props => [];
}

class ProfileLoadError extends ProfileState {
  @override
  List<Object> get props => [];
}

class ProfileBusy extends ProfileState {
  @override
  List<Object> get props => [];
}

class ProfileValidationError extends ProfileState {
  final  int field;

  ProfileValidationError(this.field);

  @override
  List<Object> get props => [field];
}

class ProfileSuccess extends ProfileState {
  final  String message;
  final ActionState actionState;
  ProfileSuccess({this.message="",this.actionState});
  @override
  List<Object> get props => [message,actionState];
}


class ProfileError extends ProfileState {
  final String msg;
  ProfileError(this.msg);
  @override
  List<Object> get props => [msg];
}

class ProfilePictureSuccess extends ProfileState {
  final  String message;
  final  String image;

  ProfilePictureSuccess(this.image,{this.message=""});
  @override
  List<Object> get props => [message,image];
}


/// profile portfolio
///
class ProfilePortfolioBusy extends ProfileState {
  @override
  List<Object> get props => [];
}

class ProfilePortfolioBusyProgress extends ProfileState {
  final int progress;

  ProfilePortfolioBusyProgress({this.progress = 0});
  @override
  List<Object> get props => [progress];
}
class ProfilePortfolioSuccess extends ProfileState {
  final  String message;
  final PortfolioUploadResponse portfolioUploadResponse;
  ProfilePortfolioSuccess({this.message="",this.portfolioUploadResponse});
  @override
  List<Object> get props => [message,portfolioUploadResponse];
}


class ProfilePortfolioError extends ProfileState {
  final String msg;
  ProfilePortfolioError(this.msg);
  @override
  List<Object> get props => [msg];
}


class ProfilePortfolioDeleteBusy extends ProfileState {
  @override
  List<Object> get props => [];
}
class ProfilePortfolioDeleteSuccess extends ProfileState {
  final  String type;
  final int id;
  ProfilePortfolioDeleteSuccess({this.type,this.id});
  @override
  List<Object> get props => [type,id];
}


class ProfilePortfolioDeleteError extends ProfileState {
  final String msg;
  ProfilePortfolioDeleteError(this.msg);
  @override
  List<Object> get props => [msg];
}



/// analytics

class ProfileAnalyticsLoading extends ProfileState {
  @override
  List<Object> get props => [];
}

class ProfileAnalyticsLoadSuccess extends ProfileState {
  final AnalyticsResponse analytics;

  ProfileAnalyticsLoadSuccess(this.analytics);

  @override
  List<Object> get props => [analytics];
}

class ProfileAnalyticsLoadError extends ProfileState {
  final String msg;
  ProfileAnalyticsLoadError(this.msg);
  @override
  List<Object> get props => [msg];
}


class ProfileDeleteBusy extends ProfileState {
  @override
  List<Object> get props => [];
}
class ProfileDeleteSuccess extends ProfileState {
  ProfileDeleteSuccess();
  @override
  List<Object> get props => [];
}


class ProfileDeleteError extends ProfileState {
  ProfileDeleteError();
  @override
  List<Object> get props => [];
}