part of 'app_alert_cubit.dart';

abstract class AppAlertState extends Equatable {
  const AppAlertState();
}

class AppAlertInitial extends AppAlertState {
  @override
  List<Object> get props => [];
}

class AppAlertShowSnackBar extends AppAlertState {
  final String message;

  AppAlertShowSnackBar(this.message);

  @override
  List<Object> get props => [message];
}
