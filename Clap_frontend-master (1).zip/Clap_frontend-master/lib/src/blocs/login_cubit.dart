import 'package:bloc/bloc.dart';
import 'package:clap/src/models/celebrity.dart';
import 'package:clap/src/models/models.dart';
import 'package:clap/src/models/profile_response.dart';
import 'package:clap/src/resources/repository.dart';
import 'package:clap/src/utils/validator.dart';
import 'package:equatable/equatable.dart';
import 'package:firebase_auth/firebase_auth.dart';
part 'login_state.dart';

class LoginCubit extends Cubit<LoginState> {
  LoginCubit() : super(LoginInitial());
  final Repository _repository = Repository();
  void saveUser(User user) async {
    emit(LoginBusy());
    try{
      if (user != null) {
        ///Saves user credential, this will keep user session active
        await _repository.saveUser(user);
        Profile profile = await _repository.getUser();
        await _repository.saveUserFromProfile(profile);
        Celebrity celebrity = await _repository.getActionStateCelebrity();
        String actionType = await _repository.getActionType();

        ActionState actionState = celebrity!=null ? ActionState(celebrity: celebrity,actionType: actionType) : null;
        print('got below');

        emit(LoginSuccess(user,profile.displayName==""||profile.displayName==null,actionState,profile.isCompleted));
      } else {
        emit(LoginError());
      }
    }catch(_){
      print(_.toString());
      emit(LoginError());
    }

  }


  void checkPhoneNumber(String mobile) async{
    emit(LoginBusy());
    try{
      bool status = await _repository.checkPhoneNUmber(mobile);
      emit(LoginPhoneCheckSuccess(status));
    }catch(_){
      print(_.toString());
      emit(LoginPhoneError());
    }

  }


}
