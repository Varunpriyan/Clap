part of 'audition_cubit.dart';

abstract class AuditionState extends Equatable {
  const AuditionState();
}

class AuditionInitial extends AuditionState {
  @override
  List<Object> get props => [];
}


class AuditionLoading extends AuditionState {
  @override
  List<Object> get props => [];
}

class AuditionLoadSuccess extends AuditionState {
  final List<Audition> auditions;

  AuditionLoadSuccess(this.auditions);

  @override
  List<Object> get props => [auditions];
}

class AuditionLoadEmpty extends AuditionState {
  final List<Audition> auditions;

  AuditionLoadEmpty(this.auditions);

  @override
  List<Object> get props => [auditions];
}

class AuditionLoadError extends AuditionState {
  @override
  List<Object> get props => [];
}



class AuditionDetailsLoading extends AuditionState {
  @override
  List<Object> get props => [];
}

class AuditionDetailsLoadSuccess extends AuditionState {
  final Audition audition;

  AuditionDetailsLoadSuccess(this.audition);

  @override
  List<Object> get props => [audition];
}

class AuditionDetailsLoadEmpty extends AuditionState {
  @override
  List<Object> get props => [];
}

class AuditionDetailsLoadError extends AuditionState {
  @override
  List<Object> get props => [];
}



class AuditionApplyBusy extends AuditionState {
  @override
  List<Object> get props => [];
}

class AuditionApplySuccess extends AuditionState {
  final  String message;
  AuditionApplySuccess({this.message=""});
  @override
  List<Object> get props => [message];
}

class AuditionApplyError extends AuditionState {
  final String msg;
  AuditionApplyError(this.msg);
  @override
  List<Object> get props => [msg];
}


/////////////////////  applied


class AuditionAppliedLoadSuccess extends AuditionState {
  final List<Application> applications;

  AuditionAppliedLoadSuccess(this.applications);

  @override
  List<Object> get props => [applications];
}

class AuditionAppliedLoadEmpty extends AuditionState {
  final List<Application> applications;

  AuditionAppliedLoadEmpty(this.applications);

  @override
  List<Object> get props => [applications];
}

class AuditionAppliedLoadError extends AuditionState {
  @override
  List<Object> get props => [];
}