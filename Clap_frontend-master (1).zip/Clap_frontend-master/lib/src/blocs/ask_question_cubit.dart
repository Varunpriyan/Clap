import 'package:bloc/bloc.dart';
import 'package:clap/src/models/ask_question.dart';
import 'package:clap/src/models/celebrity.dart';
import 'package:clap/src/models/payment.dart';
import 'package:clap/src/models/profile_response.dart';
import 'package:clap/src/resources/repository.dart';
import 'package:clap/src/utils/validator.dart';
import 'package:equatable/equatable.dart';

part 'ask_question_state.dart';

class AskQuestionCubit extends Cubit<AskQuestionState> {
  AskQuestionCubit() : super(AskQuestionInitial());
  final Repository _repository = Repository();

  void askQuestion({
    Celebrity celebrity,
    String question,
    String phone,
    String email,
  }) async {
    emit(AskQuestionBusy());
    if (validateFields(mobile: phone,email: email)) {
      try {
        AskQuestionResponse response =
            await _repository.askQuestion(celebrity, question,phone,email);
        if (response.success) {
          Profile user = await _repository.getUserFromCache();
          emit(AskQuestionSuccess(response, user));
        } else {
          emit(AskQuestionError());
        }
      } catch (_) {
        print(_.toString());
        emit(AskQuestionError());
      }
    }
  }

  void updatePayment(AskQuestionResponse askQuestionResponse, String paymentId,
      String amount) async {
    emit(PaymentUpdating());
    print('send start');
    try {
      PaymentResponse response = await _repository.updatePayment(
          orderId: askQuestionResponse.order,
          paymentId: paymentId,
          paymentStatus: 'Payment Success',
          amount: amount);
      if (response.success) {
        askQuestionResponse.paymentStatus = true;
        emit(PaymentUpdateSuccess(askQuestionResponse));
      } else {
        emit(PaymentUpdateFailed(askQuestionResponse));
      }
    } catch (_) {
      emit(PaymentUpdateError(askQuestionResponse));
    }
  }

  bool validateFields({String mobile,String email}) {
    if (((mobile == null || mobile.isEmpty)||(email == null || email.isEmpty))) {
      emit(AskQuestionValidationError(1));
      return false;
    }
    if(mobile.isNotEmpty){
      if (!Validator.validateMobile(mobile)) {
        emit(AskQuestionValidationError(2));
        return false;
      }
    }

    if(email.isNotEmpty){
      if (!Validator.validateMail(email)) {
        emit(AskQuestionValidationError(3));
        return false;
      }
    }
    return true;
  }

  void validateQuestion({String question}) async {
    emit(AskQuestionBusy());
    if (validateFieldQuestion(question: question)) {
      Profile user = await _repository.getUserFromCache();
      emit(AskQuestionValidationSuccess(user));
    }
  }
  bool validateFieldQuestion({String question}) {
    if (question == null || question.isEmpty) {
      emit(AskQuestionValidationError(1));
      return false;
    }
    return true;
  }
}
