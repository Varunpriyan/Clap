part of 'login_cubit.dart';

abstract class LoginState extends Equatable {
  const LoginState();
}

class LoginInitial extends LoginState {
  @override
  List<Object> get props => [];
}

class LoginBusy extends LoginState {
  @override
  List<Object> get props => [];
}

class LoginValidationError extends LoginState {
  @override
  List<Object> get props => [];
}

class LoginSuccess extends LoginState {
  final User user;
  final bool registrationRequired;
  final ActionState actionState;
  final bool isComplete;

  LoginSuccess(this.user, this.registrationRequired,this.actionState, this.isComplete);

  @override
  List<Object> get props => [];
}

class LoginError extends LoginState {
  @override
  List<Object> get props => [];
}



class LoginPhoneCheckSuccess extends LoginState {
  final bool status;

  LoginPhoneCheckSuccess(this.status);

  @override
  List<Object> get props => [];
}

class LoginPhoneError extends LoginState {
  @override
  List<Object> get props => [];
}
