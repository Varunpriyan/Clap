part of 'app_navigator_cubit.dart';

abstract class AppNavigatorState extends Equatable {
  const AppNavigatorState();
}

class AppNavigatorInitial extends AppNavigatorState {
  @override
  List<Object> get props => [];
}

class AppNavigatorSplash extends AppNavigatorState {
  final String route = Constants.SPLASH_ROUTE;

  @override
  List<Object> get props => [route];
}

class AppNavigatorHome extends AppNavigatorState {
  final String route = Constants.HOME;
  final bool showComplete;

  AppNavigatorHome(this.showComplete);

  @override
  List<Object> get props => [route];
}

class AppNavigatorCreateProfile extends AppNavigatorState {
  final String route = Constants.CREATE_PROFILE;

  @override
  List<Object> get props => [route];
}

class AppNavigatorLogin extends AppNavigatorState {
  final String route = Constants.LOGIN;
  final bool isRegister;
  final bool isLater;

  AppNavigatorLogin(this.isRegister,{this.isLater=false});

  @override
  List<Object> get props => [route,isRegister,isLater];
}

class AppNavigatorIntro extends AppNavigatorState {
  final String route = Constants.INTRO;

  @override
  List<Object> get props => [route];
}

class AppNavigatorOtpVerification extends AppNavigatorState {
  final String route = Constants.OTP_VERIFICATION_ROUTE;
  final OtpData data;

  AppNavigatorOtpVerification(this.data);

  @override
  List<Object> get props => [route,data];
}

class AppNavigatorTermsConditions extends AppNavigatorState {
  final String route = Constants.TERMS_CONDITIONS_ROUTE;

  @override
  List<Object> get props => [route];
}

class AppNavigatorContact extends AppNavigatorState {
  final String route = Constants.CONTACT_ROUTE;

  @override
  List<Object> get props => [route];
}

class AppNavigatorCelebrityListByCategory extends AppNavigatorState {
  final String route = Constants.CELEBRITY_LIST_BY_CATEGORY;
  final Category category;

  AppNavigatorCelebrityListByCategory(this.category);

  @override
  List<Object> get props => [route,category];
}


class AppNavigatorCelebrityDetail extends AppNavigatorState {
  final String route = Constants.CELEBRITY_DETAIL_ROUTE;
  final Celebrity celebrity;

  AppNavigatorCelebrityDetail(this.celebrity);

  @override
  List<Object> get props => [route, celebrity];
}

class AppNavigatorAskQuestion extends AppNavigatorState {
  final String route = Constants.CELEBRITY_ASK_QUESTION;
  final Celebrity celebrity;
  final bool isLater;
  AppNavigatorAskQuestion(this.celebrity,this.isLater);

  @override
  List<Object> get props => [route, celebrity];
}

class AppNavigatorAskQuestionConfirm extends AppNavigatorState {
  final String route = Constants.CELEBRITY_ASK_QUESTION_CONFIRM;
  final AskQuestion askQuestion;

  AppNavigatorAskQuestionConfirm(this.askQuestion);

  @override
  List<Object> get props => [route, askQuestion];
}

class AppNavigatorMakeWishWhoFor extends AppNavigatorState {
  final String route = Constants.CELEBRITY_MAKE_WISH_WHO_FOR;
  final Celebrity celebrity;
  final bool isLater;

  AppNavigatorMakeWishWhoFor(this.celebrity,this.isLater);

  @override
  List<Object> get props => [route, celebrity];
}

class AppNavigatorMakeWishInputDetails extends AppNavigatorState {
  final String route = Constants.CELEBRITY_MAKE_WISH_INPUT_DETAILS;
  final MakeWish makeWish;

  AppNavigatorMakeWishInputDetails(this.makeWish);

  @override
  List<Object> get props => [route, makeWish];
}

class AppNavigatorMakeWishOccasion extends AppNavigatorState {
  final String route = Constants.CELEBRITY_MAKE_WISH_OCCASION;
  final MakeWish makeWish;
  AppNavigatorMakeWishOccasion(this.makeWish);

  @override
  List<Object> get props => [route, makeWish];
}

class AppNavigatorMakeWishConfirm extends AppNavigatorState {
  final String route = Constants.CELEBRITY_MAKE_WISH_CONFIRM;
  final MakeWish makeWish;

  AppNavigatorMakeWishConfirm(this.makeWish);

  @override
  List<Object> get props => [route, makeWish];
}

class AppNavigatorPaymentStatus extends AppNavigatorState {
  final String route = Constants.PAYMENT_STATUS;
  final String routeUntil = Constants.HOME;
  final int order;
  final bool status;

  AppNavigatorPaymentStatus(this.order,this.status);

  @override
  List<Object> get props => [route,order, status];
}

class AppNavigatorOrderDetail extends AppNavigatorState {
  final String route = Constants.ORDER_DETAIL;
  final int order;

  AppNavigatorOrderDetail(this.order);

  @override
  List<Object> get props => [route, order];
}

class AppNavigatorOrders extends AppNavigatorState {
  final String route = Constants.ORDERS_ROUTE;

  AppNavigatorOrders();

  @override
  List<Object> get props => [route];
}

class AppNavigatorSearch extends AppNavigatorState {
  final String route = Constants.SEARCH_ROUTE;
  final String query;

  AppNavigatorSearch(this.query);

  @override
  List<Object> get props => [route,query];
}

class AppNavigatorLaterAuth extends AppNavigatorState {
  final String route = Constants.LATER_AUTH;
  final Celebrity celebrity;
  final String type;

  AppNavigatorLaterAuth(this.celebrity,this.type);

  @override
  List<Object> get props => [route,celebrity,type];
}

// phase 2


class AppNavigatorProfileEdit extends AppNavigatorState {
  final String route = Constants.PROFILE_EDIT;
  final Profile profile;

  AppNavigatorProfileEdit(this.profile);

  @override
  List<Object> get props => [route,profile];
}

class AppNavigatorAuditions extends AppNavigatorState {
  final String route = Constants.AUDITIONS;

  AppNavigatorAuditions();

  @override
  List<Object> get props => [route];
}

class AppNavigatorAuditionStatus extends AppNavigatorState {
  final String route = Constants.AUDITION_STATUS;

  AppNavigatorAuditionStatus();

  @override
  List<Object> get props => [route];
}

class AppNavigatorAuditionDetail extends AppNavigatorState {
  final String route = Constants.AUDITION_DETAIL;
  final int audition;

  AppNavigatorAuditionDetail(this.audition);

  @override
  List<Object> get props => [route];
}

