library dropdown_formfield;

import 'package:clap/src/utils/app_config.dart';
import 'package:flutter/material.dart';
class SelectFormField extends FormField<dynamic> {
  final String titleText;
  final String hintText;
  final bool required;
  final String errorText;
  final dynamic value;
  final List dataSource;
  final List disabledDataSource;
  final String textField;
  final String valueField;
  final Function onChanged;
  final bool filled;
  final EdgeInsets contentPadding;

  SelectFormField(
      {FormFieldSetter<dynamic> onSaved,
        FormFieldValidator<dynamic> validator,
        bool autovalidate = false,
        this.titleText = 'Title',
        this.hintText = 'Select one option',
        this.required = false,
        this.errorText = 'Please select one option',
        this.value,
        this.dataSource,
        this.disabledDataSource,
        this.textField,
        this.valueField,
        this.onChanged,
        this.filled = true,
        this.contentPadding = const EdgeInsets.symmetric(vertical: 0,horizontal: 20)})
      : super(
    onSaved: onSaved,
    validator: validator,
    autovalidate: autovalidate,
    initialValue: value == '' ? null : value,
    builder: (FormFieldState<dynamic> state) {
      return Container(
        padding: const EdgeInsets.only(top: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(
              '$titleText',
              style: TextStyle(fontSize: 15, color: AppConfig.textFieldTitleColor,fontWeight: FontWeight.normal),
            ),
            SizedBox(height: 6,),
            SizedBox(
              height: 40,
              child: InputDecorator(
                decoration: InputDecoration(
                  filled: true,
                  fillColor: Colors.white,
                  contentPadding: contentPadding,
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(
                        color: AppConfig.white, width: 1.0),
                    borderRadius: BorderRadius.all(Radius.circular(30))
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(
                        color: AppConfig.white, width: 1.0),
                      borderRadius: BorderRadius.all(Radius.circular(30))
                  ),
                  /*labelText: titleText,
                  filled: filled,*/
                ),
                child: DropdownButtonHideUnderline(
                  child: DropdownButton<dynamic>(
                    dropdownColor: AppConfig.white,
                    isExpanded: true,
                    hint: Text(
                      hintText,
                        style: TextStyle(fontSize: 15.0,color: Colors.black87),
                    ),
                    value: value == '' ? null : value,
                    onChanged: (dynamic newValue) {
                      if(disabledDataSource!=null&& disabledDataSource.contains(newValue))
                        print(disabledDataSource.contains(newValue));
                      else{
                        state.didChange(newValue);
                        onChanged(newValue);
                      }

                    },
                    items: dataSource.map((item) {
                      return DropdownMenuItem<dynamic>(
                        value: item[valueField],
                        child: CustomText(item[valueField], disabledDataSource: disabledDataSource,)
                       /* child: Text(item[textField],
                            overflow: TextOverflow.ellipsis,style: TextStyle(color: item[textField]==value? AppConfig.appBarTitleTextColor  : AppConfig.appBarTitleTextColor,fontSize: 14.sp),),*/
                      );
                    }).toList(),
                  ),
                ),
              ),
            ),
            SizedBox(height: state.hasError ? 5.0 : 0.0),
            Text(
              state.hasError ? state.errorText : '',
              style: TextStyle(
                  color: Colors.redAccent.shade700,
                  fontSize: state.hasError ? 15.0 : 0.0),
            ),
          ],
        ),
      );
    },
  );


}
class CustomText extends StatelessWidget {
  final String text;
  final bool isDisabled;
  final List disabledDataSource;

  CustomText(this.text, {this.isDisabled = false,this.disabledDataSource});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      child: Container(
        width: double.infinity,
        child: Text(
          text,
          style: TextStyle(
              color: isDisabledCheck(text)
                  ? Theme.of(context).unselectedWidgetColor
                  : Theme.of(context).textTheme.title.color,
              fontSize: 15
          ),
        ),
      ),
      onTap: isDisabledCheck(text) ? () {} : null,
    );
  }

  bool isDisabledCheck(String value) {
    return disabledDataSource!=null  ? disabledDataSource.contains(value) : false;
  }
}