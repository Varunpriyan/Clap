import 'package:flutter/material.dart';

class LoaderAnimation extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SizedBox(height:MediaQuery.of(context).size.height-100,child: Center(child: CircularProgressIndicator()));
  }
}
