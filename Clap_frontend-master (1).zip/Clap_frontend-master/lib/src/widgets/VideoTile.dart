import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:video_thumbnail/video_thumbnail.dart';
class VideoTile extends StatefulWidget {
  final String path;
  final bool isFullWidth;

  const VideoTile({Key key, this.path,this.isFullWidth = false}) : super(key: key);
  @override
  _VideoTileState createState() => _VideoTileState();
}

class _VideoTileState extends State<VideoTile> {

  Uint8List thumb;

  @override
  void initState(){
    _getThumb();
    super.initState();
  }

  _getThumb()async{
    thumb = widget.isFullWidth ? await VideoThumbnail.thumbnailData(
      video: widget.path,
      imageFormat: ImageFormat.JPEG, // specify the width of the thumbnail, let the height auto-scaled to keep the source aspect ratio
      quality: 75,
    ) : await VideoThumbnail.thumbnailData(
      video: widget.path,
      imageFormat: ImageFormat.JPEG,
      maxWidth: 350, // specify the width of the thumbnail, let the height auto-scaled to keep the source aspect ratio
      quality: 25,
    );
    if(mounted)
    setState(() {
      thumb = thumb;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        thumb!=null ? widget.isFullWidth ? Image.memory(thumb,
          fit: BoxFit.cover,) :  Image.memory(thumb,
          width: 250,
          height: 250,
          fit: BoxFit.cover,) : Container(
          height: 60,
          width: 60,
          child: Text(''),
        ),
        Positioned(
            top: 0,
            bottom: 0,
            left: 0,
            right: 0,
            child: Icon(
              Icons.play_circle_fill_outlined,
              color: Colors.white,
              size: 40,
            ))
      ],
    );
  }
}
