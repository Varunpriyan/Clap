import 'package:clap/src/utils/app_config.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_fonts/google_fonts.dart';

class CustomAppBar extends StatelessWidget {
  final String title;
  final Color color;
  final bool showPop;
  final bool isClose;

  const CustomAppBar({Key key, this.title, this.color,this.showPop = true, this.isClose = false}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        showPop ? SizedBox(
          height: 30,
          child: IconButton(
            padding: EdgeInsets.all(2),
            onPressed:  (){
              if(Navigator.of(context).canPop()){
                Navigator.of(context).pop();
              }
            },
            icon: isClose ? Icon(Icons.clear,color: color,
              size: 23,) : SvgPicture.asset('assets/images/arrow_back.svg',
              color: color,
              height: 23,
              semanticsLabel: 'arrow_right',),
          ),
        ) : SizedBox(height: 0,width: 0,),
        Align(alignment: Alignment.center,child: Text(title,style: GoogleFonts.inter(fontSize: 22.0,color: color,fontWeight: FontWeight.w500),)),
      ],
    );
  }
}
