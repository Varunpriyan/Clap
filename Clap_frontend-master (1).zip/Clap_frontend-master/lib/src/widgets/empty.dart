import 'package:clap/src/utils/app_config.dart';
import 'package:clap/src/widgets/round_app_button.dart';
import 'package:flutter/material.dart';

class EmptyWidget extends StatelessWidget {
  final String image;
  final String heading;
  final String subHeading;
  final String buttonTitle;
  final bool darkMode;
  final Function onButtonPressed;

  const EmptyWidget(
      {Key key,
      this.image = "assets/images/empty_cart.png",
      @required this.heading,
      this.subHeading="",
        this.darkMode=true,
      this.buttonTitle="",
      this.onButtonPressed})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child:Padding(
      padding: const EdgeInsets.all(20.0),
      child:  Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisSize: MainAxisSize.max,
          children: [
            Container(
              width: 300,
                child: Image.asset(image)),
            SizedBox(height: 40,),
            Text(
              "$heading",
              style: TextStyle(
                color: darkMode ? AppConfig.titleFontColor : AppConfig.darkFontColor,
                fontSize: 22.0,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 15,),
            Text(
              "$subHeading",
              style: TextStyle(
                color: darkMode ? AppConfig.titleFontColor : AppConfig.darkFontColor,
                fontWeight: FontWeight.normal,
                height: 1.5,
                fontSize: 18.0,
              ),
              textAlign: TextAlign.center,
            ),
            buttonTitle.isNotEmpty ? RoundAppButton(
              title: '$buttonTitle',
              onPressed: onButtonPressed,
            ):Container()
          ],
        ),
      ),
    );
  }
}
