import 'package:flutter/material.dart';
import 'package:clap/src/utils/app_config.dart';
class ViewCount extends StatelessWidget {
  final String name;
  final String count;

  const ViewCount({Key key, this.name, this.count}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        children: [
          Row(
            children: [
              Text(
                '$name',
                style: TextStyle(fontSize: 14, color: AppConfig.grey,fontWeight: FontWeight.w400),
              ),
              Spacer(),
              Text(
                '$count Times',
                style: TextStyle(fontSize: 14, color: AppConfig.grey,fontWeight: FontWeight.w400),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
