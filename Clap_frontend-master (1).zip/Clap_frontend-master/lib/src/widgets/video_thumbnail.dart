import 'package:flutter/material.dart';
import 'dart:typed_data';
import 'package:video_thumbnail/video_thumbnail.dart';
class VideoThumbnailWidget extends StatefulWidget {
  final String path;
  const VideoThumbnailWidget({Key key,this.path}) : super(key: key);

  @override
  _VideoThumbnailWidgetState createState() => _VideoThumbnailWidgetState();
}

class _VideoThumbnailWidgetState extends State<VideoThumbnailWidget> {


  Uint8List thumb;

  _getThumb(path)async{
    thumb = await VideoThumbnail.thumbnailData(
      video: path,
      imageFormat: ImageFormat.JPEG,
      maxWidth: 228, // specify the width of the thumbnail, let the height auto-scaled to keep the source aspect ratio
      quality: 75,
    );
    if(mounted)
      setState(() {
        thumb = thumb;
      });
  }

  @override
  void initState() {
    _getThumb(widget.path);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return thumb!=null ? Center(
                        child: Image.memory(thumb,
                          height: 150,
                          fit: BoxFit.cover,),
                      ) : Container(
                        height: 60,
                        width: 60,
                        child: Text(''),
                      );
  }
}
