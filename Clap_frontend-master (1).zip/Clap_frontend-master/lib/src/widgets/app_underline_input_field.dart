import 'package:clap/src/utils/app_config.dart';
import 'package:flutter/material.dart';

class AppUnderlineInputField extends StatelessWidget {
  final String title;
  final String hint;
  final TextEditingController controller;
  final int minLines;
  final bool readOnly;
  final TextInputType keyboardType;

  final int maxLines;

  AppUnderlineInputField(
      {@required this.title,
      this.hint,
      this.controller,
      this.minLines = 1,
      this.readOnly = false,
        this.keyboardType = TextInputType.text,
      this.maxLines});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: TextStyle(
            fontSize: 18,
            color: AppConfig.white,
            fontWeight: FontWeight.w100,
          ),
        ),
        TextField(
          controller: controller,
          readOnly: readOnly,
          minLines: minLines,
          maxLines: maxLines ?? minLines,
          keyboardType: keyboardType,
          textAlign: TextAlign.start,
          style: TextStyle(
              fontSize: 20,
              color: AppConfig.white,
              fontWeight: FontWeight.w600),
          decoration: InputDecoration(
            hintText: hint ?? title,
            hintStyle: TextStyle(
              fontSize: 18,
              color: AppConfig.white,
            ),
            enabledBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: AppConfig.white,width: 0.5),
            ),
            focusedBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: AppConfig.blueUnderlineColor,width: 0.5),
            ),
            border: UnderlineInputBorder(
              borderSide: BorderSide(color: AppConfig.white,width: 0.5),
            ),

          ),
        ),
      ],
    );
  }
}
