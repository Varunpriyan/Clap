import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

enum StepWidgetState {
  indexed,
  editing,
  complete,
  disabled,
  error,
}

enum StepperWidgetType {
  vertical,
  horizontal,
}

const TextStyle _kStepStyle = TextStyle(
  fontSize: 12.0,
  color: Colors.white,
);

@immutable
class StepWidget {
  const StepWidget({
    @required this.title,
    this.subtitle,
    @required this.content,
    this.state = StepWidgetState.indexed,
    this.isActive = false,
  })  : assert(title != null),
        assert(content != null),
        assert(state != null);

  final Widget title;

  final Widget subtitle;

  final Widget content;

  final StepWidgetState state;

  final bool isActive;
}

class StepperAppWidget extends StatefulWidget {
  final double size;

  const StepperAppWidget({
    Key key,
    @required this.steps,
    this.physics,
    this.type = StepperWidgetType.vertical,
    this.currentStep = 0,
    this.onStepTapped,
    this.onStepContinue,
    this.onStepCancel,
    this.size = 18,
    this.controlsBuilder,
  })  : assert(steps != null),
        assert(type != null),
        assert(currentStep != null),
        assert(0 <= currentStep && currentStep < steps.length),
        super(key: key);

  final List<StepWidget> steps;

  final ScrollPhysics physics;

  final StepperWidgetType type;

  final int currentStep;

  final ValueChanged<int> onStepTapped;

  final VoidCallback onStepContinue;

  final VoidCallback onStepCancel;

  final ControlsWidgetBuilder controlsBuilder;

  @override
  _StepperAppWidgetState createState() => _StepperAppWidgetState();
}

class _StepperAppWidgetState extends State<StepperAppWidget>
    with TickerProviderStateMixin {
  final Map<int, StepWidgetState> _oldStates = <int, StepWidgetState>{};

  @override
  void initState() {
    super.initState();

    for (int i = 0; i < widget.steps.length; i += 1)
      _oldStates[i] = widget.steps[i].state;
  }

  @override
  void didUpdateWidget(StepperAppWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    assert(widget.steps.length == oldWidget.steps.length);

    for (int i = 0; i < oldWidget.steps.length; i += 1)
      _oldStates[i] = oldWidget.steps[i].state;
  }

  bool _isLast(int index) {
    return widget.steps.length - 1 == index;
  }

  bool _isDark() {
    return Theme.of(context).brightness == Brightness.dark;
  }

  Color _circleColor(int index) {
    final ThemeData themeData = Theme.of(context);
    if (!_isDark()) {
      return widget.steps[index].isActive
          ? themeData.primaryColor
          : Color(0xffc4c4c4);
    } else {
      return widget.steps[index].isActive
          ? themeData.accentColor
          : themeData.backgroundColor;
    }
  }

  Widget _buildCircle(int index, bool oldState) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      width: widget.size,
      height: widget.size,
      child: Container(
        padding: EdgeInsets.all(4),
        decoration: BoxDecoration(
          color: Colors.white,
          shape: BoxShape.circle,
        ),
        child: AnimatedContainer(
          curve: Curves.fastOutSlowIn,
          duration: kThemeAnimationDuration,
          decoration: BoxDecoration(
            color: _circleColor(index),
            shape: BoxShape.circle,
          ),
        ),
      ),
    );
  }

  Widget _buildIcon(int index) {
    return _buildCircle(index, true);
  }

  Widget _buildHorizontal() {
    List<Widget> childrenTitle = List();
    for (int i = 0; i < widget.steps.length; i += 1) {
      childrenTitle.add(
        Expanded(
          child: widget.steps[i].title,
        ),
      );
      if (!_isLast(i))
        childrenTitle.add(
          Expanded(
            child: Container(),
          ),
        );
    }
    final List<Widget> children = <Widget>[
      for (int i = 0; i < widget.steps.length; i += 1) ...<Widget>[
        Row(
          children: <Widget>[
            Container(
              child: Center(
                child: _buildIcon(i),
              ),
            ),
          ],
        ),
        if (!_isLast(i))
          Expanded(
            child: Container(
              height: 1.0,
              color: Colors.grey.shade400,
            ),
          ),
      ],
    ];

    return ListView(
      shrinkWrap: true,
      children: <Widget>[
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 8.0),
          height: 400,
          child: Column(
            children: childrenTitle,
          ),
        ),
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 24.0),
          height: 400,
          child: Column(
            children: children,
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    assert(debugCheckHasMaterial(context));
    assert(debugCheckHasMaterialLocalizations(context));
    assert(() {
      if (context.findAncestorWidgetOfExactType<StepperAppWidget>() != null)
        throw FlutterError('Steppers must not be nested.\n'
            'The material specification advises that one should avoid embedding '
            'steppers within steppers. '
            'https://material.io/archive/guidelines/components/steppers.html#steppers-usage');
      return true;
    }());
    assert(widget.type != null);
    return _buildHorizontal();
  }
}
