import 'package:clap/src/utils/app_config.dart';
import 'package:flutter/material.dart';

class AppRoundedInputFieldWithTitle extends StatefulWidget {
  final String title;
  final String suffixText;
  final TextEditingController controller;
  final bool readOnly;
  final TextInputType keyboardType;

  final int maxLines;
  final int maxLength;

  AppRoundedInputFieldWithTitle(
      {@required this.title,
        this.suffixText,
      this.controller,
        this.maxLength,
      this.readOnly = false,
        this.keyboardType = TextInputType.text,
      this.maxLines});

  @override
  _AppRoundedInputFieldWithTitleState createState() => _AppRoundedInputFieldWithTitleState();
}

class _AppRoundedInputFieldWithTitleState extends State<AppRoundedInputFieldWithTitle> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '${widget.title}',
            style: TextStyle(fontSize: 15, color: AppConfig.textFieldTitleColor,fontWeight: FontWeight.normal),
          ),
          SizedBox(height: 6,),
          SizedBox(
            height: widget.maxLength==null ? 40 : 64,
            child: TextField(
              controller: widget.controller,
              readOnly: widget.readOnly,
              maxLines: widget.maxLines,
              maxLength: widget.maxLength,
              keyboardType: widget.keyboardType,
              textAlign: TextAlign.start,
              onChanged:this.widget.maxLength==null ? null : (s){
                // workaround to fix the flutter bug
                if(widget.maxLength!=null){
                  if(widget.controller.text.length>widget.maxLength){
                    widget.controller.text =  widget.controller.text.substring(0,widget.maxLength);
                  }
                }

                setState(() {

                });
              },
              style: TextStyle(fontSize: 15.0,color: Colors.black87),
              decoration: InputDecoration(
                filled: true,
                fillColor: AppConfig.white,
                suffix: widget.suffixText!=null ? Text("${widget.suffixText}",style: TextStyle(color: AppConfig.textFieldTitleColor),) : null,
                counterText: this.widget.maxLength!=null ? '${widget.controller.text.length.toString()}/200' : '',
                counterStyle: TextStyle(color: AppConfig.white),
                contentPadding: EdgeInsets.symmetric(vertical: 0,horizontal: 20),
                hintText: widget.title,
                hintStyle: TextStyle(color: AppConfig.lightFontColor,),
                border: OutlineInputBorder(
                  borderSide: BorderSide(color: AppConfig.white,width: 1),
                  borderRadius: BorderRadius.circular(30.0),
                ),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: AppConfig.white,width: 1),
                  borderRadius: BorderRadius.circular(30.0),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: AppConfig.white,width: 1),
                  borderRadius: BorderRadius.circular(30.0),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
