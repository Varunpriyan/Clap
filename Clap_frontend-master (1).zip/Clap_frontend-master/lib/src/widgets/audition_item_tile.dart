import 'package:cached_network_image/cached_network_image.dart';
import 'package:clap/src/blocs/app_navigator_cubit.dart';
import 'package:clap/src/models/audition_response.dart';
import 'package:clap/src/utils/app_config.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:timeago/timeago.dart' as timeago;
class AuditionItemTile extends StatefulWidget {
  final String status;
  final Audition audition;
  final bool enableClick;

  const AuditionItemTile({Key key, this.status, this.audition,this.enableClick = true})
      : super(key: key);

  @override
  _AuditionItemTileState createState() => _AuditionItemTileState();
}

class _AuditionItemTileState extends State<AuditionItemTile> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: !widget.enableClick ? null : (){
        BlocProvider.of<AppNavigatorCubit>(context)
            .routeToAuditionDetail(audition: widget.audition.id);
      },
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            height: 206,
            width: double.infinity,
            padding: EdgeInsets.all(20),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              image: DecorationImage(
                image: widget.audition.image!=null ? CachedNetworkImageProvider(widget.audition.image) : AssetImage('assets/images/girl.jpg'),
                fit: BoxFit.cover
              )
            ),
            child: Visibility(
              visible: false,
              child: Container(
                padding: EdgeInsets.only(right: 40),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '${widget.audition.name}',
                      style: GoogleFonts.poppins(
                          fontSize: 22,
                          color: AppConfig.white,
                          fontWeight: FontWeight.w600),
                    ),
                    Spacer(),
                    Text(
                      'Audition - ${widget.audition.id.toString().padLeft(2,'0')}',
                      style: GoogleFonts.poppins(
                          fontSize: 16,
                          color: AppConfig.white,
                          fontWeight: FontWeight.w500),
                    ),
                    SizedBox(
                      height: 8,
                    ),
                    Text(
                     widget.status ?? '${timeago.format(DateTime.parse(widget.audition.createdAt))}',
                      style: GoogleFonts.poppins(
                          fontSize: 14,
                          color:  widget.status!=null ? AppConfig.primaryColorNew : AppConfig.white.withOpacity(0.8),
                          fontWeight: widget.status!=null ? FontWeight.w600 : FontWeight.w400),
                    ),
                  ],
                ),
              ),
            ),
          ),
          SizedBox(height: 8,),
          Text(
            '${widget.audition.name}',
            style: GoogleFonts.poppins(
                fontSize: 20,
                color: AppConfig.white,
                fontWeight: FontWeight.w600),
          ),
          Row(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Audition - ${widget.audition.id.toString().padLeft(2,'0')}',
                style: GoogleFonts.poppins(
                    fontSize: 16,
                    color: AppConfig.white,
                    fontWeight: FontWeight.w500),
              ),
              Text(
                widget.status ?? '${timeago.format(DateTime.parse(widget.audition.createdAt))}',
                style: GoogleFonts.poppins(
                    fontSize: 14,
                    color:  widget.status!=null ? AppConfig.primaryColorNew : AppConfig.white.withOpacity(0.8),
                    fontWeight: widget.status!=null ? FontWeight.w600 : FontWeight.w400),
              ),
            ],
          )
        ],
      ),
    );
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(8.0),
          child: widget.audition.image!=null ? CachedNetworkImage(
            imageUrl: widget.audition.image,
            height: 170.0,
            width: 120.0,
            fit: BoxFit.cover,
          ) : Container(
            height: 170.0,
            width: 120.0,
            color: Colors.white,
            child: Center(child: Image.asset('assets/images/logo.png',)),
          ),
        ),
        SizedBox(
          width: 25,
        ),
        Expanded(
          child: Container(
            height: 170,
            child: Column(
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '${widget.audition.name}',
                      style: TextStyle(
                          fontSize: 18,
                          color: AppConfig.white,
                          fontWeight: FontWeight.normal),
                    ),
                    SizedBox(
                      height: 15,
                    ),
                    Flexible(
                      child: Text(
                        '${widget.audition.info}',
                        style: TextStyle(
                            fontSize: 15,
                            color: AppConfig.white,
                            fontWeight: FontWeight.normal),
                        overflow: TextOverflow.ellipsis,
                        maxLines: 5,
                      ),
                    )
                  ],
                ),
                widget.status==null
                    ? GestureDetector(
                        onTap: () {
                          BlocProvider.of<AppNavigatorCubit>(context)
                              .routeToAuditionDetail(audition: widget.audition.id);
                        },
                        child: Text(
                          'More Details',
                          style: TextStyle(
                              fontSize: 15,
                              color: AppConfig.white,
                              fontWeight: FontWeight.normal),
                        ),
                      )
                    : Text(
                        'Status: ${widget.status}',
                        style: TextStyle(
                            fontSize: 15,
                            color: AppConfig.white,
                            fontWeight: FontWeight.normal),
                      )
              ],
            ),
          ),
        )
      ],
    );
  }
}
