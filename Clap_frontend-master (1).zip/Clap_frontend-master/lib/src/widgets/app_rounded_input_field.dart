import 'package:clap/src/utils/app_config.dart';
import 'package:flutter/material.dart';

class AppRoundedInputField extends StatefulWidget {
  final String hint;
  final TextEditingController controller;
  final bool readOnly;
  final TextInputType keyboardType;

  final int maxLines;
  final int maxLength;

  AppRoundedInputField(
      {@required this.hint,
      this.controller,
        this.maxLength,
      this.readOnly = false,
        this.keyboardType = TextInputType.text,
      this.maxLines});

  @override
  _AppRoundedInputFieldState createState() => _AppRoundedInputFieldState();
}

class _AppRoundedInputFieldState extends State<AppRoundedInputField> {
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: widget.maxLength==null ? 44 : 64,
      child: TextField(
        controller: widget.controller,
        readOnly: widget.readOnly,
        maxLines: widget.maxLines,
        maxLength: widget.maxLength,
        keyboardType: widget.keyboardType,
        textAlign: TextAlign.start,
        onChanged:this.widget.maxLength==null ? null : (s){
          // workaround to fix the flutter bug
          if(widget.maxLength!=null){
            if(widget.controller.text.length>widget.maxLength){
              widget.controller.text =  widget.controller.text.substring(0,widget.maxLength);
            }
          }

          setState(() {

          });
        },
        style: TextStyle(fontSize: 18.0,color: AppConfig.white),
        decoration: InputDecoration(
          counterText: this.widget.maxLength!=null ? '${widget.controller.text.length.toString()}/200' : '',
          counterStyle: TextStyle(color: AppConfig.white),
          contentPadding: EdgeInsets.symmetric(vertical: 0,horizontal: 20),
          hintText: widget.hint,
          hintStyle: TextStyle(color: AppConfig.lightFontColor,),
          border: OutlineInputBorder(
            borderSide: BorderSide(color: AppConfig.blueUnderlineColor,width: 1),
            borderRadius: BorderRadius.circular(30.0),
          ),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(color: AppConfig.blueUnderlineColor,width: 1),
            borderRadius: BorderRadius.circular(30.0),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(color: AppConfig.blueUnderlineColor,width: 1),
            borderRadius: BorderRadius.circular(30.0),
          ),
        ),
      ),
    );
  }
}
