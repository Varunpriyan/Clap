import 'package:clap/src/utils/app_config.dart';
import 'package:flutter/material.dart';

class ContentItem extends StatelessWidget {
  final String title;
  final String value;

  const ContentItem({Key key, this.title, this.value}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Text(
          '$title:',
          style: TextStyle(fontSize: 15, color: AppConfig.grey,fontWeight: FontWeight.w400),
        ),
        SizedBox(width: 2,),
        Text(
          '$value',
          style: TextStyle(fontSize: 15, color: AppConfig.grey,fontWeight: FontWeight.w400),
        ),
      ],
    );
  }
}
