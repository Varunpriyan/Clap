
import 'package:cached_network_image/cached_network_image.dart';
import 'package:clap/src/models/celebrity.dart';
import 'package:clap/src/utils/app_config.dart';
import 'package:flutter/material.dart';

import 'image_error.dart';

typedef ItemSelectedCallback = Function(Celebrity val);
typedef ItemAddCallback = Function(Celebrity val);

class GridItemTile extends StatelessWidget {
  final Celebrity celebrity;
  final ItemSelectedCallback onItemTap;
  final bool isInGrid;
   bool isDarkText;

  final ValueChanged<Celebrity> onRemovedFromList;

  GridItemTile(
      this.celebrity, {
        this.onItemTap,
        this.isInGrid=false,
        this.isDarkText=false,
        this.onRemovedFromList,
      });


  @override
  Widget build(BuildContext context) {
    if(isInGrid)
      isDarkText = true;
    return InkWell(
      onTap: () {
        onItemTap(celebrity);
      },
      child: Container(
        padding: EdgeInsets.all(8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: CachedNetworkImage(
                errorWidget: (context, url, error) {
                  return ImageError();
                },
                imageUrl: celebrity.image ?? "",
                fit: BoxFit.cover,
                width: double.infinity,
                height: isInGrid ? (MediaQuery.of(context).size.width*0.3)*1.2 : (MediaQuery.of(context).size.height*0.26)-62,
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Text(
              "${celebrity.name}",
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(fontSize: 12,fontWeight: FontWeight.w700,color: isDarkText ?AppConfig.darkFontColor : AppConfig.white),
            ),
            SizedBox(
              height: 3,
            ),
            Text(
              "${celebrity.profession}",
              style: TextStyle(fontSize: 11,color:  isDarkText ?AppConfig.darkFontColorWithOpacity :  AppConfig.lightFontColor),
            )
          ],
        ),
      ),
    );
  }
}
