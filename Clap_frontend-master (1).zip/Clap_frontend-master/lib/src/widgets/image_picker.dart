import 'dart:io';

import 'package:dotted_border/dotted_border.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:image_picker/image_picker.dart';
import 'package:clap/src/utils/app_config.dart';
import 'package:clap/src/widgets/round_app_button.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart';
import 'package:toast/toast.dart';
import 'package:clap/src/widgets/video_thumbnail.dart';

class ImagePickerWidget extends StatefulWidget {
  final ValueChanged<List<String>> onSelect;
  final List<String> selectedFile;
  final bool enableGallery;

  const ImagePickerWidget(
      {Key key, this.onSelect, this.selectedFile, this.enableGallery})
      : super(key: key);

  @override
  _ImagePickerWidgetState createState() => _ImagePickerWidgetState();
}

class _ImagePickerWidgetState extends State<ImagePickerWidget> {
  final _picker = ImagePicker();
  List<String> selectedImage;

  @override
  void initState() {
    selectedImage = [];
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        selectedImage != null && selectedImage.length > 0
            ? _imagesList()
            : Container(),
        GestureDetector(
          onTap: () {
            FocusScope.of(context).unfocus();
            if (widget.enableGallery)
              _showPickDialog(context);
            else
              _pickFromCamera(false,context);
          },
          child: DottedBorder(
            borderType: BorderType.RRect,
            dashPattern: [8, 4],
            color: Colors.grey.shade400,
            radius: Radius.circular(
                selectedImage != null && selectedImage.length > 0 ? 32 : 16),
            padding: EdgeInsets.all(6),
            child: ClipRRect(
              borderRadius: BorderRadius.all(Radius.circular(1)),
              child: Container(
                height: selectedImage != null && selectedImage.length > 0
                    ? 30
                    : 120,
                padding: EdgeInsets.all(3),
                width: double.infinity,
                child: selectedImage != null && selectedImage.length > 0
                    ? Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.photo_camera_outlined,
                            color: Colors.grey.shade400,
                            size: 30,
                          ),
                          SizedBox(
                            width: 10,
                          ),
                          Text(
                            "Add more",
                            style: TextStyle(
                                color: Colors.grey.shade400,
                                fontWeight: FontWeight.w600),
                          )
                        ],
                      )
                    : Column(
                        mainAxisSize: MainAxisSize.max,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.photo_camera_outlined,
                            color: Colors.grey.shade400,
                            size: 70,
                          ),
                          Text(
                            "Upload video/photo",
                            style: TextStyle(
                                color: Colors.grey.shade400,
                                fontWeight: FontWeight.w600),
                          )
                        ],
                      ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  _imagesList() {
    return Container(
      height: 120,
      padding: EdgeInsets.only(bottom: 10),
      child: ListView.builder(
        shrinkWrap: true,
        scrollDirection: Axis.horizontal,
        itemCount: selectedImage.length,
        itemBuilder: (context, index) {
          return Container(
              height: 70,
              padding: EdgeInsets.only(right: 10),
              child: Stack(
                children: [
                  selectedImage[index].endsWith('.mp4')
                      ? VideoThumbnailWidget(
                          path: selectedImage[index],
                        )
                      : Image.file(
                          File("${selectedImage[index]}"),
                          fit: BoxFit.contain,
                        ),
                  Positioned(
                      top: 5,
                      right: 5,
                      child: GestureDetector(
                        onTap: () {
                          setState(() {
                            selectedImage.removeAt(index);
                          });
                          widget.onSelect(selectedImage);
                        },
                        child: Container(
                            padding: EdgeInsets.all(2),
                            decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(15)),
                            child: Icon(
                              Icons.close,
                              color: Colors.red,
                              size: 18,
                            )),
                      )),
                  Positioned(
                    left: 5,
                      bottom: 5,
                      child: Center(
                          child: Container(
                              height: 20,
                              width: 20,
                              decoration: BoxDecoration(
                                color: Colors.black.withOpacity(0.2),
                                shape: BoxShape.circle
                              ),
                              child: Icon( selectedImage[index].endsWith('.mp4') ? Icons.movie_outlined : Icons.photo,color: Colors.white,size: 20,))))
                ],
              ));
        },
      ),
    );
  }

  _showPickDialog(mainContext) {
    showDialog(
        context: mainContext,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return Dialog(
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20.0)), //this right here
            child: Container(
              //height: 360,
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 30, vertical: 5),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          '',
                          style: TextStyle(
                            fontSize: 20,
                            color: AppConfig.hintTextColor,
                            fontWeight: FontWeight.w600,
                          ),
                          textAlign: TextAlign.left,
                        ),
                        InkWell(
                            onTap: () {
                              Navigator.of(context).pop();
                            },
                            child: Icon(Icons.close))
                      ],
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    RoundAppButton(
                      title: "Upload from gallery".toUpperCase(),
                      onPressed: () {
                        Navigator.of(context).pop();
                        _pickImage("gallery", mainContext);
                      },
                      titleFontSize: 13,
                      padding: 1.0,
                    ),
                    SizedBox(
                      height: 15,
                    ),
                    RoundAppButton(
                      title: "Take Photo".toUpperCase(),
                      onPressed: () {
                        Navigator.of(context).pop();
                        _pickFromCamera(false,mainContext);
                      },
                      titleFontSize: 13,
                      padding: 1.0,
                    ),
                    SizedBox(
                      height: 15,
                    ),
                    RoundAppButton(
                      title: "Take Video".toUpperCase(),
                      onPressed: () {
                        Navigator.of(context).pop();
                        _pickFromCamera(true,mainContext);
                      },
                      titleFontSize: 13,
                      padding: 1.0,
                    ),
                    SizedBox(
                      height: 20,
                    ),
                  ],
                ),
              ),
            ),
          );
        });
  }

  _pickImage(String source, context) async {
    FilePickerResult result = Platform.isIOS
        ? await FilePicker.platform.pickFiles(
            type: FileType.media,
            allowMultiple: true,
          )
        : await FilePicker.platform.pickFiles(
            type: FileType.custom,
            allowMultiple: true,
            allowedExtensions: ['jpg', 'jpeg', 'png', 'mp4'],
          );

    if (result != null) {
      List<File> videos = [];
      List<File> images = [];

      List<PlatformFile> files = result.files;
      for (var i = 0; i < files.length; i++) {
        if (files[i].extension.toLowerCase() == 'jpg' ||
            files[i].extension.toLowerCase() == 'jpeg' ||
            files[i].extension.toLowerCase() == 'png') {
          if (files[i].size > 20971520) {
            Toast.show(
                "Image size should be less than 20MB! Ignoring ${files[i].name}",
                context,
                duration: Toast.LENGTH_LONG,
                gravity: Toast.BOTTOM);
          } else {
            images.add(File(files[i].path));
          }
        } else if (files[i].extension.toLowerCase() == 'mp4') {
          if (files[i].size > 109457280) {
            Toast.show(
                "Video size should be less than 100MB! Ignoring ${files[i].name}",
                context,
                duration: Toast.LENGTH_LONG,
                gravity: Toast.BOTTOM);
          } else {
            videos.add(File(files[i].path));
          }
        } else {
          Toast.show(
              "Only jpg/png/mp4 file types are allowed! Ignoring ${files[i].name}",
              context,
              duration: Toast.LENGTH_LONG,
              gravity: Toast.BOTTOM);
        }
      }

      if (images.length > 0 &&
          (selectedImage
                  .where((element) => !element.toLowerCase().endsWith(".mp4"))
                  .toList()
                  .length) >=
              6) {
        Toast.show("Only 6 photos can be added!", context,
            duration: Toast.LENGTH_LONG, gravity: Toast.BOTTOM);
        images.clear();
      }
      if (videos.length > 0 &&
          (selectedImage
                  .where((element) => element.toLowerCase().endsWith(".mp4"))
                  .toList()
                  .length) >=
              3) {
        Toast.show("Only 3 videos can be added!", context,
            duration: Toast.LENGTH_LONG, gravity: Toast.BOTTOM);
        videos.clear();
      }

      int remImages = 6 -
          (selectedImage.length > 0
              ? selectedImage
                  .where((element) => !element.toLowerCase().endsWith(".mp4"))
                  .toList()
                  .length
              : 0);
      int remVideo = 3 -
          (selectedImage.length > 0
              ? selectedImage
                  .where((element) => element.toLowerCase().endsWith(".mp4"))
                  .toList()
                  .length
              : 0);

      print('/videos');
      print(remVideo);
      // media qualified to upload
      if (images.length > remImages) {
        images = images.take(remImages).toList();
        Toast.show(
            "Only $remImages photos can be added! Ignoring rest of photos.",
            context,
            duration: Toast.LENGTH_LONG,
            gravity: Toast.BOTTOM);
      }
      if (videos.length > remVideo) {
        videos = videos.take(remVideo).toList();
        Toast.show(
            "Only $remVideo videos can be added! Ignoring rest of videos.",
            context,
            duration: Toast.LENGTH_LONG,
            gravity: Toast.BOTTOM);
      }

      print("images:${images.length}");
      print("videos:${videos.length}");

      if (images.length > 0 || videos.length > 0) {
        final Directory directory = await getApplicationDocumentsDirectory();
        final String path = directory.path;
        for (File file in images) {
          var fileName = basename(file.path);
          File newFile = File(file.path);
          final File localImage = await newFile.copy(
              '$path/${DateTime.now().millisecondsSinceEpoch.toString()}_$fileName');
          if (selectedImage == null) selectedImage = [];
          selectedImage.add(localImage.path);
        }
        for (File file in videos) {
          var fileName = basename(file.path);
          File newFile = File(file.path);
          final File localImage = await newFile.copy(
              '$path/${DateTime.now().millisecondsSinceEpoch.toString()}_$fileName');
          if (selectedImage == null) selectedImage = [];
          selectedImage.add(localImage.path);
        }
      }

      setState(() {
        selectedImage = selectedImage;
      });

      widget.onSelect(selectedImage);
    }
  }

  _pickFromCamera(isVideo,context) async {
    PickedFile image;
    if(isVideo)
    image =
        await _picker.getVideo(source: ImageSource.camera, maxDuration: Duration(minutes: 1));
    else
      image =
      await _picker.getImage(source: ImageSource.camera, imageQuality: 60);

    if (image == null) return;


    if(!isVideo)
    if ((selectedImage
            .where((element) => !element.toLowerCase().endsWith(".mp4"))
            .toList()
            .length) >=
            6) {
      Toast.show("Only 6 photos can be added!", context,
          duration: Toast.LENGTH_LONG, gravity: Toast.BOTTOM);
      return;
    }

    if(isVideo)
    if ((selectedImage
            .where((element) => element.toLowerCase().endsWith(".mp4"))
            .toList()
            .length) >=
            3) {
      Toast.show("Only 3 videos can be added!", context,
          duration: Toast.LENGTH_LONG, gravity: Toast.BOTTOM);
      return;
    }


    final Directory directory = await getApplicationDocumentsDirectory();
    final String path = directory.path;
    var fileName = basename(image.path);
    File file = File(image.path);
    final File localImage = await file.copy('$path/$fileName');
    if (selectedImage == null) selectedImage = [];
    setState(() {
      selectedImage.add(localImage.path);
    });
    print('picked image from camera');
    widget.onSelect(selectedImage);
  }
}
