
import 'package:clap/src/blocs/app_navigator_cubit.dart';
import 'package:clap/src/models/categories_response.dart';
import 'package:clap/src/models/celebrity.dart';
import 'package:clap/src/utils/app_config.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'celebrity_grid_item.dart';

const double _kDefaultSizedBoxHeight = 114;
const double _kDefaultTileWidth = 130;
class HorizontalCelebrityList extends StatefulWidget {
  final List<Celebrity> celebrities;
  final Category category;
  final ItemSelectedCallback onItemSelected;
  final bool more;
  final bool isDarkTitle;
  final bool isInGrid;
  final bool isDartText;
  final double horizontalPadding;
  final double titleHorizontalPadding;
  final Function onSeeAllSelected;

  HorizontalCelebrityList({
    this.celebrities,
    this.category,
    @required this.onItemSelected,
    this.more = true,
    this.isDarkTitle = false,
    this.isDartText = false,
    this.isInGrid = false,
    this.horizontalPadding = 18.0,
    this.titleHorizontalPadding = 12.0,
    this.onSeeAllSelected,
  });

  @override
  _HorizontalCelebrityListState createState() => _HorizontalCelebrityListState();
}

class _HorizontalCelebrityListState extends State<HorizontalCelebrityList> {

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final double _sizedBoxHeight =
        _kDefaultSizedBoxHeight + (76 * MediaQuery.of(context).textScaleFactor);
    return Container(
      padding: EdgeInsets.symmetric(horizontal: widget.horizontalPadding),
      margin: EdgeInsets.symmetric(vertical: 12),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            margin: EdgeInsets.symmetric(horizontal: widget.titleHorizontalPadding,vertical: 5.0),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    widget.category.name,
                    style: TextStyle(
                      fontSize: 22,
                      color: widget.isDarkTitle ? AppConfig.titleBlueFontColor : AppConfig.titleFontColor,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                widget.more
                    ? GestureDetector(
                  onTap: widget.onSeeAllSelected,
                  child: Text(
                    'See All',
                    style: TextStyle(
                      fontSize: 14,
                      color: AppConfig.orangeTextColor,
                      fontWeight: FontWeight.w600,
                    ),
                    textAlign: TextAlign.center,
                  ),
                )
                    : Container(),
              ],
            ),
          ),
          SizedBox(
            height: (MediaQuery.of(context).size.width*0.3)*1.75,
            child:ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: widget.celebrities.length,
                    itemBuilder: (context, index) {
                      return SizedBox(
                        width: MediaQuery.of(context).size.width*0.3,
                        child: GridItemTile(
                                widget.celebrities[index],
                                isInGrid: widget.isInGrid,
                                isDarkText: widget.isDartText,
                                onItemTap: (celebrity) {
                                  BlocProvider.of<AppNavigatorCubit>(context)
                                      .routeToCelebrityDetail(celebrity);
                                },
                              ),
                      );
                    },
                  )
          )
        ],
      ),
    );
  }
}
