import 'package:clap/src/utils/app_config.dart';
import 'package:flutter/material.dart';
import 'raised_app_button.dart';

class RoundAppButton extends StatelessWidget {
  final String title;
  final String subtitle;
  final Function onPressed;
  final BoxShadow shadowTheme;
  final Color color;
  final double padding;
  final bool isBusy;
  final double titleFontSize;
  final double height;

  const RoundAppButton({
    Key key,
    @required this.title,
    @required this.onPressed,
    this.shadowTheme = AppConfig.boxShadowTheme,
    this.color = AppConfig.primaryButtonColor,
    this.padding = 16.0,
    this.titleFontSize = 18.0,
    this.height = 46.0,
    this.subtitle = "",
    this.isBusy = false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: padding),
      child: RaisedAppButton(
        color: color,
        shadow: false,
        height: height,
        shadowTheme: shadowTheme,
        onPressed: onPressed,
        child: Stack(
          children: [
            Center(
              child: isBusy
                  ? SizedBox(
                height: 24,
                    width: 24,
                    child: CircularProgressIndicator(
                strokeWidth: 2,
                        valueColor:
                            AlwaysStoppedAnimation<Color>(AppConfig.white),
                      ),
                  )
                  : Column(
                mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                          title,
                          style: TextStyle(
                            fontSize: titleFontSize,
                            color: AppConfig.white,
                            fontWeight: FontWeight.w300,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      subtitle.isNotEmpty ? Text(
                        subtitle,
                        style: TextStyle(
                          fontSize: 12.0,
                          color: AppConfig.buttonSubtitleTextColor,
                          fontWeight: FontWeight.w400,
                        ),
                        textAlign: TextAlign.center,
                      ) : Container(),
                    ],
                  ),
            ),
          ],
        ),
      ),
    );
  }
}
