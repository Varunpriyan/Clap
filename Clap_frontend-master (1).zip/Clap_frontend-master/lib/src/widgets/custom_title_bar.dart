import 'package:clap/src/blocs/app_navigator_cubit.dart';
import 'package:clap/src/utils/app_config.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_fonts/google_fonts.dart';

class CustomTitleBarWidget extends StatelessWidget {
  final String title;
  final String buttonText;
  final bool hasBackButton;
  final Function onCancel;

  const CustomTitleBarWidget({Key key, this.title, this.buttonText='',this.hasBackButton=false,this.onCancel}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
          border: Border(bottom:  BorderSide(
            color: AppConfig.blueUnderlineColor,
            width: 0.5,
          ))
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              hasBackButton ? GestureDetector(onTap: (){
                if(Navigator.of(context).canPop()){
                  Navigator.of(context).pop();
                }
              },child: Padding(
                padding: const EdgeInsets.only(right: 15),
                child: SvgPicture.asset('assets/images/arrow_left.svg',
                  color: AppConfig.white,
                  height: 17,
                  semanticsLabel: 'arrow_right',),
              )) : Container(),
              Text(title,style: GoogleFonts.montserrat(fontSize: 14.0,color: AppConfig.white,fontWeight: FontWeight.w500),),
            ],
          ),

          buttonText.isNotEmpty?GestureDetector(onTap:onCancel??(){
            BlocProvider.of<AppNavigatorCubit>(context)
                .routeToHome();
          },child: Text('Cancel',style: TextStyle(fontSize: 14.0,color: AppConfig.orangeTextColor),)):Container(),
        ],
      ),
    );
  }
}
