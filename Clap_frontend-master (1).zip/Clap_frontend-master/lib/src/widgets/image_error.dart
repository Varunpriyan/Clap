import 'package:flutter/material.dart';

class ImageError extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
        child: Material(
      child: Image.asset(
          'assets/images/default.png',fit: BoxFit.contain,) /*Text(
        'Image Not Available',
        textAlign: TextAlign.center,
      )*/
      ,
    ));
  }
}
