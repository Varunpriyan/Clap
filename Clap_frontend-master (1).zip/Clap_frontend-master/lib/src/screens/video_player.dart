import 'package:flutter/material.dart';
import 'package:better_player/better_player.dart';

class VideoPlayer extends StatefulWidget {
  final String url;

  const VideoPlayer({Key key, this.url}) : super(key: key);
  @override
  _VideoPlayerState createState() => _VideoPlayerState();
}

class _VideoPlayerState extends State<VideoPlayer> {
  @override
  void initState() {

    super.initState();
  }
  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Stack(
        children: [
          BetterPlayer.network(
            "${widget.url}",
            betterPlayerConfiguration: BetterPlayerConfiguration(
              autoPlay: true,
              aspectRatio: 16 / 9,
              fit: BoxFit.contain,
              controlsConfiguration: BetterPlayerControlsConfiguration(
                enablePlaybackSpeed: false,
                enableSubtitles: false,
                enableQualities: false,
                enableOverflowMenu: false,
                loadingColor: Colors.white,
                enableSkips: false
              ),
              //fullScreenByDefault: true,
            ),
          ),
        ],
      ),
    );
  }
}
