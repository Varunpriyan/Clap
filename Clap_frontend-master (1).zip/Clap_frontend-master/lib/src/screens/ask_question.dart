import 'package:cached_network_image/cached_network_image.dart';
import 'package:clap/src/blocs/app_navigator_cubit.dart';
import 'package:clap/src/blocs/ask_question_cubit.dart';
import 'package:clap/src/models/ask_question.dart';
import 'package:clap/src/models/celebrity.dart';
import 'package:clap/src/models/models.dart';
import 'package:clap/src/utils/app_config.dart';
import 'package:clap/src/widgets/custom_title_bar.dart';
import 'package:clap/src/widgets/image_error.dart';
import 'package:clap/src/widgets/round_app_button.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';

class AskQuestionScreen extends StatefulWidget {
  @override
  _AskQuestionScreenState createState() => _AskQuestionScreenState();
}

class _AskQuestionScreenState extends State<AskQuestionScreen> {
  TextEditingController _textEditingControllerQuestion;
  AskQuestionCubit _askQuestionCubit;

  Celebrity celebrity;
  @override
  void initState() {
    _textEditingControllerQuestion = TextEditingController();
    _askQuestionCubit = AskQuestionCubit();

    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    celebrity = ModalRoute.of(context).settings.arguments;
    return Scaffold(
      body: SafeArea(
        child: BlocListener(
          cubit: _askQuestionCubit,
          listener: (context,state){
            if (state is AskQuestionValidationError) {
              Scaffold.of(context).showSnackBar(
                SnackBar(
                  content: Text("Please enter a valid question",style: TextStyle(color: AppConfig.primaryColorDark),),
                  backgroundColor: AppConfig.white,
                ),
              );
            }
            if (state is AskQuestionValidationSuccess) {
              AskQuestion askQuestion = AskQuestion(question: _textEditingControllerQuestion.text.trim(),celebrity: celebrity,user: state.user);
              BlocProvider.of<AppNavigatorCubit>(context)
                  .routeToAskQuestionConfirm(askQuestion);
            }
          },
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40,vertical: 20),
              child: Column(
                children: [
                  CustomTitleBarWidget(title: 'Ask a Question',buttonText: 'Cancel',onCancel: (){Navigator.of(context).pop();},),
                  SizedBox(height: 70,),
                  CircleAvatar(
                    radius: 61.0,
                    backgroundImage: CachedNetworkImageProvider(
                      '${celebrity.image}',
                    ),
                  ),
                  SizedBox(height: 15,),
                  Text('${celebrity.name}',style: GoogleFonts.montserrat(fontSize: 22.0,color: AppConfig.white,fontWeight: FontWeight.w500),),
                  SizedBox(height: 70,),
                  Align(alignment: Alignment.centerLeft,child: Text('What is your Question?',style: TextStyle(fontSize: 18.0,color: AppConfig.white))),
                  SizedBox(height: 20,),
                  TextField(
                    controller: _textEditingControllerQuestion,
                    style: TextStyle(color: AppConfig.white),
                    onChanged: (s){
                      // workaround to fix the flutter bug
                      if(_textEditingControllerQuestion.text.length>200){
                        _textEditingControllerQuestion.text =  _textEditingControllerQuestion.text.substring(0,200);
                      }
                      setState(() {

                      });
                    },
                    minLines: 6,
                    maxLines: 10,
                    maxLength: 200,
                    inputFormatters: [
                      new LengthLimitingTextInputFormatter(200),// for mobile
                    ],
                    decoration: new InputDecoration(
                      counterText: '${_textEditingControllerQuestion.text.length.toString()}/200',
                      counterStyle: TextStyle(color: AppConfig.white),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: AppConfig.blueUnderlineColor, width: 1),
                        borderRadius: const BorderRadius.all(
                          const Radius.circular(15.0),
                        ),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: AppConfig.blueUnderlineColor, width: 1),
                        borderRadius: const BorderRadius.all(
                          const Radius.circular(15.0),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 30,),
                  BlocBuilder(
                    cubit: _askQuestionCubit,
                      builder: (context,state){
                    bool isBusy = false;
                    if (state is AskQuestionBusy) {
                      isBusy = true;
                    }
                    return RoundAppButton(
                      isBusy: isBusy,
                        padding: MediaQuery.of(context).size.width*0.2,
                        title: "Next",
                        titleFontSize: 22.0,
                        onPressed: () {
                          _askQuestionCubit.validateQuestion(question: _textEditingControllerQuestion.text.trim());

                        });
                  })
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }


}
