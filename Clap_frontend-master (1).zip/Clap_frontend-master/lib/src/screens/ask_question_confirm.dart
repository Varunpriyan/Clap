import 'package:cached_network_image/cached_network_image.dart';
import 'package:clap/src/blocs/app_navigator_cubit.dart';
import 'package:clap/src/blocs/ask_question_cubit.dart';
import 'package:clap/src/models/ask_question.dart';
import 'package:clap/src/models/models.dart';
import 'package:clap/src/utils/app_config.dart';
import 'package:clap/src/widgets/app_rounded_input_field.dart';
import 'package:clap/src/widgets/custom_title_bar.dart';
import 'package:clap/src/widgets/image_error.dart';
import 'package:clap/src/widgets/round_app_button.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';

class AskQuestionConfirmScreen extends StatefulWidget {
  @override
  _AskQuestionConfirmScreenState createState() => _AskQuestionConfirmScreenState();
}

class _AskQuestionConfirmScreenState extends State<AskQuestionConfirmScreen> {
  AskQuestion askQuestion;
  AskQuestionCubit _askQuestionCubit;
  AskQuestionResponse askQuestionResponse;
  Razorpay _razorPay;

  TextEditingController _textEditingControllerPhone;
  TextEditingController _textEditingControllerEmail;
  bool _isLoading;

  @override
  void initState() {
    _askQuestionCubit = AskQuestionCubit();
    _textEditingControllerPhone = TextEditingController();
    _textEditingControllerEmail = TextEditingController();

    _razorPay = Razorpay();
    _razorPay.on(Razorpay.EVENT_PAYMENT_SUCCESS, _handlePaymentSuccess);
    _razorPay.on(Razorpay.EVENT_PAYMENT_ERROR, _handlePaymentError);
    _razorPay.on(Razorpay.EVENT_EXTERNAL_WALLET, _handleExternalWallet);
    super.initState();

    _isLoading = false;

  }

  @override
  void dispose() {
    _razorPay.clear();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    askQuestion = ModalRoute.of(context).settings.arguments;
    _textEditingControllerPhone.text = askQuestion.user.phoneNumber;
    _textEditingControllerEmail.text = askQuestion.user.email;
    print(askQuestion.user.email);
    return Scaffold(
      body: SafeArea(
        child: BlocListener(
          cubit: _askQuestionCubit,
          listener: (context,state){
            if (state is AskQuestionValidationError) {
              String message = 'Validation Error';
              switch (state.field) {
                case 1:
                  message = 'Mobile no. and Email id are required';
                  break;
                case 2:
                  message = 'Invalid Mobile no.';
                  break;
                case 3:
                  message = 'Invalid Email';
                  break;
              }
              Scaffold.of(context).showSnackBar(
                SnackBar(
                  content: Text("$message",style: TextStyle(color: AppConfig.primaryColorDark),),
                  backgroundColor: AppConfig.white,
                ),
              );
            }
            if (state is AskQuestionSuccess) {
              askQuestionResponse = state.askQuestionResponse;
              print(double.parse(askQuestion.celebrity.askQuestionPrice) * 100);
              var options = {
                'key': '${state.askQuestionResponse.keys.test}',
                'amount': double.parse(askQuestion.celebrity.askQuestionPrice) * 100,
                'name': 'Clap',
                'order_id': askQuestionResponse.razorId,
                'description': 'Online Items',
                'prefill': {
                  'contact': '${state.user.phoneNumber}',
                  'email': '${state.user.email}'
                }
              };
              askQuestionResponse = state.askQuestionResponse;
              _razorPay.open(options);
              setState(() {
                _isLoading = true;
              });
            }
            if (state is AskQuestionError) {
              Scaffold.of(context).showSnackBar(
                SnackBar(
                  content: Text("Something went wrong! Try again.",style: TextStyle(color: AppConfig.primaryColorDark),),
                  backgroundColor: AppConfig.white,
                ),
              );
            }
            if (state is PaymentUpdateSuccess ||
                state is PaymentUpdateError ||
                state is PaymentUpdateFailed) {
              askQuestionResponse = state.askQuestionResponse;
              BlocProvider.of<AppNavigatorCubit>(context)
                  .routeToPaymentStatus(askQuestionResponse.order,askQuestionResponse.paymentStatus);
            }
          },
          child: !_isLoading ? SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40,vertical: 20),
              child: Column(
                children: [
                  CustomTitleBarWidget(title: 'Confirm Details',buttonText: 'Cancel',),
                  SizedBox(height: 20,),
                  Container(
                      padding: EdgeInsets.symmetric(horizontal: 20,vertical: 5),
                      margin: EdgeInsets.symmetric(vertical: 10),
                      decoration: new BoxDecoration(
                          border: new Border.all(
                              width: 10, color: Colors.transparent),
                          borderRadius: const BorderRadius.all(
                              const Radius.circular(15.0)),
                          //color: new Color.fromRGBO(255, 255, 255, 0.5),
                          gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [
                              AppConfig.primaryColor,
                              AppConfig.blueBottomNavigationColor
                            ],
                            /*stops: [0.2,0.31,0.7,0.9]*/
                          ) // Specifies the background color and the opacity
                      ),
                    child: Column(
                      children: [
                        Container(
                          padding: EdgeInsets.symmetric(horizontal: 10,vertical: 5),
                          decoration: BoxDecoration(
                              border: Border(bottom:  BorderSide(
                                color: AppConfig.white,
                                width: 0.3,
                              ))
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              CircleAvatar(
                                radius: 25,
                                backgroundImage: CachedNetworkImageProvider(
                                  '${askQuestion.celebrity.image}',
                                ),
                              ),
                              SizedBox(width: 15,),
                              CircleAvatar(
                                radius: 25,
                                backgroundImage: askQuestion.user.profile.isNotEmpty ? NetworkImage(askQuestion.user.profile) :   AssetImage('assets/images/user.png'),
                              ),
                              SizedBox(width: 25,),
                              Expanded(child: Text('${askQuestion.celebrity.name} and ${askQuestion.user.displayName}',style: GoogleFonts.montserrat(fontSize: 11.0,color: AppConfig.white,fontWeight: FontWeight.w500),)),

                            ],
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Align(
                            alignment: Alignment.centerLeft,
                            child: Text(
                              '${askQuestion.question}',
                              style: TextStyle(
                                  fontSize: 12.0,
                                  color: AppConfig.white,
                                  fontWeight: FontWeight.w400),
                              textAlign: TextAlign.left,
                            ),
                          ),
                        ),
                        Align(
                          alignment: Alignment.centerRight,
                          child: SizedBox(
                            height: 22,
                            width: 44,
                            child: OutlineButton(
                              padding: EdgeInsets.all(0),
                              onPressed: () {
                                Navigator.of(context).pop();
                              },
                              child: Text("Edit",style: TextStyle(color: AppConfig.white,fontSize: 10),),
                              borderSide: BorderSide(color: AppConfig.white),
                              shape: StadiumBorder(),
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                  SizedBox(height: 30,),
                  Text('Delivery Information',style: GoogleFonts.montserrat(fontSize: 22.0,color: AppConfig.white,fontWeight: FontWeight.w500),),
                  SizedBox(height: 30,),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 12.0),
                    child: AppRoundedInputField(hint: 'Enter Mobile No.*',controller: _textEditingControllerPhone,keyboardType: TextInputType.phone,),
                  ),
                  /*Padding(
                    padding: const EdgeInsets.all(12.0),
                    child: Center(child: Text('OR',style: TextStyle(color: AppConfig.white,fontSize: 18),),),
                  ),*/
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 12.0),
                    child: AppRoundedInputField(hint: 'Enter Email ID*',controller: _textEditingControllerEmail,keyboardType: TextInputType.emailAddress,),
                  ),
                  SizedBox(height: 40,),
                  BlocBuilder(
                    cubit: _askQuestionCubit,
                      builder:(context,state){
                        bool isBusy = false;
                        if (state is AskQuestionBusy ||
                            state is PaymentUpdating) {
                          isBusy = true;
                        }
                    return RoundAppButton(
                      isBusy: isBusy,
                        title: "Proceed to payment",
                        titleFontSize: 22.0,
                        onPressed: () {
                           _askQuestionCubit.askQuestion(celebrity: askQuestion.celebrity,question:askQuestion.question,phone:_textEditingControllerPhone.text.trim(),email:_textEditingControllerEmail.text.trim());
                        });
                  }),
                ],
              ),
            ),
          ) : Center(
            child: CircularProgressIndicator(
              strokeWidth: 2,
              valueColor:
              AlwaysStoppedAnimation<Color>(AppConfig.white),
            ),
          ),
        ),
      ),
    );
  }


  void _handlePaymentSuccess(PaymentSuccessResponse response) {
    print('payment succeeds');
    _askQuestionCubit.updatePayment(askQuestionResponse, response.paymentId,askQuestion.celebrity.askQuestionPrice);
  }

  void _handlePaymentError(PaymentFailureResponse response) {
    BlocProvider.of<AppNavigatorCubit>(context)
        .routeToPaymentStatus(askQuestionResponse.order,askQuestionResponse.paymentStatus);
  }

  void _handleExternalWallet(ExternalWalletResponse response) {
    BlocProvider.of<AppNavigatorCubit>(context)
        .routeToPaymentStatus(askQuestionResponse.order,askQuestionResponse.paymentStatus);
  }
}
