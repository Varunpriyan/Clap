import 'package:cached_network_image/cached_network_image.dart';
import 'package:clap/src/blocs/app_navigator_cubit.dart';
import 'package:clap/src/blocs/occasion_cubit.dart';
import 'package:clap/src/models/celebrity.dart';
import 'package:clap/src/models/models.dart';
import 'package:clap/src/models/occasion_response.dart';
import 'package:clap/src/utils/app_config.dart';
import 'package:clap/src/utils/constants.dart';
import 'package:clap/src/widgets/app_rounded_input_field.dart';
import 'package:clap/src/widgets/custom_title_bar.dart';
import 'package:clap/src/widgets/image_error.dart';
import 'package:clap/src/widgets/loadng.dart';
import 'package:clap/src/widgets/round_app_button.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_fonts/google_fonts.dart';

class MakeWishInputOccasionScreen extends StatefulWidget {
  static const String routeName = Constants.CELEBRITY_MAKE_WISH_OCCASION;
  final MakeWish makeWish;

  MakeWishInputOccasionScreen({Key key, this.makeWish}) : super(key: key);

  @override
  _MakeWishInputOccasionScreenState createState() =>
      _MakeWishInputOccasionScreenState();
}

class _MakeWishInputOccasionScreenState
    extends State<MakeWishInputOccasionScreen> {

  TextEditingController _textEditingControllerInfo;
  Occasion occasion;
  OccasionCubit _occasionCubit;

  @override
  void initState() {
    _textEditingControllerInfo = TextEditingController();
    _occasionCubit = OccasionCubit();
    _occasionCubit.getOccasions();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 20),
            child: BlocBuilder(
              cubit: _occasionCubit,
              builder: (context, state) {
                if (state is OccasionLoadSuccess) {
                  return Column(
                    children: [
                      CustomTitleBarWidget(
                        title: 'Choose Occasion', buttonText: 'Cancel',),
                      SizedBox(height: 70,),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Column(
                            children: [
                              CircleAvatar(
                                radius: 45,
                                backgroundImage: CachedNetworkImageProvider(
                                  '${widget.makeWish.celebrity.image}',
                                ),
                              ),
                              SizedBox(height: 15,),
                              Text('${widget.makeWish.celebrity.name}',
                                style: GoogleFonts.montserrat(fontSize: 14.0,
                                    color: AppConfig.white,
                                    fontWeight: FontWeight.w500),),
                            ],
                          ),
                          Padding(
                            padding: EdgeInsets.only(top: 40),
                            child: SvgPicture.asset(
                              'assets/images/arrow_bi.svg',
                              color: AppConfig.blueBottomNavigationColor,
                              height: 15,
                              semanticsLabel: 'done',),
                          ),
                          Column(
                            children: [
                              CircleAvatar(
                                radius: 45,
                                backgroundImage: widget.makeWish.user.profile.isNotEmpty ? NetworkImage(widget.makeWish.user.profile) : AssetImage(
                                    'assets/images/user.png'),
                              ),
                              SizedBox(height: 15,),
                              Text('${widget.makeWish.user.displayName}',
                                style: GoogleFonts.montserrat(fontSize: 14.0,
                                    color: AppConfig.white,
                                    fontWeight: FontWeight.w500),),
                            ],
                          ),
                        ],
                      ),
                      SizedBox(height: 30,),
                      Container(
                        height: 40,
                        padding: EdgeInsets.symmetric(horizontal: 10.0),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(25.0),
                          border: Border.all(
                              color: AppConfig.blueUnderlineColor, width: 1),
                        ),
                        child: DropdownButton<Occasion>(
                          isExpanded: true,
                            value: occasion,
                            underline: SizedBox(),
                            iconEnabledColor: AppConfig.white,
                            //dropdownColor: AppConfig.primaryColorDark,
                            items: state.occasions.map((Occasion oc) {
                              return new DropdownMenuItem(
                                value: oc,
                                child: new Text(oc.name,style: TextStyle(color: AppConfig.white),),
                              );
                            }).toList(),
                            hint: Text("Choose an Occasion",style: TextStyle(color: AppConfig.white),),
                            onChanged: (Occasion oc) {
                              setState(() {
                                occasion = oc;
                                print(oc.name);
                              });
                            }),
                      ),
                     /* Wrap(
                          spacing: 10.0,
                          children: state.occasions.map<Widget>(
                                (oc) =>
                                ChoiceChip(
                                  selected: occasion != null ? occasion.id ==
                                      oc.id ? true : false : false,
                                  onSelected: (s) {
                                    setState(() {
                                      occasion = oc;
                                    });
                                  },
                                  label: Text(
                                    '${oc.name}',
                                    style: TextStyle(
                                        fontSize: 15.0, color: AppConfig.white),
                                  ),
                                  backgroundColor: AppConfig
                                      .scaffoldBackgroundColor,
                                  selectedColor: AppConfig.primaryButtonColor,
                                  shape: StadiumBorder(
                                      side: BorderSide(
                                          color: AppConfig.blueUnderlineColor)),
                                ),
                          ).toList()),*/
                      SizedBox(height: 40,),
                      Align(alignment: Alignment.centerLeft,
                          child: Text('Add other information', style: TextStyle(
                              fontSize: 14.0, color: AppConfig.white))),
                      SizedBox(height: 5,),
                      TextField(
                        controller: _textEditingControllerInfo,
                        style: TextStyle(color: AppConfig.white),
                        minLines: 6,
                        maxLines: 10,
                        maxLength: 200,
                        onChanged: (s){
                          // workaround to fix the flutter bug
                          if(_textEditingControllerInfo.text.length>200){
                            _textEditingControllerInfo.text =  _textEditingControllerInfo.text.substring(0,200);
                          }
                          setState(() {

                          });
                        },
                        inputFormatters: [
                          new LengthLimitingTextInputFormatter(200),// for mobile
                        ],
                        decoration: new InputDecoration(
                          counterText: '${_textEditingControllerInfo.text.length.toString()}/200',
                          counterStyle: TextStyle(color: AppConfig.white),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                                color: AppConfig.blueUnderlineColor, width: 1),
                            borderRadius: const BorderRadius.all(
                              const Radius.circular(15.0),
                            ),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                                color: AppConfig.blueUnderlineColor, width: 1),
                            borderRadius: const BorderRadius.all(
                              const Radius.circular(15.0),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 40,),
                      RoundAppButton(
                          padding: MediaQuery
                              .of(context)
                              .size
                              .width * 0.2,
                          title: "Done",
                          titleFontSize: 22.0,
                          onPressed: () {
                            widget.makeWish.otherInfo =
                                _textEditingControllerInfo.text;
                            widget.makeWish.occasion = occasion;
                            Navigator.pop(context, widget.makeWish);
                          }),
                    ],
                  );
                }
                return LoaderAnimation();
              },
            ),
          ),
        ),
      ),
    );
  }
}
