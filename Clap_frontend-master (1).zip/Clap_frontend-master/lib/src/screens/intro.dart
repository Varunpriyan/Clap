import 'dart:io';

import 'package:clap/src/blocs/app_navigator_cubit.dart';
import 'package:clap/src/blocs/user_cubit.dart';
import 'package:clap/src/utils/app_config.dart';
import 'package:clap/src/widgets/round_app_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class IntroScreen extends StatefulWidget {
  @override
  _IntroScreenState createState() => _IntroScreenState();
}

class _IntroScreenState extends State<IntroScreen>
    with SingleTickerProviderStateMixin {
  TabController tabController;
  List<Widget> dots = new List();
  double marginLeftDotFocused = 0;
  double marginRightDotFocused = 0;
  double sizeDot = 5.0;
  double initValueMarginRight;
  UserCubit _userCubit;

  @override
  void initState() {
    tabController = new TabController(length: 2, vsync: this);
    super.initState();
    initValueMarginRight = (sizeDot * 2);
    tabController.addListener(() {
      if (tabController.indexIsChanging) {
        setState(() {});
      }
    });
    tabController.animation.addListener(() {
      this.setState(() {
        marginLeftDotFocused = tabController.animation.value * 3 * 2;
        marginRightDotFocused = tabController.animation.value * 3 * 2;
      });
    });

    _userCubit  = UserCubit();
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener<AppNavigatorCubit, AppNavigatorState>(
      listener: (BuildContext context, state) {
        if (state is AppNavigatorLogin) {
          Navigator.of(context).pushNamed(state.route,arguments: state.isRegister);
        }
        if (state is AppNavigatorHome) {
          Navigator.of(context).pushNamedAndRemoveUntil(
              state.route, (Route<dynamic> route) => false);
        }
      },
      child: Scaffold(
        backgroundColor: AppConfig.scaffoldBackgroundColor,
        body: DefaultTabController(
          length: 2,
          child: Stack(
            children: <Widget>[
              TabBarView(
                children: [
                  Stack(
                    children: [
                      Container(
                        height: double.maxFinite,
                        width: double.maxFinite,
                        child: Image.asset(
                          'assets/images/dark-line-bg.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                      //Make sure to change the values in Native Splash also
                      Align(
                        alignment: Alignment.center,
                        child: Container(
                          padding: EdgeInsets.all(12),
                          child: Image.asset(
                            'assets/images/logo.png',
                            width: MediaQuery.of(context).size.width * 0.5,
                          ),
                        ),
                      ),
                    ],
                  ),
                  Container(
                    height: double.maxFinite,
                    width: double.maxFinite,
                    child: Image.asset(
                      'assets/images/source.gif',
                      fit: BoxFit.cover,
                    ),
                  )
                ],
                controller: tabController,
                physics: ScrollPhysics(),
              ),
              renderBottom(),
            ],
          ),
        ),
        //backgroundColor: Colors.transparent,
      ),
    );
  }

  Widget renderBottom() {
    return Positioned(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          // Dot indicator
          Row(
            children: [
              Flexible(
                  child: Container(
                child: Stack(
                  children: <Widget>[
                    Row(
                      children: this.renderListDots(),
                      mainAxisAlignment: MainAxisAlignment.center,
                    ),
                    Center(
                      child: Container(
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(sizeDot / 2)),
                        width: 12,
                        height: sizeDot,
                        margin: EdgeInsets.only(
                            left: marginLeftDotFocused,
                            right: marginRightDotFocused),
                      ),
                    )
                  ],
                ),
              )),
            ],
          ),
          SizedBox(
            height: 50,
          ),
          Row(
            children: [
              Flexible(
                child: RoundAppButton(
                    title: "Login",
                    onPressed: () {
                      BlocProvider.of<AppNavigatorCubit>(context)
                          .routeToLogin(false,false);
                    }),
              ),
              Flexible(
                child: RoundAppButton(title: "Sign Up", onPressed: () {
                  BlocProvider.of<AppNavigatorCubit>(context)
                      .routeToLogin(true,false);
                }),
              ),
            ],
          ),
          /*Padding(
            padding: const EdgeInsets.all(12.0),
            child: Center(child: Text('OR',style: TextStyle(color: AppConfig.white,fontSize: 18),),),
          ),*/
          SizedBox(height: 20,),
          Platform.isWindows ? BlocBuilder(
            cubit: _userCubit,
              builder: (context,state){
            if(state is SkippedLogin){
              BlocProvider.of<AppNavigatorCubit>(context)
                  .routeToHome();
            }
            return InkWell(
              onTap: (){
                _userCubit.skipLogin();
              },
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Center(child: Text('SKIP',style: TextStyle(color: AppConfig.white,fontSize: 20,fontWeight: FontWeight.w500,decoration: TextDecoration.underline),),),
              ),
            );
          }) : Container()
        ],
      ),
      bottom: 60.0,
      left: 10.0,
      right: 10.0,
    );
  }

  List<Widget> renderListDots() {
    dots.clear();
    for (int i = 0; i < 2; i++) {
      dots.add(renderDot(5, Colors.white, 1, i));
    }
    return dots;
  }

  Widget renderDot(double radius, Color color, double opacity, int i) {
    return Opacity(
      child: Container(
        decoration: BoxDecoration(
            color: color, borderRadius: BorderRadius.circular(radius / 2)),
        width: tabController.index == i ? 15 : 10,
        height: radius,
        margin: EdgeInsets.only(left: 6, right: 6),
      ),
      opacity: opacity,
    );
  }
}
