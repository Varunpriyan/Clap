import 'package:clap/src/blocs/app_navigator_cubit.dart';
import 'package:clap/src/models/profile_response.dart';
import 'package:clap/src/utils/app_config.dart';
import 'package:clap/src/widgets/content_item.dart';
import 'package:flutter/material.dart';
import 'package:clap/src/widgets/round_app_button.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
class AuditionProfile extends StatefulWidget {
  final Profile profile;

  const AuditionProfile({Key key, this.profile}) : super(key: key);
  @override
  _AuditionProfileState createState() => _AuditionProfileState();
}

class _AuditionProfileState extends State<AuditionProfile> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(right: 20,left: 20,top: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: EdgeInsets.symmetric(vertical: 20),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              color: AppConfig.cardBodyColor
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 25,vertical: 4),
                  child: Text(
                    'About Me',
                    style: TextStyle(fontSize: 15, color: AppConfig.white,fontWeight: FontWeight.w500),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 25,vertical: 8),
                  child: Text(
                    '${widget.profile.aboutMe??'NA'}',
                    style: TextStyle(fontSize: 15, color: AppConfig.grey,fontWeight: FontWeight.w400),
                  ),
                ),
                Divider(color: Colors.grey,thickness: 0.1,),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 25,vertical: 4),
                  child: Text(
                    'Personal Details',
                    style: TextStyle(fontSize: 15, color: AppConfig.white,fontWeight: FontWeight.w500),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 25,vertical: 8),
                  child: Row(
                    children: [
                      Expanded(child: ContentItem(title: 'Age',value: '${widget.profile.age==0 ? 'NA' : (widget.profile.age.toString() +' years')}',)),
                      Expanded(child: ContentItem(title: 'Gender',value: '${widget.profile.gender ?? 'NA'}',)),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 25,vertical: 8),
                  child: Row(
                    children: [
                      Expanded(child: ContentItem(title: 'Height',value: '${widget.profile.height=="0.00" ? 'NA' : widget.profile.height} cm',)),
                      SizedBox(width: 4,),
                      Expanded(child: ContentItem(title: 'Weight',value: '${widget.profile.weight=="0.00" ? 'NA' : (widget.profile.weight.toString() +' kg')}',)),
                    ],
                  ),
                ),

                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 25,vertical: 8),
                  child: ContentItem(title: 'Hair Colour',value: '${widget.profile.hairColour??'NA'}',),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 25,vertical: 8),
                  child: ContentItem(title: 'Location',value: '${widget.profile.location??'NA'}',),
                ),
                Divider(color: Colors.grey,thickness: 0.1,),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 25,vertical: 4),
                  child: Text(
                    'Contact Information',
                    style: TextStyle(fontSize: 15, color: AppConfig.white,fontWeight: FontWeight.w500),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 25,vertical: 8),
                  child: ContentItem(title: 'Phone',value: '${widget.profile.phoneNumber}',),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 25,vertical: 8),
                  child: ContentItem(title: 'Email ID',value: '${widget.profile.email}',),
                ),
              ],
            ),
          ),
          SizedBox(height: 30,),
          RoundAppButton(
            color: AppConfig.primaryColorNew,
            title: "Update Profile", onPressed: (){
            BlocProvider.of<AppNavigatorCubit>(context)
                .routeToProfileEdit(profile: widget.profile);
          },padding: MediaQuery.of(context).size.width*0.15,),
          SizedBox(height: 5,),
        ],
      ),
    );
  }
}
