import 'package:clap/src/blocs/app_navigator_cubit.dart';
import 'package:clap/src/blocs/order_cubit.dart';
import 'package:clap/src/models/order.dart';
import 'package:clap/src/utils/app_config.dart';
import 'package:clap/src/widgets/custom_title_bar.dart';
import 'package:clap/src/widgets/empty.dart';
import 'package:clap/src/widgets/loadng.dart';
import 'package:date_format/date_format.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_fonts/google_fonts.dart';

class OrdersScreen extends StatefulWidget {
  @override
  _OrdersScreenState createState() => _OrdersScreenState();
}

class _OrdersScreenState extends State<OrdersScreen> {
  OrderCubit _orderCubit;
  ScrollController _scrollController;
  List<Order> orders;
  @override
  void initState() {
    _orderCubit = OrderCubit();
    _orderCubit.getAllOrders();
    _scrollController = ScrollController()..addListener(_scrollListener);
    orders = [];
    super.initState();
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }
  void _scrollListener() {
    if (_scrollController.position.pixels ==
        _scrollController.position.maxScrollExtent) {
      _orderCubit.getAllOrdersNext();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          controller: _scrollController,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
            child: Column(
              children: [
                CustomTitleBarWidget(
                  title: 'My Orders',
                  hasBackButton: true,
                ),
                SizedBox(
                  height: 40,
                ),
                BlocBuilder(
                  cubit: _orderCubit,
                  buildWhen: (previous, current) => current is OrderInitial || current is OrdersLoading || current is OrdersLoadSuccess ||
                      current is OrdersLoadError || current is OrdersLoadEmpty,
                  builder: (context,state){
                    if (state is OrdersLoadSuccess) {
                      orders = state.orders;
                    }
                    if (state is OrdersLoadEmpty) {
                      if (state.orders != null) {
                        orders = state.orders;
                      } else
                        return EmptyWidget(
                          heading: 'No Orders',
                        );
                    }
                    if (state is OrdersLoadError) {
                      return Center(
                        child: EmptyWidget(
                          heading: 'No Orders',
                        ),
                      );
                    }
                    if(state is OrdersLoading){
                      if(orders.length==0){
                        return LoaderAnimation();
                      }
                    }
                    return ListView.builder(
                        shrinkWrap: true,
                        physics: NeverScrollableScrollPhysics(),
                        itemCount: orders.length,
                        itemBuilder: (context, index) {
                          return InkWell(
                            onTap: (){
                              BlocProvider.of<AppNavigatorCubit>(context)
                                  .routeToOrderDetail(orders[index].id);
                            },
                            child: Container(
                              padding: EdgeInsets.symmetric(horizontal: 20,vertical: 10),
                              margin: EdgeInsets.symmetric(vertical: 10),
                              decoration: new BoxDecoration(
                                  border: new Border.all(
                                      width: 10, color: Colors.transparent),
                                  borderRadius: const BorderRadius.all(
                                      const Radius.circular(15.0)),
                                  //color: new Color.fromRGBO(255, 255, 255, 0.5),
                                  gradient: LinearGradient(
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                    colors: [
                                      AppConfig.primaryColor,
                                      AppConfig.blueBottomNavigationColor
                                    ],
                                    /*stops: [0.2,0.31,0.7,0.9]*/
                                  ) // Specifies the background color and the opacity
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                mainAxisSize: MainAxisSize.max,
                                children: [
                                  Expanded(
                                    child: Column(
                                      children: [
                                        Text(
                                          '${orders[index].status}',
                                          style: GoogleFonts.montserrat(
                                              fontSize: 11.0,
                                              color: AppConfig.white,
                                              fontWeight: FontWeight.w400),
                                          textAlign: TextAlign.left,
                                        ),
                                        Container(
                                          decoration: BoxDecoration(
                                              border: Border(top:  BorderSide(
                                                color: AppConfig.white,
                                                width: 0.5,
                                              ))
                                          ),
                                          child: Text(
                                            'Order ID: ${orders[index].orderId}',
                                            style: TextStyle(
                                                fontSize: 11.0,
                                                color: AppConfig.white,
                                                fontWeight: FontWeight.w400),
                                            textAlign: TextAlign.left,
                                          ),
                                          padding: EdgeInsets.only(top: 5.0),margin: EdgeInsets.only(top: 5.0),
                                        ),
                                      ],
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                    ),
                                  ),
                                  Container(
                                    child: Expanded(
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.end,
                                        children: [
                                          Flexible(
                                            child: Column(
                                              children: [
                                                Text(
                                                  '${formatDate(DateTime.parse(orders[index].date), [dd, '/', mm, '/', yy])}',
                                                  style: GoogleFonts.montserrat(
                                                      fontSize: 11.0,
                                                      color: AppConfig.white,
                                                      fontWeight: FontWeight.w400),
                                                  textAlign: TextAlign.left,
                                                ),
                                                Container(
                                                  decoration: BoxDecoration(
                                                      border: Border(top:  BorderSide(
                                                        color: AppConfig.white,
                                                        width: 0.5,
                                                      ))
                                                  ),
                                                  child: Text(
                                                    orders[index].amount!=null ? '₹ ${orders[index].amount}' : '',
                                                    style: TextStyle(
                                                        fontSize: 11.0,
                                                        color: AppConfig.white,
                                                        fontWeight: FontWeight.w400),
                                                    textAlign: TextAlign.left,
                                                  ),padding: EdgeInsets.only(top: 5.0),margin: EdgeInsets.only(top: 5.0),),
                                              ],
                                            ),
                                          ),
                                          SizedBox(
                                            width: 25,
                                          ),
                                          Center(
                                              child: SvgPicture.asset('assets/images/arrow_right.svg',
                                                color: AppConfig.white,
                                                height: 17,
                                                semanticsLabel: 'arrow_right',))
                                        ],
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            ),
                          );
                        });
                  },
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
