import 'package:clap/src/blocs/app_navigator_cubit.dart';
import 'package:clap/src/blocs/celebrity_cubit.dart';
import 'package:clap/src/blocs/login_cubit.dart';
import 'package:clap/src/blocs/profile_cubit.dart';
import 'package:clap/src/models/models.dart';
import 'package:clap/src/utils/app_config.dart';
import 'package:clap/src/utils/constants.dart';
import 'package:clap/src/widgets/app_underline_input_field.dart';
import 'package:clap/src/widgets/round_app_button.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_fonts/google_fonts.dart';
class CreateProfileScreen extends StatefulWidget {
  @override
  _CreateProfileState createState() => _CreateProfileState();
}

class _CreateProfileState extends State<CreateProfileScreen> {

  ProfileCubit _profileCubit;

  TextEditingController _textEditingControllerName;
  TextEditingController _textEditingControllerEmail;
  CelebrityCubit _celebrityCubit;
  @override
  void initState() {
    _profileCubit = ProfileCubit();
    _textEditingControllerName = TextEditingController();
    _textEditingControllerEmail = TextEditingController();
    _celebrityCubit = CelebrityCubit();
    super.initState();
  }

  @override
  void dispose() {
    _textEditingControllerName.dispose();
    _textEditingControllerEmail.dispose();
    _profileCubit.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppConfig.scaffoldBackgroundColor,
      body: MultiBlocListener(
        listeners: [
          BlocListener(
            cubit: _profileCubit,
            listener: (BuildContext context, state) {
              if (state is ProfileValidationError) {
                String message = 'Validation Error';
                switch (state.field) {
                  case 1:
                    message = 'Invalid Name';
                    break;
                  case 2:
                    message = 'Invalid Email';
                    break;
                }
                Scaffold.of(context).showSnackBar(
                  SnackBar(
                    content: Text(message,style: TextStyle(color: AppConfig.primaryColorDark),),
                    backgroundColor: AppConfig.white,
                  ),
                );
              }
              if (state is ProfileSuccess) {
                if(state.actionState!=null){
                  _celebrityCubit.clearCelebrityActionState();
                  if(state.actionState.actionType=="wish"){
                    BlocProvider.of<
                        AppNavigatorCubit>(
                        context)
                        .routeToMakeWishWhoFor(
                        state.actionState.celebrity,isLater: true);
                  }else{
                    BlocProvider.of<
                        AppNavigatorCubit>(
                        context)
                        .routeToAskQuestion(
                        state.actionState.celebrity,isLater: true);
                  }

                }else{
                  BlocProvider.of<AppNavigatorCubit>(context).routeToHome(showComplete: true);
                }
              }
              if (state is ProfileError) {
                Scaffold.of(context).showSnackBar(
                  SnackBar(
                    content: Text(state.msg,style: TextStyle(color: AppConfig.primaryColorDark),),
                    backgroundColor: AppConfig.white,
                  ),
                );
              }
            },
          ),
          BlocListener<AppNavigatorCubit, AppNavigatorState>(
            listener: (BuildContext context, state) {
              if (state is AppNavigatorHome) {
                Navigator.of(context)
                    .pushNamedAndRemoveUntil(state.route,(Route<dynamic> route) => false,arguments: state.showComplete);
              }
              if (state is AppNavigatorAskQuestion) {
                Navigator.of(context).pushNamedAndRemoveUntil(
                    state.route, ModalRoute.withName(Constants.HOME),
                    arguments: state.celebrity);
              }
              if (state is AppNavigatorMakeWishWhoFor) {
                Navigator.of(context).pushNamedAndRemoveUntil(
                    state.route, ModalRoute.withName(Constants.HOME),
                    arguments: state.celebrity);
              }
              if (state is AppNavigatorIntro) {
                Navigator.of(context).pushNamedAndRemoveUntil(
                    state.route, (Route<dynamic> route) => false);
              }
            },
          )
        ],
        child: SingleChildScrollView(
          child: Container(
            margin: EdgeInsets.symmetric(vertical: 35),
            padding: EdgeInsets.symmetric(horizontal: 44),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Align(
                  alignment: Alignment.center,
                  child: Container(
                    padding: EdgeInsets.all(12),
                    child: Image.asset('assets/images/logo.png',width: MediaQuery.of(context).size.width*0.5,),
                  ),
                ),
                SizedBox(
                  height: 30,
                ),
                Text('Create your profile!',style: GoogleFonts.montserrat(color: AppConfig.titleFontColor,fontSize: 22.0,fontWeight: FontWeight.w500),),
                SizedBox(
                  height: 60,
                ),
                AppUnderlineInputField(title: 'Enter full name*',hint: '',controller: _textEditingControllerName,),
                SizedBox(
                  height: 50,
                ),
                /*AppUnderlineInputField(title: 'Enter registered Mobile*',hint: '',controller: _textEditingControllerMobile,),
                SizedBox(
                  height: 50,
                ),*/
                AppUnderlineInputField(title: 'Enter Email ID*',hint: '',controller: _textEditingControllerEmail,),
                // Adobe XD layer: 'Button' (group)
                SizedBox(
                  height: 60,
                ),
                BlocBuilder(
                    cubit: _profileCubit,
                    builder: (context, state) {
                      bool buttonEnabled = true;
                      if (state is ProfileBusy) {
                        buttonEnabled = false;
                      }
                      return RoundAppButton(
                        isBusy: !buttonEnabled,
                        onPressed: buttonEnabled
                            ? () {
                                _profileCubit.updateProfile(
                                 email: _textEditingControllerEmail.text.trim(),
                                  name: _textEditingControllerName.text.trim(),
                                  isCreate: true
                                );
                              }
                            : null,
                        title: 'Submit',
                        padding: 25,
                      );
                    }),
                SizedBox(
                  height: 20.0,
                ),
                Center(
                  child: TextButton(onPressed: (){
                    _profileCubit.logout();
                    BlocProvider.of<AppNavigatorCubit>(context)
                        .routeToIntro();
                  }, child: Text("Logout",style: TextStyle(color: Colors.white,fontSize: 16),)),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
