import 'dart:ui';

import 'package:clap/src/blocs/app_navigator_cubit.dart';
import 'package:clap/src/blocs/profile_cubit.dart';
import 'package:clap/src/screens/audition_portfolio.dart';
import 'package:clap/src/screens/audition_profile.dart';
import 'package:clap/src/utils/app_config.dart';
import 'package:clap/src/widgets/loadng.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_custom_tab_bar/custom_tab_bar_lib.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:clap/src/screens/audition_menu.dart';
import 'package:clap/src/screens/audition_analytics.dart';
import 'package:clap/src/models/profile_response.dart';
import 'package:ndialog/ndialog.dart';
import 'package:toast/toast.dart';
import 'package:percent_indicator/percent_indicator.dart';

class AuditionHomeScreen extends StatefulWidget {
  @override
  _AuditionHomeScreenState createState() => _AuditionHomeScreenState();
}

class _AuditionHomeScreenState extends State<AuditionHomeScreen> {
  ProfileCubit _profileCubit;
  Profile profile;
  final int pageCount = 3;
  int currentPage = 0;
  PageController _controller = PageController();
  LinearIndicatorController _linearIndicatorController =
      LinearIndicatorController();
  ProgressDialog progressDialog;

  @override
  void initState() {
    _profileCubit = BlocProvider.of<ProfileCubit>(context);
    super.initState();
  }

  @override
  void dispose() {
    _controller.dispose();
    _linearIndicatorController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    _profileCubit.getProfile();
    return SingleChildScrollView(
      physics: ClampingScrollPhysics(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            height: 10,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Align(
              alignment: Alignment.center,
              child: Container(
                padding: EdgeInsets.only(top: 12,left: 12,right: 12),
                child: Text(
                  'Profile',
                  style: GoogleFonts.inter(
                    fontSize: 22,
                    color: AppConfig.titleFontColor,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ),
          ),
          BlocListener<ProfileCubit, ProfileState>(
            listener: (BuildContext context, state) {
              if (state is ProfilePortfolioBusy) {
                progressDialog = ProgressDialog(
                  context,
                  blur: 0,
                  dismissable: false,
                  dialogTransitionType: DialogTransitionType.Shrink,
                  title: Text("Please wait"),
                  message: Text("Uploading media..."),
                  onDismiss: () {},
                );
                progressDialog.setLoadingWidget(BlocBuilder(cubit: _profileCubit,builder: (context, state) {
                  int progress = 0;
                  if(state is ProfilePortfolioBusyProgress)
                    progress = state.progress;
                  return CircularPercentIndicator(
                    radius: 60.0,
                    lineWidth: 5.0,
                    percent: progress/100,
                    center: new Text("$progress%"),
                    progressColor: AppConfig.primaryColor,
                    backgroundColor: AppConfig.scaffoldBackgroundColor,
                  );
                },));
                progressDialog.show();
              }
              if (state is ProfilePortfolioSuccess) {
                progressDialog.dismiss();
                Toast.show("Portfolio added successfully.", context,
                    duration: Toast.LENGTH_LONG, gravity: Toast.BOTTOM);
              }
              if (state is ProfilePortfolioError) {
                progressDialog.dismiss();
                Toast.show("${state.msg}", context,
                    duration: Toast.LENGTH_LONG, gravity: Toast.BOTTOM);
              }

              if (state is ProfilePortfolioDeleteBusy) {
                progressDialog = ProgressDialog(
                  context,
                  blur: 0,
                  dismissable: false,
                  dialogTransitionType: DialogTransitionType.Shrink,
                  title: Text("Please wait"),
                  message: Text("Deleting media..."),
                  onDismiss: () {},
                );
                progressDialog.setLoadingWidget(CircularProgressIndicator(backgroundColor: AppConfig.scaffoldBackgroundColor,valueColor:
                AlwaysStoppedAnimation<Color>(AppConfig.primaryColor)));
                progressDialog.show();
              }
              if (state is ProfilePortfolioDeleteSuccess) {
                progressDialog.dismiss();
                Toast.show("Deleted.", context,
                    duration: Toast.LENGTH_LONG, gravity: Toast.BOTTOM);
              }
              if (state is ProfilePortfolioError) {
                progressDialog.dismiss();
                Toast.show("${state.msg}", context,
                    duration: Toast.LENGTH_LONG, gravity: Toast.BOTTOM);
              }
            },
            child: BlocBuilder(
                cubit: _profileCubit,
                builder: (context, state) {
                  print('here'+state.toString());
                  if (state is ProfileLoading || state is ProfileInitial) {
                    return LoaderAnimation();
                  }
                  if (state is ProfileLoadSuccess) {
                    profile = state.profile;
                  }

                  if (state is ProfilePortfolioSuccess) {
                    if(profile!=null){
                      profile.portfolio.image
                          .addAll(state.portfolioUploadResponse.images);
                      profile.portfolio.video
                          .addAll(state.portfolioUploadResponse.videos);
                    }
                  }

                  if (state is ProfilePortfolioDeleteSuccess) {
                    if(profile!=null){
                      if(state.type=="image"){
                        profile.portfolio.image.removeWhere((item) => item.id == state.id);
                      }else{
                        profile.portfolio.video.removeWhere((item) => item.id == state.id);
                      }
                    }

                  }
                  if (profile != null) {
                    return Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        SizedBox(height: 30,),
                        Column(
                          children: [
                            Align(
                              alignment: Alignment.topCenter,
                              child: Container(
                                  height:140,
                                  width: 140,
                                  decoration: BoxDecoration(
                                    color: AppConfig.cardBodyColor,
                                    shape: BoxShape.circle
                                  ),
                                  child: Center(
                                    child: CircleAvatar(
                                      radius: 35,
                                      backgroundColor: Colors.white,
                                      backgroundImage: profile.profile !=
                                              null
                                          ? NetworkImage(profile.profile)
                                          : AssetImage(
                                              'assets/images/user.png'),
                                    ),
                                  )),
                            ),
                            SizedBox(height: 15,),
                            Text(
                              '${allWordsCapitilize(profile.displayName)}',
                              style: GoogleFonts.inter(
                                  color: AppConfig.white,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w400),
                              textAlign: TextAlign.center,
                            ),
                            SizedBox(height: 25,),
                          ],
                        ),
                        Container(
                          height: 45,
                          color: AppConfig.cardBodyColor,
                          child: Row(
                            mainAxisSize: MainAxisSize.max,
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              GestureDetector(
                                onTap: (){
                                  setState(() {
                                    currentPage = 0;
                                  });
                                },
                                child: Container(
                                  margin: EdgeInsets.symmetric(vertical: 10),
                                  alignment: Alignment.center,
                                  decoration: BoxDecoration(
                                      color: 0==currentPage ? AppConfig.primaryColorNew  : AppConfig.buttonBgColor,
                                      borderRadius: BorderRadius.circular(20)
                                  ),
                                  constraints: BoxConstraints(
                                      minWidth: MediaQuery.of(context).size.width * 0.24),
                                  child: (Text(
                                    'Profile',
                                    style: TextStyle(fontSize: 14, color: Colors.white),
                                  )),
                                ),
                              ),
                              GestureDetector(
                                onTap: (){
                                  setState(() {
                                    currentPage = 1;
                                  });
                                },
                                child: Container(
                                  margin: EdgeInsets.symmetric(vertical: 10),
                                  alignment: Alignment.center,
                                  decoration: BoxDecoration(
                                      color: 1==currentPage ? AppConfig.primaryColorNew  : AppConfig.buttonBgColor,
                                      borderRadius: BorderRadius.circular(20)
                                  ),
                                  constraints: BoxConstraints(
                                      minWidth: MediaQuery.of(context).size.width * 0.24),
                                  child: (Text(
                                    'Portfolio',
                                    style: TextStyle(fontSize: 14, color: Colors.white),
                                  )),
                                ),
                              ),
                              GestureDetector(
                                onTap: (){
                                  setState(() {
                                    currentPage = 2;
                                  });
                                },
                                child: Container(
                                  margin: EdgeInsets.symmetric(vertical: 10),
                                  alignment: Alignment.center,
                                  decoration: BoxDecoration(
                                      color: 2==currentPage ? AppConfig.primaryColorNew  : AppConfig.buttonBgColor,
                                      borderRadius: BorderRadius.circular(20)
                                  ),
                                  constraints: BoxConstraints(
                                      minWidth: MediaQuery.of(context).size.width * 0.24),
                                  child: (Text(
                                    'Status',
                                    style: TextStyle(fontSize: 14, color: Colors.white),
                                  )),
                                ),
                              )
                            ],
                          ),
                        ),
                        AnimatedSwitcher(duration: Duration(milliseconds: 200),
                        child: getChild(),),
                        /*Expanded(
                          child: PageView(
                            controller: _controller,
                            children: [
                              AuditionProfile(
                                profile: profile,
                              ),
                              AuditionPortfolioScreen(
                                profile: profile,
                              ),
                              AuditionAnalyticsScreen(),
                            ],
                          ),
                        )*/
                      ],
                    );
                  }
                  return LoaderAnimation();
                }),
          ),
        ],
      ),
    );
  }

  Widget getChild(){
    switch(currentPage){
      case 0:
       return AuditionProfile(
          profile: profile,
        );
      case 1:
        return AuditionPortfolioScreen(
          profile: profile,
        );
      case 2:
        return AuditionAnalyticsScreen();
    }
  }

  Widget getTabbarChild(BuildContext context, TabBarItemInfo info) {
    return TabBarItem(
      tabbarItemInfo: info,
      delegate: ColorTransformDelegate(
          highlightColor: Colors.white,
          normalColor: Colors.white,
          builder: (context, color) {
            return Container(
              margin: EdgeInsets.symmetric(vertical: 10),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: info.itemIndex==_controller.page ? AppConfig.primaryColor  : AppConfig.buttonBgColor,
                borderRadius: BorderRadius.circular(20)
              ),
              constraints: BoxConstraints(
                  minWidth: MediaQuery.of(context).size.width * 0.24),
              child: (Text(
                '${_getTabName(info.itemIndex)}',
                style: TextStyle(fontSize: 14, color: color),
              )),
            );
          }),
    );
  }

  _getTabName(index) {
    switch (index) {
      case 0:
        return 'Profile';
        break;
      case 1:
        return 'Portfolio';
        break;
      case 2:
        return 'Status';
        break;
    }
  }

  String allWordsCapitilize(String str) {
    return str.toLowerCase().split(' ').map((word) {
      String leftText = (word.length > 1) ? word.substring(1, word.length) : '';
      return word[0].toUpperCase() + leftText;
    }).join(' ');
  }
}
