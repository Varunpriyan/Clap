import 'package:better_player/better_player.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:clap/src/blocs/app_navigator_cubit.dart';
import 'package:clap/src/blocs/celebrity_cubit.dart';
import 'package:clap/src/blocs/user_cubit.dart';
import 'package:clap/src/models/categories_response.dart';
import 'package:clap/src/models/celebrity.dart';
import 'package:clap/src/utils/app_config.dart';
import 'package:clap/src/utils/constants.dart';
import 'package:clap/src/widgets/expandable_text.dart';
import 'package:clap/src/widgets/horizontal_celebrity_list.dart';
import 'package:clap/src/widgets/image_error.dart';
import 'package:clap/src/widgets/loadng.dart';
import 'package:clap/src/widgets/round_app_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:flutter_svg/svg.dart';
import 'package:flutter_swiper/flutter_swiper.dart';
import 'package:google_fonts/google_fonts.dart';

class CelebrityDetailScreen extends StatefulWidget {
  static const String routeName = Constants.CELEBRITY_DETAIL_ROUTE;
  final Celebrity celebrity;

  CelebrityDetailScreen({Key key, this.celebrity}) : super(key: key);

  @override
  _CelebrityDetailScreenState createState() => _CelebrityDetailScreenState();
}

class _CelebrityDetailScreenState extends State<CelebrityDetailScreen> {
  CelebrityCubit _celebrityCubit;
  UserCubit _userCubit;
  bool isSkippedLogIn;

  @override
  void initState() {
    _celebrityCubit = CelebrityCubit();
    _celebrityCubit.getCelebrityDetail(widget.celebrity);
    _userCubit = UserCubit();
    isSkippedLogIn = false;
    _userCubit.getSkipLoginStatus().then((value) => {isSkippedLogIn = value});
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppConfig.white,
      body: SafeArea(
        child: BlocBuilder(
          buildWhen: (previous, current) =>
              current is CelebrityInitial ||
              current is CelebrityLoading ||
              current is CelebrityLoadSuccess ||
              current is CelebrityLoadError ||
              current is CelebrityLoadEmpty,
          cubit: _celebrityCubit,
          builder: (context, state) {
            if (state is CelebrityLoadSuccess) {
              return SingleChildScrollView(
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                      vertical: 30.0, horizontal: 40),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Stack(
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(20),
                            child: CachedNetworkImage(
                              errorWidget: (context, url, error) {
                                return ImageError();
                              },
                              imageUrl: '${state.celebrity.image}',
                              //https://i.pinimg.com/originals/65/c3/1c/65c31cfac905350c751e588bc3869cab.jpg
                              fit: BoxFit.cover,
                              width: double.infinity,
                              height:
                                  (MediaQuery.of(context).size.height * 0.65),
                            ),
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Container(
                                margin: EdgeInsets.all(6),
                                decoration: new BoxDecoration(
                                    border: new Border.all(
                                        width: 10, color: Colors.transparent),
                                    //color is transparent so that it does not blend with the actual color specified
                                    borderRadius: const BorderRadius.all(
                                        const Radius.circular(30.0)),
                                    // color: new Color.fromRGBO(255, 255, 255, 0.7),
                                    gradient: LinearGradient(
                                      begin: Alignment.topLeft,
                                      end: Alignment.bottomRight,
                                      colors: [
                                        Color.fromRGBO(255, 255, 255, 0.14),
                                        Color.fromRGBO(255, 255, 255, 0.1),
                                        Color.fromRGBO(255, 255, 255, 0.01)
                                      ],
                                      /*stops: [0.2,0.31,0.7,0.9]*/
                                    ) // Specifies the background color and the opacity
                                    ),
                                child: GestureDetector(
                                    onTap: () {
                                      if (Navigator.of(context).canPop()) {
                                        Navigator.of(context).pop();
                                      }
                                    },
                                    child: SizedBox(
                                      height: 17,
                                      width: 17,
                                      child: SvgPicture.asset(
                                        'assets/images/arrow_left.svg',
                                        color: AppConfig.darkIconColor,
                                        semanticsLabel: 'arrow_left',
                                      ),
                                    )),
                              ),
                              Container(
                                decoration: new BoxDecoration(
                                    border: new Border.all(
                                        width: 10, color: Colors.transparent),
                                    borderRadius: const BorderRadius.all(
                                        const Radius.circular(30.0)),
                                    //color: new Color.fromRGBO(255, 255, 255, 0.5),
                                    gradient: LinearGradient(
                                      begin: Alignment.topRight,
                                      end: Alignment.bottomLeft,
                                      colors: [
                                        Color.fromRGBO(255, 255, 255, 0.14),
                                        Color.fromRGBO(255, 255, 255, 0.1),
                                        Color.fromRGBO(255, 255, 255, 0.01)
                                      ],
                                      /*stops: [0.2,0.31,0.7,0.9]*/
                                    ) // Specifies the background color and the opacity
                                    ),
                                child: Row(
                                  children: [
                                    GestureDetector(
                                        onTap: () {},
                                        child: Icon(
                                          Icons.share_rounded,
                                          color: AppConfig.darkIconColor,
                                        )),
                                    GestureDetector(
                                        onTap: () {},
                                        child: Icon(
                                          Icons.bookmark_outline_rounded,
                                          color: AppConfig.darkIconColor,
                                        ))
                                  ],
                                ),
                              )
                            ],
                          ),
                          Positioned(
                            bottom: 20.0,
                            left: 10.0,
                            right: 10.0,
                            child: Column(
                              children: [
                                Text(
                                  '${state.celebrity.name}',
                                  style: GoogleFonts.montserrat(
                                      color: AppConfig.white,
                                      fontSize: 22,
                                      fontWeight: FontWeight.w500),
                                  textAlign: TextAlign.center,
                                ),
                                SizedBox(
                                  height: 30,
                                ),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Flexible(
                                      child: RoundAppButton(
                                          padding: 0,
                                          title: "Make a wish!",
                                          titleFontSize: 16.0,
                                          subtitle:
                                              '₹${state.celebrity.makeWishPrice}',
                                          onPressed: () {
                                            if (isSkippedLogIn) {
                                              BlocProvider.of<AppNavigatorCubit>(context)
                                                  .routeToLaterAuth(state.celebrity,"wish");

                                            } else {
                                              BlocProvider.of<
                                                          AppNavigatorCubit>(
                                                      context)
                                                  .routeToMakeWishWhoFor(
                                                      state.celebrity);
                                            }
                                          }),
                                    ),
                                    SizedBox(
                                      width: 20,
                                    ),
                                    Flexible(
                                      child: RoundAppButton(
                                          padding: 0,
                                          title: "Ask a Question",
                                          titleFontSize: 16.0,
                                          subtitle:
                                              '₹${state.celebrity.askQuestionPrice}',
                                          onPressed: () {
                                            if (isSkippedLogIn) {
                                              BlocProvider.of<AppNavigatorCubit>(context)
                                                  .routeToLaterAuth(state.celebrity,"question");

                                            } else {
                                              BlocProvider.of<
                                                          AppNavigatorCubit>(
                                                      context)
                                                  .routeToAskQuestion(
                                                      state.celebrity);
                                            }
                                          }),
                                    ),
                                  ],
                                )
                              ],
                            ),
                          )
                        ],
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Flexible(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    RatingBar(
                                      initialRating: 3.5,
                                      minRating: 1,
                                      direction: Axis.horizontal,
                                      allowHalfRating: true,
                                      itemCount: 5,
                                      ignoreGestures: true,
                                      itemSize: 17.0,
                                      itemPadding:
                                          EdgeInsets.symmetric(horizontal: 1.0),
                                      itemBuilder: (context, _) => Icon(
                                        Icons.star,
                                        color: AppConfig.starRatingColor,
                                      ),
                                      onRatingUpdate: (rating) {
                                        print(rating);
                                      },
                                    ),
                                    Text(
                                      '3.5',
                                      style: TextStyle(
                                          color: AppConfig.darkRatingTextColor,
                                          fontWeight: FontWeight.w500),
                                    )
                                  ],
                                ),
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 4.0, vertical: 4.0),
                                  child: Text(
                                    '100 Reviews',
                                    style: TextStyle(
                                        color:
                                            AppConfig.darkFontColorWithOpacity),
                                  ),
                                )
                              ],
                            ),
                          ),
                          Container(
                              height: 40,
                              child: VerticalDivider(
                                color: AppConfig.darkRatingTextColor,
                                thickness: 0.8,
                              )),
                          Flexible(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        SizedBox(
                                            width: 20,
                                            height: 20,
                                            child: Icon(
                                              Icons.access_time_outlined,
                                              size: 15,
                                            )),
                                        Text(
                                          '${state.celebrity.responseTime}',
                                          style: TextStyle(
                                              color: AppConfig
                                                  .darkRatingTextColor),
                                        )
                                      ],
                                    ),
                                    Row(
                                      children: [
                                        SizedBox(
                                          width: 20,
                                          height: 20,
                                        ),
                                        Text(
                                          'Preparation Time',
                                          style: TextStyle(
                                              color: AppConfig
                                                  .darkFontColorWithOpacity),
                                        )
                                      ],
                                    )
                                  ],
                                ),
                              ],
                            ),
                          )
                        ],
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 20),
                        child: ExpandableText(
                          '${state.celebrity.description}',
                          style: TextStyle(
                              color: AppConfig.detailsTextColor, fontSize: 18),
                          maxLines: 7,
                        ),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Text(
                        'Categories',
                        style: GoogleFonts.montserrat(
                            color: AppConfig.titleBlueFontColor,
                            fontSize: 18,
                            fontWeight: FontWeight.w500),
                        textAlign: TextAlign.center,
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Wrap(
                          spacing: 10.0,
                          children: state.celebrity.category
                              .map<Widget>(
                                (category) => ActionChip(
                                  label: Text(
                                    '${category.name}',
                                    style: TextStyle(fontSize: 15.0),
                                  ),
                                  onPressed: () {
                                    BlocProvider.of<AppNavigatorCubit>(context)
                                        .routeToCelebrityListByCategory(
                                            category);
                                  },
                                  backgroundColor: AppConfig.white,
                                  shape: StadiumBorder(
                                      side: BorderSide(
                                          color: AppConfig.blueUnderlineColor)),
                                ),
                              )
                              .toList()),
                      SizedBox(
                        height: 30,
                      ),
                      state.celebrity.sampleWishes.length > 0
                          ? _previousWishesVideoCarouselWidget(
                              state.celebrity.sampleWishes)
                          : Container(),
                      state.celebrity.relatedCelebrity.length > 0
                          ? HorizontalCelebrityList(
                              isDartText: true,
                              isDarkTitle: true,
                              horizontalPadding: 0.0,
                              onItemSelected: null,
                              category: Category(name: 'Related'),
                              celebrities: state.celebrity.relatedCelebrity,
                              more: false,
                              titleHorizontalPadding: 0.0,
                              onSeeAllSelected: () {
                                /*BlocProvider.of<AppNavigatorCubit>(context)
                        .routeToCelebrityListByCategory();*/
                              },
                            )
                          : Container(),
                      RoundAppButton(
                          padding: 0,
                          title:
                              "Make a wish:₹${state.celebrity.makeWishPrice}",
                          titleFontSize: 22.0,
                          onPressed: () {
                            if (isSkippedLogIn) {
                              BlocProvider.of<AppNavigatorCubit>(context)
                                  .routeToLaterAuth(state.celebrity,"wish");

                            } else {
                              BlocProvider.of<
                                  AppNavigatorCubit>(
                                  context)
                                  .routeToMakeWishWhoFor(
                                  state.celebrity);
                            }
                          }),
                      SizedBox(
                        height: 20,
                      ),
                      RoundAppButton(
                          padding: 0,
                          title:
                              "Ask a Question:₹${state.celebrity.askQuestionPrice}",
                          titleFontSize: 22.0,
                          onPressed: () {
                            if (isSkippedLogIn) {
                              BlocProvider.of<AppNavigatorCubit>(context)
                                  .routeToLaterAuth(state.celebrity,"question");

                            } else {
                              BlocProvider.of<
                                  AppNavigatorCubit>(
                                  context)
                                  .routeToAskQuestion(
                                  state.celebrity);
                            }
                          })
                    ],
                  ),
                ),
              );
            }
            return LoaderAnimation();
          },
        ),
      ),
    );
  }

  Widget _previousWishesVideoCarouselWidget(List<Video> videos) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Celebrity’s Wishes',
          style: GoogleFonts.montserrat(
              color: AppConfig.titleBlueFontColor,
              fontSize: 18,
              fontWeight: FontWeight.w500),
          textAlign: TextAlign.center,
        ),
        SizedBox(
          height: 10,
        ),
        SizedBox(
          height: (MediaQuery.of(context).size.height * 0.4),
          child: PageView.builder(
              itemCount: videos.length,
              itemBuilder: (context, index) {
                return InkWell(
                  onTap: () {},
                  child: Container(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(right: 1),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(20),
                            child: AspectRatio(
                              aspectRatio: 16 / 9,
                              child: BetterPlayer.network(
                                "${videos[index].url}",
                                betterPlayerConfiguration:
                                    BetterPlayerConfiguration(
                                        aspectRatio: 16 / 9,
                                        controlsConfiguration:
                                            BetterPlayerControlsConfiguration(
                                                enableOverflowMenu: false,
                                                enableQualities: false,
                                                enableSubtitles: false)),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              "${videos[index].user}",
                              style: TextStyle(
                                  fontSize: 14, color: AppConfig.darkFontColor),
                            ),
                            /*Text(
                              "For: Name",
                              style: TextStyle(
                                  fontSize: 14, color: AppConfig.darkFontColor),
                            ),*/
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              }),
        )
      ],
    );
  }
}
