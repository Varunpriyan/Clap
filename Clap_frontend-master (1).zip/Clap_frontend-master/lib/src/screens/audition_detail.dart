import 'dart:io';
import 'dart:typed_data';

import 'package:better_player/better_player.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:clap/src/blocs/app_navigator_cubit.dart';
import 'package:clap/src/models/audition_response.dart';
import 'package:clap/src/utils/app_config.dart';
import 'package:clap/src/utils/constants.dart';
import 'package:clap/src/widgets/audition_item_tile.dart';
import 'package:clap/src/widgets/custom_appbar.dart';
import 'package:clap/src/widgets/empty.dart';
import 'package:clap/src/widgets/image_picker.dart';
import 'package:clap/src/widgets/loadng.dart';
import 'package:clap/src/widgets/round_app_button.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:clap/src/blocs/audition_cubit.dart';
import 'package:image_picker/image_picker.dart';
import 'package:ndialog/ndialog.dart';
import 'package:toast/toast.dart';
import 'package:video_thumbnail/video_thumbnail.dart';
class AuditionDetailScreen extends StatefulWidget {
  static const String routeName = Constants.AUDITION_DETAIL;
  final int audition;


  const AuditionDetailScreen({Key key, this.audition}) : super(key: key);
  @override
  _AuditionDetailScreenState createState() => _AuditionDetailScreenState();
}

class _AuditionDetailScreenState extends State<AuditionDetailScreen> {
  AuditionCubit _auditionCubit;
  Audition audition;
  File _pickedVideo;
  ProgressDialog progressDialog;
  final picker = ImagePicker();

  var dialogSetState;

  Uint8List thumb;
  List<String> files = [];

  @override
  void initState() {
    _auditionCubit = AuditionCubit();
    _auditionCubit.getAuditionDetails(widget.audition);
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 10),
            child: BlocListener<AuditionCubit,AuditionState>(
              cubit: _auditionCubit,
              listener: (context, state) {
                if (state is AuditionApplyBusy) {
                  progressDialog = ProgressDialog(
                    context,
                    blur: 0,
                    dismissable: false,
                    dialogTransitionType: DialogTransitionType.Shrink,
                    title: Text("Please wait"),
                    message: Text(_pickedVideo!=null ? "Uploading video..." : "Applying..."),
                    onDismiss: () {},
                  );
                  progressDialog.setLoadingWidget(CircularProgressIndicator());
                  progressDialog.show();
                }
                if (state is AuditionApplySuccess) {
                  progressDialog.dismiss();
                  setState(() {
                    audition.applied= true;
                    audition.status= "PENDING";
                  });
                  /*Toast.show("${state.message}", context,
                      duration: Toast.LENGTH_LONG, gravity: Toast.BOTTOM);*/
                  _showSubmitSuccessDialog();
                }
                if (state is AuditionApplyError) {
                  progressDialog.dismiss();
                  Toast.show("${state.msg}", context,
                      duration: Toast.LENGTH_LONG, gravity: Toast.BOTTOM);
                }
              },
              child: BlocBuilder(
                cubit: _auditionCubit,
                buildWhen: (previous, current) => current is AuditionInitial || current is AuditionDetailsLoading || current is AuditionDetailsLoadSuccess ||
                    current is AuditionDetailsLoadEmpty || current is AuditionDetailsLoadError,
                builder: (context, state) {
                  if (state is AuditionDetailsLoadError || state is AuditionDetailsLoadEmpty) {
                    return Center(
                      child: EmptyWidget(
                        heading: 'Audition not found!',
                      ),
                    );
                  }
                  if(state is AuditionDetailsLoadSuccess){
                    audition = state.audition;
                    return Column(
                      children: [
                        CustomAppBar(
                          title: 'Audition Details',
                          color: AppConfig.white,
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 20),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              SizedBox(
                                height: 15,
                              ),
                              AuditionItemTile(audition: audition,enableClick: false,),
                              SizedBox(height: 15,),
                              Container(
                                padding: EdgeInsets.symmetric(vertical: 20),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(20),
                                  color: AppConfig.cardBodyColor
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.symmetric(horizontal: 30,vertical: 4),
                                      child: Text(
                                        '${audition.otherInfo}',
                                        style: TextStyle(fontSize: 15, color: AppConfig.grey,fontWeight: FontWeight.normal),
                                      ),
                                    ),
                                    Divider(color: Colors.grey,thickness: 0.1,),
                                    Padding(
                                      padding: const EdgeInsets.symmetric(horizontal: 30,vertical: 4),
                                      child: Text(
                                        '${audition.info}',
                                        style: TextStyle(fontSize: 15, color: AppConfig.grey,fontWeight: FontWeight.normal),
                                      ),
                                    ),
                                    Divider(color: Colors.grey,thickness: 0.1,),
                                    audition.production!=null && audition.production!="" ? Padding(
                                      padding: const EdgeInsets.symmetric(horizontal: 30,vertical: 4),
                                      child: Text(
                                        '${audition.production}',
                                        style: TextStyle(fontSize: 15, color: AppConfig.grey,fontWeight: FontWeight.normal),
                                      ),
                                    )  : Container(),
                                    audition.production!=null && audition.production!="" ? Divider(color: Colors.grey,thickness: 0.1,) : Container(),
                                    audition.applied ?  Padding(
                                      padding: const EdgeInsets.symmetric(horizontal: 30,vertical: 4),
                                      child: RichText(
                                        text: TextSpan(
                                            text: 'STATUS: ', style: TextStyle(fontSize: 15, color: AppConfig.grey,fontWeight: FontWeight.w600),children: [
                                            TextSpan(text: '${audition.status}', style: TextStyle(fontSize: 15, color: AppConfig.primaryColorNew,fontWeight: FontWeight.w600))
                                        ])),
                                    ) : SizedBox(),
                                    Padding(
                                      padding: const EdgeInsets.only(left: 30,top: 25,right: 30),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.max,
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          SizedBox(
                                            width: audition.applied ? MediaQuery.of(context).size.width*0.4 : MediaQuery.of(context).size.width*0.3,
                                            child: RoundAppButton(
                                              titleFontSize: 14,
                                              height: 28,
                                              title: audition.applied ? "Already applied" :"Apply", onPressed: audition.applied ? null : (){

                                             // if(audition.isProfileComplete){
                                                if(audition.auditionClip){
                                                  _showSubmitVideoDialog();
                                                }else{
                                                  _auditionCubit.submitApplication(audition: audition.id,path: null);
                                                }

                                             // }else{
                                               // _showCompleteProfileDialog();
                                              //}
                                            },padding: audition.applied ?10 : 12,
                                              color: audition.applied ? AppConfig.lightFontColor : AppConfig.buttonBgColor,),
                                          ),
                                         audition.nextAudition!=null ? SizedBox(
                                            width: MediaQuery.of(context).size.width*0.3,
                                            child: RoundAppButton(
                                              titleFontSize: 14,
                                              height: 28,
                                              title: "Skip", onPressed: (){
                                                Navigator.of(context).pop();
                                                BlocProvider.of<AppNavigatorCubit>(context)
                                                    .routeToAuditionDetail(audition: audition.nextAudition);
                                            },padding: 12,
                                              color: AppConfig.buttonBgColor,),
                                          ) : SizedBox(width: 0,height: 0,)
                                        ],
                                      ),
                                    )

                                  ],
                                ),
                              ),

                            ],
                          ),
                        ),
                      ],
                    );
                  }
                  return LoaderAnimation();
                },
              ),
            ),
          ),
        ),
      ),
    );
  }

  _showUploadVideoDialog(){
    showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return Dialog(
            shape: RoundedRectangleBorder(
                borderRadius:
                BorderRadius.circular(20.0)), //this right here
            child: Container(
              //height: 350,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 30,vertical: 30),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Align(alignment: Alignment.centerRight,child: GestureDetector(onTap: (){
                      Navigator.of(context).pop();
                    },child: Icon(Icons.close_outlined,color: AppConfig.hintTextColor,)),),
                    Text('Audition Application',style: GoogleFonts.montserrat(fontSize: 22.0,color: AppConfig.titleBlueFontColor,fontWeight: FontWeight.w500),),
                    SizedBox(height: 15,),
                    Text(
                      'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Integer lacinia. Praesent dapibus. Duis condimentum augue id magna semper rutrum.',
                      style: TextStyle(fontSize: 15, color: Colors.black54,fontWeight: FontWeight.normal),
                    ),
                    SizedBox(height: 25,),
                    RoundAppButton(title: "Upload from Gallery", onPressed: (){
                      Navigator.of(context).pop();
                      _pickVideo(false);
                    },titleFontSize: 15,),
                    SizedBox(height: 15,),
                    RoundAppButton(title: "Take Video", onPressed: (){
                      Navigator.of(context).pop();
                      _pickVideo(true);
                    },titleFontSize: 15,),
                  ],
                ),
              ),
            ),
          );
        });
  }

  _showSubmitVideoDialog(){
    showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return StatefulBuilder(builder: (context, setState) {
            dialogSetState = setState;
            return Dialog(
              shape: RoundedRectangleBorder(
                  borderRadius:
                  BorderRadius.circular(20.0)), //this right here
              child: Container(
                height: 380,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 30,vertical: 15),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Align(alignment: Alignment.centerRight,child: GestureDetector(onTap: (){
                        Navigator.of(context).pop();
                      },child: Icon(Icons.close_outlined,color: AppConfig.hintTextColor,)),),
                      Text('Submit Audition',style: GoogleFonts.montserrat(fontSize: 22.0,color: AppConfig.titleBlueFontColor,fontWeight: FontWeight.w500),),
                      SizedBox(height: 15,),

                      ImagePickerWidget(enableGallery: true,onSelect: (medias){
                        dialogSetState((){
                          files = medias;
                        });
                      },),
                      SizedBox(height: 20,),
                      /*thumb!=null ? Center(
                        child: Image.memory(thumb,
                          height: 150,
                          fit: BoxFit.cover,),
                      ) : Container(
                        height: 60,
                        width: 60,
                        child: Text(''),
                      ),*/
                      /*Center(child: BetterPlayer.file(
                      "${_pickedVideo.path}",
                      betterPlayerConfiguration: BetterPlayerConfiguration(
                        autoPlay: false,
                        aspectRatio: 16 / 9,
                        fit: BoxFit.contain,
                        controlsConfiguration: BetterPlayerControlsConfiguration(
                            enablePlaybackSpeed: false,
                            enableSubtitles: false,
                            enableQualities: false,
                            enableOverflowMenu: false,
                            loadingColor: Colors.white,
                            enableSkips: false,
                          enableFullscreen: false,
                          enablePlayPause: false,
                          enableProgressBar: false,
                          enableMute: false,
                          backgroundColor: Colors.white,
                          controlBarColor: Colors.transparent
                        ),
                        //fullScreenByDefault: true,
                      ),
                    )),*/
                      /*SizedBox(height: 5,),
                      Center(
                        child: Text(
                          '${_pickedVideo.path.split('/').last}',
                          style: TextStyle(fontSize: 15, color: Colors.black54,fontWeight: FontWeight.normal),
                        ),
                      ),*/
                      SizedBox(height: 20,),
                      RoundAppButton(title: "Submit", onPressed: (){
                        if(files.length>0){
                          Navigator.of(context).pop();
                          _auditionCubit.submitApplication(audition: audition.id,path: files);
                        }else{
                          Toast.show(
                              "Video/Photo is required to apply for this addition!",
                              context,
                              duration: Toast.LENGTH_LONG,
                              gravity: Toast.BOTTOM);
                        }

                      },titleFontSize: 15,),
                    ],
                  ),
                ),
              ),
            );
          },);
        });
  }

  _showSubmitSuccessDialog(){
    showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return Dialog(
            shape: RoundedRectangleBorder(
                borderRadius:
                BorderRadius.circular(20.0)), //this right here
            child: Container(
              height: 220,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 30,vertical: 15),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Align(alignment: Alignment.centerRight,child: GestureDetector(onTap: (){
                      Navigator.of(context).pop();
                    },child: Icon(Icons.close_outlined,color: AppConfig.hintTextColor,)),),
                    SizedBox(height: 25,),
                    Text('Application Submitted!',style: GoogleFonts.montserrat(fontSize: 22.0,color: AppConfig.titleBlueFontColor,fontWeight: FontWeight.w500),),
                    SizedBox(height: 45,),
                    RoundAppButton(title: "Check Status", onPressed: (){
                      Navigator.of(context).pop();
                      Navigator.of(context).pop();
                      BlocProvider.of<AppNavigatorCubit>(context).routeToAuditionStatus();
                    },titleFontSize: 15,),
                  ],
                ),
              ),
            ),
          );
        });
  }

  _showCompleteProfileDialog(){
    showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return Dialog(
            shape: RoundedRectangleBorder(
                borderRadius:
                BorderRadius.circular(20.0)), //this right here
            child: Container(
              height: 280,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 30,vertical: 30),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Align(alignment: Alignment.centerRight,child: GestureDetector(onTap: (){
                      Navigator.of(context).pop();
                    },child: Icon(Icons.close_outlined,color: AppConfig.hintTextColor,)),),
                    Text('Upload Profile Details',style: GoogleFonts.montserrat(fontSize: 22.0,color: AppConfig.titleBlueFontColor,fontWeight: FontWeight.w500),),
                    SizedBox(height: 15,),
                    Text(
                      'To apply for auditions, please update your profile with the required details about yourself.',
                      style: TextStyle(fontSize: 15, color: Colors.black54,fontWeight: FontWeight.normal),
                    ),
                    SizedBox(height: 25,),
                    RoundAppButton(title: "Update Profile", onPressed: (){
                      Navigator.of(context).pop();
                      Navigator.of(context).pop();
                      BlocProvider.of<AppNavigatorCubit>(context)
                          .routeToProfileEdit();
                    },titleFontSize: 15,),
                  ],
                ),
              ),
            ),
          );
        });
  }

  _pickVideo(bool isCamera)async{
    File file;

    if(isCamera){
      final pickedFile = await picker.getVideo(source: isCamera ? ImageSource.camera : ImageSource.gallery,maxDuration: isCamera ?Duration(minutes: 1) : null);
      file = File(pickedFile.path);
    }else{
      FilePickerResult result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['mp4'],
      );

      if (result != null) {
        PlatformFile _file = result.files.single;
        if (_file.extension == 'mp4') {
          file = File(result.files.single.path);
        } else {
          Toast.show("Only mp4 file types are allowed!", context,
              duration: Toast.LENGTH_LONG, gravity: Toast.BOTTOM);
        }
      }
    }


    if(file.lengthSync()>31457280){
      Toast.show("File size should be less than 30MB!", context,
          duration: Toast.LENGTH_LONG, gravity: Toast.BOTTOM);
    }else{
      _pickedVideo = file;
      _showSubmitVideoDialog();
      _getThumb(file.path);
    }
  }

  _getThumb(path)async{
    thumb = await VideoThumbnail.thumbnailData(
      video: path,
      imageFormat: ImageFormat.JPEG,
      maxWidth: 128, // specify the width of the thumbnail, let the height auto-scaled to keep the source aspect ratio
      quality: 25,
    );
    if(mounted)
      if(dialogSetState!=null)
      dialogSetState(() {
        thumb = thumb;
      });
  }

}
