import 'package:clap/src/blocs/app_navigator_cubit.dart';
import 'package:clap/src/blocs/ask_question_cubit.dart';
import 'package:clap/src/blocs/order_cubit.dart';
import 'package:clap/src/models/ask_question.dart';
import 'package:clap/src/models/celebrity.dart';
import 'package:clap/src/models/order.dart';
import 'package:clap/src/utils/app_config.dart';
import 'package:clap/src/utils/constants.dart';
import 'package:clap/src/widgets/custom_title_bar.dart';
import 'package:clap/src/widgets/empty.dart';
import 'package:clap/src/widgets/loadng.dart';
import 'package:clap/src/widgets/round_app_button.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';
import 'package:toast/toast.dart';

class OrderDetailScreen extends StatefulWidget {
  static const String routeName = Constants.ORDER_DETAIL;
  final int order;

  OrderDetailScreen({Key key, this.order}) : super(key: key);
  @override
  _OrderDetailScreenState createState() => _OrderDetailScreenState();
}

class _OrderDetailScreenState extends State<OrderDetailScreen> {
  OrderCubit _orderCubit;
  AskQuestionCubit _askQuestionCubit;
  Razorpay _razorPay;
  Order order;
  bool _isLoading;
  @override
  void initState() {
    print("order detail route");
    _orderCubit = OrderCubit();
    _orderCubit.getOrderDetails(widget.order);
    print(widget.order);
    _askQuestionCubit = AskQuestionCubit();
    _razorPay = Razorpay();
    _razorPay.on(Razorpay.EVENT_PAYMENT_SUCCESS, _handlePaymentSuccess);
    _razorPay.on(Razorpay.EVENT_PAYMENT_ERROR, _handlePaymentError);
    _razorPay.on(Razorpay.EVENT_EXTERNAL_WALLET, _handleExternalWallet);
    _isLoading = false;
    super.initState();
  }

  @override
  void dispose() {
    _razorPay.clear();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: BlocListener(
          cubit: _askQuestionCubit,
          listener: (context,state){
            if (state is PaymentUpdateSuccess ||
                state is PaymentUpdateError ||
                state is PaymentUpdateFailed) {
              Navigator.of(context).pop();
              BlocProvider.of<AppNavigatorCubit>(context)
                  .routeToPaymentStatus(order.id,true);
            }
          },
          child:!_isLoading ? SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40,vertical: 20),
              child: BlocBuilder(
                cubit: _orderCubit,
                buildWhen: (previous, current) => current is OrderInitial || current is OrderDetailsLoading || current is OrderDetailsLoadSuccess ||
                    current is OrderDetailsLoadEmpty || current is OrderDetailsLoadError,
                builder: (context,state){
                  if (state is OrderDetailsLoadError || state is OrderDetailsLoadEmpty) {
                    return Center(
                      child: EmptyWidget(
                        heading: 'Order not found!',
                      ),
                    );
                  }
                  if(state is OrderDetailsLoadSuccess){
                    order = state.order;
                    Celebrity celebrity;
                    if(state.order.question!=null){
                      celebrity = state.order.question.celebrity;
                    }else{
                      celebrity = state.order.booking.celebrity;
                    }
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        CustomTitleBarWidget(title: 'Check Your Order Status',),
                        SizedBox(height: 30,),
                        Text('${state.order.booking!=null ? 'MAKE A WISH' : 'ASK A QUESTION'}!- ${celebrity.name}',style: GoogleFonts.montserrat(fontSize: 14.0,color: AppConfig.white,fontWeight: FontWeight.w500),textAlign: TextAlign.left,),
                        SizedBox(height: 7,),
                        Text('Order ID: ${state.order.orderId}',style: TextStyle(fontSize: 14.0,color: AppConfig.buttonSubtitleTextColor,fontWeight: FontWeight.w100),textAlign: TextAlign.left,),
                        SizedBox(height: 50,),
                        Row(
                          children: [
                            CircleAvatar(child: state.order.placed!=null ? SvgPicture.asset(state.order.placed?'assets/images/done.svg':'assets/images/fail.svg',
                              color: AppConfig.white,
                              height: 15,
                              semanticsLabel: 'done',) : Container(),radius: 17,backgroundColor: AppConfig.blueCircleColor,),
                            Padding(
                              padding: const EdgeInsets.only(left: 20),
                              child: Text("Order Placed",style: TextStyle(fontWeight: FontWeight.w700,fontSize: 22.0,color: AppConfig.white),),
                            ),
                          ],
                        ),
                        Container(
                          width: 1.0,
                          height: 50.0,
                          color: AppConfig.blueUnderlineColor,
                          margin: EdgeInsets.only(left: 15),
                        ),

                        Row(
                          children: [
                            CircleAvatar(child:  state.order.recived!=null ? SvgPicture.asset(state.order.recived?'assets/images/done.svg':'assets/images/fail.svg',
                              color: AppConfig.white,
                              height: 15,
                              semanticsLabel: 'done',) : Container(),radius: 17,backgroundColor: AppConfig.blueCircleColor,),
                            Padding(
                              padding: const EdgeInsets.only(left: 20),
                              child: Text(state.order.recived!=null ? state.order.recived ? "Order Received" : "Payment Failed": "Payment Failed",style: TextStyle(fontWeight: FontWeight.w700,fontSize: 22.0,color: AppConfig.white),),
                            ),
                            SizedBox(width: 10,),
                            state.order.recived==null||state.order.recived==false ? state.order.approved==null || state.order.approved ? SizedBox(height:35,child: TextButton(onPressed: _isLoading ? null : (){
                              print(state.order.rzpOrderid);
                              var options = {
                                'key': '${state.order.keys.test}',
                                'amount': double.parse(state.order.amount) * 100,
                                'name': 'Clap',
                                'order_id': state.order.rzpOrderid,
                                'description': 'Online Items',
                                'prefill': {
                                  'contact': '${state.user.phoneNumber}',
                                  'email': '${state.user.email}'
                                }
                              };
                              _razorPay.open(options);
                              setState(() {
                                _isLoading = true;
                              });

                            }, child: _isLoading ? SizedBox(
                              height: 35,
                              width: 35,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                valueColor:
                                AlwaysStoppedAnimation<Color>(AppConfig.white),
                              ),
                            ) : Text("Retry payment",style: TextStyle(color: AppConfig.white,decoration: TextDecoration.underline),))) : Container(): Container()
                          ],
                        ),
                        Container(
                          width: 1.0,
                          height: 50.0,
                          color: AppConfig.blueUnderlineColor,
                          margin: EdgeInsets.only(left: 15),
                        ),
                        Row(
                          children: [
                            CircleAvatar(child:state.order.approved!=null ? SvgPicture.asset(state.order.approved?'assets/images/done.svg':'assets/images/fail.svg',
                              color: AppConfig.white,
                              height: 15,
                              semanticsLabel: 'done',):Container(),radius: 17,backgroundColor: AppConfig.blueCircleColor,),
                            Padding(
                              padding: const EdgeInsets.only(left: 20),
                              child: Text(state.order.approved!=null ? state.order.approved ?"Order Approved" : "Order Declined" : "Order Approved",style: TextStyle(fontWeight: FontWeight.w700,fontSize: 22.0,color: AppConfig.white),),
                            ),
                          ],
                        ),
                        state.order.approved==null ||state.order.approved ? Wrap(
                          children: [
                            Container(
                              width: 1.0,
                              height: 50.0,
                              color: AppConfig.blueUnderlineColor,
                              margin: EdgeInsets.only(left: 15),
                            ),
                            Row(
                              children: [
                                CircleAvatar(child: state.order.delivered!=null ? SvgPicture.asset(state.order.delivered?'assets/images/done.svg':'assets/images/fail.svg',
                                  color: AppConfig.white,
                                  height: 15,
                                  semanticsLabel: 'done',):Container(),radius: 17,backgroundColor: AppConfig.blueCircleColor,),
                                Padding(
                                  padding: const EdgeInsets.only(left: 20),
                                  child: Text(state.order.delivered==false ? "Order Not Delivered" : "Order Delivered",style: TextStyle(fontWeight: FontWeight.w700,fontSize: 22.0,color: AppConfig.white),),
                                ),
                              ],
                            ),
                          ],
                        ) : Container(),
                        state.order.refund!=null || (state.order.approved!=null&&!state.order.approved)  ? Wrap(
                          children: [
                            Container(
                              width: 1.0,
                              height: 50.0,
                              color: AppConfig.blueUnderlineColor,
                              margin: EdgeInsets.only(left: 15),
                            ),
                            Row(
                              children: [
                                CircleAvatar(child: state.order.refund!=null ? SvgPicture.asset(state.order.refund?'assets/images/done.svg':'assets/images/fail.svg',
                                  color: AppConfig.white,
                                  height: 15,
                                  semanticsLabel: 'done',):Container(),radius: 17,backgroundColor: AppConfig.blueCircleColor,),
                                Padding(
                                  padding: const EdgeInsets.only(left: 20),
                                  child: Text(state.order.refund==null||state.order.refund ? "Refund Processed" : "Refund Not Processed" ,style: TextStyle(fontWeight: FontWeight.w700,fontSize: 22.0,color: AppConfig.white),),
                                ),
                              ],
                            ),
                          ],
                        )  : Container(),
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 40),
                          child: Text(state.order.approved==null||state.order.approved ? 'Estimated Delivery Time: ${celebrity.responseTime}' : '',style: TextStyle(fontSize: 14.0,color: AppConfig.buttonSubtitleTextColor,fontWeight: FontWeight.w100),textAlign: TextAlign.left,),
                        ),
                        RoundAppButton(
                            padding: MediaQuery.of(context).size.width*0.25,
                            title: "Done",
                            isBusy: _isLoading,
                            titleFontSize: 22.0,
                            onPressed: () {
                              Navigator.of(context).pop();
                            }),
                        SizedBox(height: 10,),
                        Center(child: GestureDetector(onTap:(){
                          BlocProvider.of<AppNavigatorCubit>(context)
                              .routeToOrders();
                        },child: Text('Check Other Orders',style: TextStyle(fontSize: 14.0,color: AppConfig.buttonSubtitleTextColor,fontWeight: FontWeight.w100,decoration: TextDecoration.underline),textAlign: TextAlign.center,))),
                      ],
                    );
                  }
                  return LoaderAnimation();
                },
              ),
            ),
          ) : Center(
            child: CircularProgressIndicator(
              strokeWidth: 2,
              valueColor:
              AlwaysStoppedAnimation<Color>(AppConfig.white),
            ),
          ),
        ),
      ),
    );
  }

  void _handlePaymentSuccess(PaymentSuccessResponse response) {
    print('payment succeeds');
    AskQuestionResponse askQuestionResponse = AskQuestionResponse(order: order.id);
    _askQuestionCubit.updatePayment(askQuestionResponse, response.paymentId,order.amount);
  }

  void _handlePaymentError(PaymentFailureResponse response) {
    print(response.message);
   // Toast.show("Payment failed ${response.message}", context, duration: Toast.LENGTH_LONG, gravity:  Toast.BOTTOM);
    Navigator.of(context).pop();
    BlocProvider.of<AppNavigatorCubit>(context)
        .routeToPaymentStatus(order.id,false);
  }

  void _handleExternalWallet(ExternalWalletResponse response) {

  }
}
