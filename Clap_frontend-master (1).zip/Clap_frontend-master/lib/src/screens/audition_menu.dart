import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:clap/src/blocs/app_navigator_cubit.dart';
import 'package:clap/src/utils/app_config.dart';
class AuditionMenuScreen extends StatefulWidget {
  @override
  _AuditionMenuScreenState createState() => _AuditionMenuScreenState();
}

class _AuditionMenuScreenState extends State<AuditionMenuScreen> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 35,vertical: 40),
      child: Column(
        children: [
          InkWell(
            onTap: () {
              BlocProvider.of<AppNavigatorCubit>(context)
                  .routeToAuditions();
            },
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 15),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'View Available Auditions',
                    style: TextStyle(fontSize: 18, color: AppConfig.white),
                  ),
                  Icon(
                    Icons.arrow_forward_ios_rounded,
                    color: AppConfig.white,
                    size: 20,
                  )
                ],
              ),
            ),
          ),
          InkWell(
            onTap: () {
              BlocProvider.of<AppNavigatorCubit>(context).routeToAuditionStatus();
            },
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 15),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Check Applied Audition Status',
                    style: TextStyle(fontSize: 18, color: AppConfig.white),
                  ),
                  Icon(
                    Icons.arrow_forward_ios_rounded,
                    color: AppConfig.white,
                    size: 20,
                  )
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
