import 'dart:ui';

import 'package:clap/src/blocs/app_navigator_cubit.dart';
import 'package:clap/src/blocs/profile_cubit.dart';
import 'package:clap/src/utils/app_config.dart';
import 'package:clap/src/widgets/loadng.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:file_picker/file_picker.dart';
import 'dart:io';
import 'package:clap/src/models/profile_response.dart';
import 'package:toast/toast.dart';
import 'package:clap/src/widgets/round_app_button.dart';

class ProfileScreen extends StatefulWidget {
  @override
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  ProfileCubit _profileCubit;
  Profile profile;
  File _selectedFile;

  @override
  void initState() {
    _profileCubit = ProfileCubit();
    super.initState();
  }

  @override
  void dispose() {
    _profileCubit.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    _profileCubit.getProfile();
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 30),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              height: 10,
            ),
            Align(
              alignment: Alignment.center,
              child: Container(
                padding: EdgeInsets.all(12),
                child: Image.asset(
                  'assets/images/logo.png',
                  width: MediaQuery.of(context).size.width * 0.5,
                ),
              ),
            ),
            SizedBox(
              height: 10,
            ),
            BlocListener(
              cubit: _profileCubit,
              listener: (context, state) {
                if(state is ProfileDeleteSuccess){
                  Toast.show("Profile deleted successfully.", context, duration: Toast.LENGTH_LONG, gravity:  Toast.BOTTOM);
                  _profileCubit.logout();
                  BlocProvider.of<AppNavigatorCubit>(context)
                      .routeToIntro();
                }
                if(state is ProfileDeleteError){
                  Toast.show("Something went wrong! Try again.", context, duration: Toast.LENGTH_LONG, gravity:  Toast.BOTTOM);
                }
              },
              child: BlocBuilder(
                  cubit: _profileCubit,
                  builder: (context, state) {
                    if (state is ProfileLoadSuccess) {
                      profile = state.profile;
                    }
                    if (profile != null) {
                      return Stack(
                        children: [
                          Align(
                            alignment: Alignment.topCenter,
                            child: Container(
                                height: MediaQuery.of(context).size.width * 0.55,
                                width: MediaQuery.of(context).size.width * 0.55,
                                decoration: BoxDecoration(
                                  gradient: RadialGradient(
                                    colors: [
                                      Color(0xff64CEE8),
                                      Color.fromRGBO(118, 173, 215, 0.4),
                                      Color.fromRGBO(210, 0, 123, 0.13),
                                      Color.fromRGBO(210, 0, 123, 0.01)
                                    ],
                                    /*stops: [0.2,0.31,0.7,0.9]*/
                                  ),
                                ),
                                child: Center(
                                  child: Stack(
                                    children: [
                                      CircleAvatar(
                                        radius: 50,
                                        backgroundColor: Colors.white.withOpacity(0.7),
                                        backgroundImage: profile.profile !=
                                                null
                                            ? _selectedFile != null
                                            ? FileImage(_selectedFile) : NetworkImage(profile.profile)
                                            : _selectedFile != null
                                                ? FileImage(_selectedFile)
                                                : AssetImage(
                                                    'assets/images/user.png'),
                                      ),
                                      Positioned(
                                          bottom: 0,
                                          right: 0,
                                          child: GestureDetector(
                                            onTap: () {
                                              _pickImage();
                                            },
                                            child: Container(
                                                padding: EdgeInsets.all(5),
                                                decoration: BoxDecoration(
                                                    color:
                                                        AppConfig.hintTextColor,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            20)),
                                                child: Icon(
                                                  Icons.camera_alt,
                                                  color: AppConfig.darkFontColor,
                                                  size: 15,
                                                )),
                                          ))
                                    ],
                                  ),
                                )),
                          ),
                          Align(
                              alignment: Alignment.topCenter,
                              child: Column(
                                children: [
                                  Text(
                                    '${allWordsCapitilize(profile.displayName)}',
                                    style: GoogleFonts.montserrat(
                                        color: AppConfig.white,
                                        fontSize: 22,
                                        fontWeight: FontWeight.w400),
                                    textAlign: TextAlign.center,
                                  ),
                                  Text(
                                    '${profile.phoneNumber}'.toUpperCase(),
                                    style: GoogleFonts.montserrat(
                                        color: AppConfig.white,
                                        fontSize: 14,
                                        fontWeight: FontWeight.w400),
                                    textAlign: TextAlign.center,
                                  ),
                                ],
                              )),
                          Positioned(
                            bottom: 10,
                            child: Text(
                              'Settings',
                              style: GoogleFonts.montserrat(
                                fontSize: 22,
                                color: AppConfig.titleFontColor,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          )
                        ],
                      );
                    }
                    return Container();
                  }),
            ),
            SizedBox(
              height: 20,
            ),
            InkWell(
              onTap: () {
                BlocProvider.of<AppNavigatorCubit>(context).routeToOrders();
              },
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 15),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Order History',
                      style: TextStyle(fontSize: 18, color: AppConfig.white),
                    ),
                    Icon(
                      Icons.arrow_forward_ios_rounded,
                      color: AppConfig.white,
                      size: 20,
                    )
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 15),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Notification Settings',
                    style: TextStyle(fontSize: 18, color: AppConfig.white),
                  ),
                  Icon(
                    Icons.arrow_forward_ios_rounded,
                    color: AppConfig.white,
                    size: 20,
                  )
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 15),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Privacy policy',
                    style: TextStyle(fontSize: 18, color: AppConfig.white),
                  ),
                  Icon(
                    Icons.arrow_forward_ios_rounded,
                    color: AppConfig.white,
                    size: 20,
                  )
                ],
              ),
            ),
            InkWell(
              onTap: () {
                launch('http://www.getclap.in/privacy-policy/');
              },
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 15),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Security & Privacy',
                      style: TextStyle(fontSize: 18, color: AppConfig.white),
                    ),
                    Icon(
                      Icons.arrow_forward_ios_rounded,
                      color: AppConfig.white,
                      size: 20,
                    )
                  ],
                ),
              ),
            ),
            /*Padding(
              padding: const EdgeInsets.symmetric(vertical: 15),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Terms of Service',
                    style: TextStyle(fontSize: 18, color: AppConfig.white),
                  ),
                  Icon(
                    Icons.arrow_forward_ios_rounded,
                    color: AppConfig.white,
                    size: 20,
                  )
                ],
              ),
            ),*/
            InkWell(
              onTap: () {
                BlocProvider.of<AppNavigatorCubit>(context).routeToContact();
              },
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 15),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Contact Us',
                      style: TextStyle(fontSize: 18, color: AppConfig.white),
                    ),
                    Icon(
                      Icons.arrow_forward_ios_rounded,
                      color: AppConfig.white,
                      size: 20,
                    )
                  ],
                ),
              ),
            ),
            InkWell(
              onTap: () async {
                _showDeleteAccountDialog();
              },
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 15),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Delete profile',
                      style: TextStyle(fontSize: 18, color: AppConfig.white),
                    ),
                    Icon(
                      Icons.arrow_forward_ios_rounded,
                      color: AppConfig.white,
                      size: 20,
                    )
                  ],
                ),
              ),
            ),
            InkWell(
              onTap: () async {
                _showLogoutDialog();
              },
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 15),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Logout',
                      style: TextStyle(fontSize: 18, color: AppConfig.white),
                    ),
                    Icon(
                      Icons.arrow_forward_ios_rounded,
                      color: AppConfig.white,
                      size: 20,
                    )
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  String allWordsCapitilize(String str) {
    return str.toLowerCase().split(' ').map((word) {
      String leftText = (word.length > 1) ? word.substring(1, word.length) : '';
      return word[0].toUpperCase() + leftText;
    }).join(' ');
  }

  _pickImage() async {
    FilePickerResult result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['jpg', 'jpeg', 'png'],
    );

    if (result != null) {
      //File file = File(result.files.single.path);
      PlatformFile file = result.files.single;
      if (file.extension == 'jpg' ||
          file.extension == 'jpeg' ||
          file.extension == 'png') {
        if (file.size > 20971520) {
          Scaffold.of(context).showSnackBar(
            SnackBar(
              content: Text(
                "File size should be less than 20MB!",
                style: TextStyle(color: AppConfig.primaryColorDark),
              ),
              backgroundColor: AppConfig.white,
            ),
          );
        } else {
          setState(() {
            _selectedFile = File(result.files.single.path);
          });
          _profileCubit.updateProfilePicture(path: result.files.single.path);
        }
      } else {
        Scaffold.of(context).showSnackBar(
          SnackBar(
            content: Text(
              "Only jpg/png file types are allowed!",
              style: TextStyle(color: AppConfig.primaryColorDark),
            ),
            backgroundColor: AppConfig.white,
          ),
        );
      }
    }
  }

  _showDeleteAccountDialog(){
    showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return Dialog(
            shape: RoundedRectangleBorder(
                borderRadius:
                BorderRadius.circular(20.0)), //this right here
            child: Container(
              //height: 350,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 30,vertical: 30),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Align(alignment: Alignment.centerRight,child: GestureDetector(onTap: (){
                      Navigator.of(context).pop();
                    },child: Icon(Icons.close_outlined,color: AppConfig.hintTextColor,)),),
                    Text('Delete profile?',style: GoogleFonts.montserrat(fontSize: 22.0,color: AppConfig.titleBlueFontColor,fontWeight: FontWeight.w500),),
                    SizedBox(height: 15,),
                    Text(
                      'Are you sure want to delete your profile?',
                      style: TextStyle(fontSize: 15, color: Colors.black54,fontWeight: FontWeight.normal),
                    ),
                    SizedBox(height: 25,),
                    Row(
                      children: [
                        Expanded(
                          child: RoundAppButton(title: "No", onPressed: (){
                            Navigator.of(context).pop();
                          },titleFontSize: 15,),
                        ),
                        SizedBox(width: 15,),
                        Expanded(
                          child: RoundAppButton(title: "Yes", onPressed: (){
                            _profileCubit.deleteProfile();
                          },titleFontSize: 15,),
                        ),
                      ],
                    ),


                  ],
                ),
              ),
            ),
          );
        });
  }


  _showLogoutDialog(){
    showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return Dialog(
            shape: RoundedRectangleBorder(
                borderRadius:
                BorderRadius.circular(20.0)), //this right here
            child: Container(
              //height: 350,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 30,vertical: 30),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Align(alignment: Alignment.centerRight,child: GestureDetector(onTap: (){
                      Navigator.of(context).pop();
                    },child: Icon(Icons.close_outlined,color: AppConfig.hintTextColor,)),),
                    Text('Logout?',style: GoogleFonts.montserrat(fontSize: 22.0,color: AppConfig.titleBlueFontColor,fontWeight: FontWeight.w500),),
                    SizedBox(height: 15,),
                    Text(
                      'Are you sure want to logout?',
                      style: TextStyle(fontSize: 15, color: Colors.black54,fontWeight: FontWeight.normal),
                    ),
                    SizedBox(height: 25,),
                    Row(
                      children: [
                        Expanded(
                          child: RoundAppButton(title: "No", onPressed: (){
                            Navigator.of(context).pop();
                          },titleFontSize: 15,),
                        ),
                        SizedBox(width: 15,),
                        Expanded(
                          child: RoundAppButton(title: "Yes", onPressed: (){
                            _profileCubit.logout();
                            BlocProvider.of<AppNavigatorCubit>(context)
                                .routeToIntro();
                          },titleFontSize: 15,),
                        ),
                      ],
                    ),


                  ],
                ),
              ),
            ),
          );
        });
  }

}
