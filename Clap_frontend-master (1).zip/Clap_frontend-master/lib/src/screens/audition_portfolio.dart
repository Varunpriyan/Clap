import 'package:clap/src/screens/gallery.dart';
import 'package:clap/src/utils/app_config.dart';
import 'package:clap/src/widgets/VideoTile.dart';
import 'package:clap/src/widgets/round_app_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:clap/src/models/profile_response.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:file_picker/file_picker.dart';
import 'dart:io';
import 'package:clap/src/screens/photo_view.dart';
import 'package:clap/src/screens/video_player.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:clap/src/blocs/profile_cubit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:toast/toast.dart';

class AuditionPortfolioScreen extends StatefulWidget {
  final Profile profile;

  const AuditionPortfolioScreen({Key key, this.profile}) : super(key: key);

  @override
  _AuditionPortfolioScreenState createState() =>
      _AuditionPortfolioScreenState();
}

class _AuditionPortfolioScreenState extends State<AuditionPortfolioScreen> {

  ProfileCubit _profileCubit;

  @override
  void initState() {
    _profileCubit = BlocProvider.of<ProfileCubit>(context);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          widget.profile.portfolio.image.length == 0 &&
                  widget.profile.portfolio.video.length == 0
              ? Padding(
                  padding: const EdgeInsets.symmetric(vertical: 30),
                  child: Center(
                      child: Text(
                    'No portfolio added yet!',
                    style: TextStyle(color: AppConfig.white, fontSize: 16),
                  )),
                )
              : Container(),
          widget.profile.portfolio.image.length > 0
              ? Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Photos',
                      style: TextStyle(
                          fontSize: 18,
                          color: AppConfig.white,
                          fontWeight: FontWeight.bold),
                    ),
                    SizedBox(
                      height: 15,
                    ),
                    GridView.builder(
                      shrinkWrap: true,
                      physics: NeverScrollableScrollPhysics(),
                      itemCount: widget.profile.portfolio.image.length,
                      padding: EdgeInsets.zero,
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        crossAxisSpacing: 16,
                        mainAxisSpacing: 16,
                        childAspectRatio: (1 / 1),
                      ),
                      itemBuilder: (
                        context,
                        index,
                      ) {
                        return GestureDetector(
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) =>  PhotoViewer(
                                  portfolio: widget.profile.portfolio,
                                  tag: '${widget.profile.portfolio.image[index].id}',
                                  index: index,
                                ),
                              ),
                            );
                          },
                          onLongPress: (){
                            _showRemoveDialog("image", widget.profile.portfolio.image[index].id);
                          },
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(4),
                            child: CachedNetworkImage(
                              imageUrl:
                                  widget.profile.portfolio.image[index].file,
                              height: 60,
                              width: 60,
                              fit: BoxFit.cover,
                              placeholder: (context, url) => SizedBox( height: 60,
                                  width: 60,child: Icon(Icons.image,color: Colors.white,size: 60,))
                            ),
                          ),
                        );
                      },
                    ),
                    SizedBox(
                      height: 30,
                    ),
                  ],
                )
              : Container(),
          widget.profile.portfolio.video.length > 0
              ? Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Videos',
                      style: TextStyle(
                          fontSize: 18,
                          color: AppConfig.white,
                          fontWeight: FontWeight.bold),
                    ),
                    SizedBox(
                      height: 15,
                    ),
                    GridView.builder(
                      shrinkWrap: true,
                      physics: NeverScrollableScrollPhysics(),
                      itemCount: widget.profile.portfolio.video.length,
                      padding: EdgeInsets.zero,
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        crossAxisSpacing: 16,
                        mainAxisSpacing: 16,
                        childAspectRatio: (1 / 1),
                      ),
                      itemBuilder: (
                        context,
                        index,
                      ) {
                        return GestureDetector(
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) =>  PhotoViewer(
                                  portfolio: widget.profile.portfolio,
                                  tag: '${widget.profile.portfolio.image[index].id}',
                                  index: index+widget.profile.portfolio.image.length,
                                ),
                              ),
                            );
                          },
                          onLongPress: (){
                            _showRemoveDialog("video",widget.profile.portfolio.video[index].id);
                          },
                          child: VideoTile(path: widget.profile.portfolio.video[index].file),
                        );
                      },
                    ),
                    SizedBox(
                      height: 30,
                    ),
                  ],
                )
              : Container(),
          RoundAppButton(
            color: AppConfig.primaryColorNew,
            title: "Update Media",
            onPressed: () {
              _pickFile();
            },
            padding: MediaQuery.of(context).size.width * 0.15,
          )
        ],
      ),
    );
  }


  _showRemoveDialog(String type, int id){
    showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return Dialog(
            shape: RoundedRectangleBorder(
                borderRadius:
                BorderRadius.circular(20.0)), //this right here
            child: Container(
              //height: 350,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 30,vertical: 30),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Align(alignment: Alignment.centerRight,child: GestureDetector(onTap: (){
                      Navigator.of(context).pop();
                    },child: Icon(Icons.close_outlined,color: AppConfig.hintTextColor,)),),
                    Text('Delete media',style: GoogleFonts.montserrat(fontSize: 22.0,color: AppConfig.titleBlueFontColor,fontWeight: FontWeight.w500),),
                    SizedBox(height: 15,),
                    Text(
                      'Are you sure want to delete this media?',
                      style: TextStyle(fontSize: 15, color: Colors.black54,fontWeight: FontWeight.normal),
                    ),
                    SizedBox(height: 25,),
                    Row(
                      children: [
                        Expanded(
                          child: RoundAppButton(title: "No", onPressed: (){
                            Navigator.of(context).pop();
                          },titleFontSize: 15,),
                        ),
                        SizedBox(width: 15,),
                        Expanded(
                          child: RoundAppButton(title: "Yes", onPressed: (){
                            Navigator.of(context).pop();
                            _profileCubit.deletePortfolio(type: type,id: id);
                          },titleFontSize: 15,),
                        ),
                      ],
                    ),


                  ],
                ),
              ),
            ),
          );
        });
  }

  _pickFile() async {
    FilePickerResult result = Platform.isIOS ? await FilePicker.platform.pickFiles(
      type: FileType.media,
      allowMultiple: true,
    ) : await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowMultiple: true,
      allowedExtensions: ['jpg', 'jpeg', 'png', 'mp4'],
    );

    if (result != null) {
      List<File> videos = [];
      List<File> images = [];

      List<PlatformFile> files = result.files;
      for (var i = 0; i < files.length; i++) {
        if(files[i].extension.toLowerCase() == 'jpg' ||
            files[i].extension.toLowerCase() == 'jpeg' ||
            files[i].extension.toLowerCase() == 'png'){
          if(files[i].size > 20971520){

            Toast.show("Image size should be less than 20MB! Ignoring ${files[i].name}", context,
                duration: Toast.LENGTH_LONG, gravity: Toast.BOTTOM);
          }else{
            images.add(File(files[i].path));
          }
        }else if(files[i].extension.toLowerCase() == 'mp4'){
          if (files[i].size > 31457280) {
            Toast.show("Video size should be less than 30MB! Ignoring ${files[i].name}", context,
                duration: Toast.LENGTH_LONG, gravity: Toast.BOTTOM);
          } else {
            videos.add(File(files[i].path));
          }
        }else{
          Toast.show("Only jpg/png/mp4 file types are allowed! Ignoring ${files[i].name}", context,
              duration: Toast.LENGTH_LONG, gravity: Toast.BOTTOM);
        }
      }


      if(images.length>0 && widget.profile.portfolio.image.length>=10){
        Toast.show("Only 10 photos can be added to your portfolio!", context,
            duration: Toast.LENGTH_LONG, gravity: Toast.BOTTOM);
        images.clear();
      }
      if(videos.length>0 && widget.profile.portfolio.video.length>=2){
        Toast.show("Only 2 videos can be added to your portfolio!", context,
            duration: Toast.LENGTH_LONG, gravity: Toast.BOTTOM);
        videos.clear();
      }

      int remImages = 10 - widget.profile.portfolio.image.length;
      int remVideo = 2 - widget.profile.portfolio.video.length;

      // media qualified to upload
      if(images.length>remImages){
        images = images.take(remImages).toList();
        Toast.show("Only $remImages photos can be added to your portfolio! Ignoring rest of photos.", context,
            duration: Toast.LENGTH_LONG, gravity: Toast.BOTTOM);
      }
      if(videos.length>remVideo){
        videos = videos.take(remVideo).toList();
        Toast.show("Only $remVideo videos can be added to your portfolio! Ignoring rest of videos.", context,
            duration: Toast.LENGTH_LONG, gravity: Toast.BOTTOM);
      }


      print("images:${images.length}");
      print("videos:${videos.length}");

      if(images.length>0||videos.length>0)
      _profileCubit.addPortfolio(files: images..addAll(videos));

    }
  }
}
