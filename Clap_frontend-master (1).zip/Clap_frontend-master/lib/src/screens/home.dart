import 'package:cached_network_image/cached_network_image.dart';
import 'package:clap/src/blocs/app_navigator_cubit.dart';
import 'package:clap/src/blocs/user_cubit.dart';
import 'package:clap/src/models/models.dart';
import 'package:clap/src/screens/coming_soon.dart';
import 'package:clap/src/screens/index.dart';
import 'package:clap/src/screens/intro.dart';
import 'package:clap/src/screens/loginLater.dart';
import 'package:clap/src/screens/profile.dart';
import 'package:clap/src/utils/app_config.dart';
import 'package:clap/src/utils/constants.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:clap/src/screens/audition_home.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:clap/src/screens/auditions.dart';
import 'package:clap/src/widgets/round_app_button.dart';

class HomeScreen extends StatefulWidget {
  static const String routeName = Constants.HOME;
  final bool showComplete;

  const HomeScreen({Key key, this.showComplete = false}) : super(key: key);
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  UserCubit _userCubit;
  int _currentTabIndex = 0;
  bool isSkippedLogIn;
  @override
  void initState() {
    _userCubit = UserCubit();
    isSkippedLogIn = false;

    _userCubit.getSkipLoginStatus().then((value) =>  {
      isSkippedLogIn = value
    });

    if(widget.showComplete){
      Future.delayed(Duration(seconds: 1)).then((value) => BlocProvider.of<AppNavigatorCubit>(context)
          .routeToProfileEdit());
      }

    super.initState();
  }

  @override
  void dispose() {
    _userCubit.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    Widget _child;
    switch (_currentTabIndex) {
      case 0:
        _child = IndexScreen();
        break;
      case 1:
        _child = AuditionsScreen();
        break;
      case 2:
        _child = !isSkippedLogIn ? AuditionHomeScreen() : LoginLaterScreen();
        break;
      case 3:
        _child = !isSkippedLogIn ? ProfileScreen() : LoginLaterScreen();
        break;
    }

    return WillPopScope(
      onWillPop: (){
        if(_currentTabIndex != 0){
          _onTap(0);
          return Future.value(false);
        }
        return Future.value(true);
      },
      child: Scaffold(
        backgroundColor: AppConfig.scaffoldBackgroundColor,
        body: BlocListener<AppNavigatorCubit, AppNavigatorState>(
          listener: (BuildContext context, state) {
            if (state is AppNavigatorLogin) {
              if(!state.isLater){
                Navigator.of(context).pushNamedAndRemoveUntil(
                    state.route, (Route<dynamic> route) => false,arguments: state.isRegister);
              }else{
                Navigator.of(context).pushNamed(
                    state.route,arguments: state.isRegister);
              }

            }
            if (state is AppNavigatorCelebrityListByCategory) {
              Navigator.of(context).pushNamed(
                  state.route,arguments: state.category);
            }
            if (state is AppNavigatorCelebrityDetail) {
              Navigator.of(context).pushNamed(
                  state.route,arguments: state.celebrity);
            }
            if (state is AppNavigatorAskQuestion) {
              if(state.isLater)
                Navigator.of(context).pushNamedAndRemoveUntil(
                    state.route, ModalRoute.withName(Constants.HOME),
                    arguments: state.celebrity);
              else
                Navigator.of(context).pushNamed(
                    state.route,arguments: state.celebrity);
            }
            if (state is AppNavigatorAskQuestionConfirm) {
              Navigator.of(context).pushNamed(
                  state.route,arguments: state.askQuestion);
            }
            if (state is AppNavigatorPaymentStatus) {
              TempOrder order = TempOrder(order: state.order,status: state.status);
              Navigator.of(context).pushNamedAndRemoveUntil(
                  state.route, ModalRoute.withName(state.routeUntil),
                  arguments: order);
            }
            if (state is AppNavigatorOrderDetail) {
              Navigator.of(context).pushNamed(
                  state.route,arguments: state.order);
            }
            if (state is AppNavigatorHome) {
              Navigator.of(context).pushNamedAndRemoveUntil(
                  state.route, (Route<dynamic> route) => false);
            }
            if (state is AppNavigatorOrders) {
              Navigator.of(context).pushNamed(
                  state.route);
            }

            if (state is AppNavigatorMakeWishWhoFor) {
              if(state.isLater)
                Navigator.of(context).pushNamedAndRemoveUntil(
                  state.route, ModalRoute.withName(Constants.HOME),
                  arguments: state.celebrity);
              else
               Navigator.of(context).pushNamed(
                  state.route,arguments: state.celebrity);
            }
            if (state is AppNavigatorMakeWishInputDetails) {
              Navigator.of(context).pushNamed(
                  state.route,arguments: state.makeWish);
            }
            if (state is AppNavigatorMakeWishConfirm) {
              Navigator.of(context).pushNamed(
                  state.route,arguments: state.makeWish);
            }

            if (state is AppNavigatorSearch) {
              Navigator.of(context).pushNamed(
                  state.route,arguments: state.query);
            }
            if (state is AppNavigatorIntro) {
              Navigator.of(context).pushNamedAndRemoveUntil(
                  state.route, (Route<dynamic> route) => false);
            }
            if (state is AppNavigatorLaterAuth) {
              ActionState action  = ActionState(celebrity: state.celebrity,actionType: state.type);
              Navigator.of(context).pushNamed(
                  state.route,arguments: action);
            }
            if (state is AppNavigatorContact) {
              Navigator.of(context).pushNamed(
                  state.route);
            }
            if (state is AppNavigatorProfileEdit) {
              Navigator.of(context).pushNamed(
                  state.route,arguments: state.profile);
            }
            if (state is AppNavigatorAuditions) {
              Navigator.of(context).pushNamed(
                  state.route);
            }
            if (state is AppNavigatorAuditionStatus) {
              Navigator.of(context).pushNamed(
                  state.route);
            }
            if (state is AppNavigatorAuditionDetail) {
              Navigator.of(context).pushNamed(
                  state.route,arguments: state.audition);
            }
          },
          child: SafeArea(child: _child),
        ),
        bottomNavigationBar: _buildBottomNavigationBar(),
      ),
    );
  }

  BottomNavigationBar _buildBottomNavigationBar() {
    return BottomNavigationBar(
      selectedFontSize: 13.0,
      unselectedFontSize: 13.0,
      backgroundColor: AppConfig.bottomNavigationBgColor,
      type: BottomNavigationBarType.fixed,
      items: [
        _bottomNavigationBarItem(
            svgImagePath: 'assets/images/home.svg',
            label: 'Home',
            selected: _currentTabIndex == 0),
        _bottomNavigationBarItem(
            svgImagePath: 'assets/images/audition.svg',
            label: 'Audition',
            selected: _currentTabIndex == 1),
        _bottomNavigationBarItem(
            svgImagePath: 'assets/images/profile.svg',
            label: 'Profile',
            selected: _currentTabIndex == 2),
        _bottomNavigationBarItem(
            svgImagePath: 'assets/images/setting.svg',
            label: 'Settings',
            selected: _currentTabIndex == 3),
      ],
      showSelectedLabels: true,
      showUnselectedLabels: true,
      onTap: _onTap,
      currentIndex: _currentTabIndex,
    );
  }

  BottomNavigationBarItem _bottomNavigationBarItem(
      {String svgImagePath, String label, bool selected}) {
    return BottomNavigationBarItem(
      icon: Container(
        height: 30,
        width: 26,
        padding: EdgeInsets.only(bottom: 4,top: 4),
        child: SvgPicture.asset(svgImagePath,
            color: selected ? AppConfig.bottomNavigationSelectedColor : AppConfig.blueBottomNavigationColor,
            semanticsLabel: label,),
      ),
      title: Text(label,style: GoogleFonts.poppins(color: selected ? AppConfig.bottomNavigationSelectedColor : AppConfig.blueBottomNavigationColor),),
    );
  }

  _onTap(int tabIndex) async{

    if(_currentTabIndex ==4)
      {
        isSkippedLogIn = await _userCubit.getSkipLoginStatus();
        setState(() {
          isSkippedLogIn = isSkippedLogIn;
        });
      }

    setState(() {

    });
    setState(() {
      _currentTabIndex = tabIndex;
    });
  }

  _showCompleteProfileDialog(){
    showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return Dialog(
            shape: RoundedRectangleBorder(
                borderRadius:
                BorderRadius.circular(20.0)), //this right here
            child: Container(
              height: 280,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 30,vertical: 30),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Align(alignment: Alignment.centerRight,child: GestureDetector(onTap: (){
                      Navigator.of(context).pop();
                    },child: Icon(Icons.close_outlined,color: AppConfig.hintTextColor,)),),
                    Text('Upload Profile Details',style: GoogleFonts.montserrat(fontSize: 22.0,color: AppConfig.titleBlueFontColor,fontWeight: FontWeight.w500),),
                    SizedBox(height: 15,),
                    Text(
                      'To apply for auditions, please update your profile with the required details about yourself.',
                      style: TextStyle(fontSize: 15, color: Colors.black54,fontWeight: FontWeight.normal),
                    ),
                    SizedBox(height: 25,),
                    RoundAppButton(title: "Update Profile", onPressed: (){
                      Navigator.of(context).pop();
                      BlocProvider.of<AppNavigatorCubit>(context)
                          .routeToProfileEdit();
                    },titleFontSize: 15,),
                  ],
                ),
              ),
            ),
          );
        });
  }
}
