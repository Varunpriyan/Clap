import 'package:clap/src/blocs/app_navigator_cubit.dart';
import 'package:clap/src/blocs/category_cubit.dart';
import 'package:clap/src/models/categories_response.dart';
import 'package:clap/src/models/celebrity.dart';
import 'package:clap/src/utils/app_config.dart';
import 'package:clap/src/utils/constants.dart';
import 'package:clap/src/widgets/celebrity_grid_item.dart';
import 'package:clap/src/widgets/empty.dart';
import 'package:clap/src/widgets/loadng.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_fonts/google_fonts.dart';

class CelebrityListByCategoryScreen extends StatefulWidget {
  static const String routeName = Constants.CELEBRITY_LIST_BY_CATEGORY;
  final Category category;

  CelebrityListByCategoryScreen({Key key, this.category}) : super(key: key);

  @override
  _CelebrityListByCategoryScreenState createState() =>
      _CelebrityListByCategoryScreenState();
}

class _CelebrityListByCategoryScreenState
    extends State<CelebrityListByCategoryScreen> {
  CategoryCubit _categoryCubit;
  ScrollController _scrollController;
  List<Celebrity> celebrities;
  @override
  void initState() {
    _categoryCubit = CategoryCubit();
    _categoryCubit.getCelebritiesInCategory(widget.category);
    _scrollController = ScrollController()..addListener(_scrollListener);
    celebrities = [];
    super.initState();
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }
  void _scrollListener() {
    if (_scrollController.position.pixels ==
        _scrollController.position.maxScrollExtent) {
      _categoryCubit.getCelebritiesInCategoryNext(widget.category);
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppConfig.white,
      body: SafeArea(
        child: SingleChildScrollView(
          controller: _scrollController,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 25, vertical: 15),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    IconButton(
                        icon: SvgPicture.asset(
                          'assets/images/arrow_left.svg',
                          color: AppConfig.titleBlueFontColor,
                          semanticsLabel: 'arrow_left',
                        ),
                        onPressed: () {
                          if (Navigator.of(context).canPop()) {
                            Navigator.of(context).pop();
                          }
                        }),
                    Text(
                      '${widget.category.name}',
                      style: GoogleFonts.montserrat(
                          color: AppConfig.titleBlueFontColor,
                          fontSize: 22,
                          fontWeight: FontWeight.w500),
                      textAlign: TextAlign.center,
                    )
                  ],
                ),
                SizedBox(
                  height: 15,
                ),
                BlocBuilder(
                  cubit: _categoryCubit,
                    buildWhen: (previous, current) => current is CelebritiesInCategoryLoading || current is CelebritiesInCategoryLoadSuccess ||
                        current is CelebritiesInCategoryLoadEmpty || current is CelebritiesInCategoryLoadError,
                    builder: (context, state) {
                    if (state is CelebritiesInCategoryLoadSuccess) {
                      celebrities = state.celebrities;
                    }
                    if (state is CelebritiesInCategoryLoadEmpty) {
                      if (state.celebrities != null) {
                        celebrities = state.celebrities;
                      } else
                        return EmptyWidget(
                          heading: 'No Celebrities found in this category',
                          darkMode: false,
                        );
                    }
                    if (state is CelebritiesInCategoryLoadError) {
                      return EmptyWidget(
                        heading: 'No Celebrities found in this category',
                        darkMode: false,
                      );
                    }
                    if(state is CelebritiesInCategoryLoading){
                      if(celebrities.length==0){
                        return LoaderAnimation();
                      }
                    }
                    return GridView.count(
                     // controller: _scrollController,
                      physics: NeverScrollableScrollPhysics(),
                      shrinkWrap: true,
                      childAspectRatio: 0.65,
                      crossAxisCount: 2,
                      crossAxisSpacing: 50.0,
                      children: List.generate(celebrities.length, (index) {
                        return GridItemTile(
                          celebrities[index],
                          isInGrid: true,
                          onItemTap: (celebrity) {
                            BlocProvider.of<AppNavigatorCubit>(context)
                                .routeToCelebrityDetail(celebrity);
                          },
                        );
                      }),
                    );


                })
              ],
            ),
          ),
        ),
      ),
    );
  }
}
