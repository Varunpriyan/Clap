import 'package:clap/src/utils/app_config.dart';
import 'package:flutter/material.dart';

class ComingSoonScreen extends StatefulWidget {
  @override
  _ComingSoonScreenState createState() => _ComingSoonScreenState();
}

class _ComingSoonScreenState extends State<ComingSoonScreen> {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text("Coming soon",style: TextStyle(color: AppConfig.white,fontSize: 26),),
    );
  }
}
