import 'package:cached_network_image/cached_network_image.dart';
import 'package:clap/src/models/profile_response.dart';
import 'package:clap/src/utils/app_config.dart';
import 'package:clap/src/utils/constants.dart';
import 'package:clap/src/widgets/VideoTile.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:photo_view/photo_view.dart';
import 'package:scroll_to_index/scroll_to_index.dart';
import 'package:clap/src/screens/video_player.dart';

class PhotoViewer extends StatefulWidget {
  final String tag;
  final Portfolio portfolio;
  final int index;
  static const String routeName = Constants.GALLERY_ROUTE;
  const PhotoViewer({Key key, this.tag, this.portfolio,this.index=0})
      : super(key: key);

  @override
  _PhotoViewerState createState() => _PhotoViewerState();
}

class _PhotoViewerState extends State<PhotoViewer> {
  int _selectedIndex =0;
  PageController pageController = PageController(initialPage: 0);
  AutoScrollController controller;
  List<Widget> _medias = [];
  List<Widget> _thumbs = [];
  @override
  void initState() {
    _selectedIndex = widget.index;
    super.initState();
    controller = AutoScrollController(
        viewportBoundaryGetter: () =>
            Rect.fromLTRB(0, 0, 0, MediaQuery.of(context).padding.bottom),
        axis: Axis.horizontal);

    if(_selectedIndex>0){
      pageController =  PageController(initialPage: _selectedIndex);
      controller.scrollToIndex(_selectedIndex, preferPosition: AutoScrollPosition.middle);
    }
    _medias = widget.portfolio.image.map((photo) => Container(
      color: AppConfig.scaffoldBackgroundColor,
      child: new PhotoView(
        imageProvider: CachedNetworkImageProvider(photo.file),
        heroAttributes: PhotoViewHeroAttributes(tag: "${widget.tag}${photo.id}"),
        backgroundDecoration: BoxDecoration(
            color: AppConfig.scaffoldBackgroundColor
        ),
        initialScale: PhotoViewComputedScale.contained,
      ),
    )).toList();

    _medias.addAll(widget.portfolio.video.map((photo) => Container(child: GestureDetector(onTap: (){
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) =>  VideoPlayer(url: photo.file,),
        ),
      );
    },child: Center(child: new VideoTile(path: photo.file,isFullWidth: true,))))).toList());

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppConfig.scaffoldBackgroundColor,
      body: Stack(
        children: [

          PageView(
            controller: pageController,
            onPageChanged: (page){
              controller.scrollToIndex(page, preferPosition: AutoScrollPosition.begin);
              setState(() {
                _selectedIndex = page;
              });
            },
            children: _medias,
          ),
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              height:  MediaQuery.of(context).size.width*0.25,
              padding: EdgeInsets.all(10),
              color: Colors.white30,
              child: ListView.builder(
                controller: controller,
                physics: BouncingScrollPhysics(),
                scrollDirection: Axis.horizontal,
                shrinkWrap: true,
                itemCount: widget.portfolio.image.length+widget.portfolio.video.length,
                itemBuilder: (context, index) {
                  if(index<widget.portfolio.image.length){
                    return AutoScrollTag(
                      key: ValueKey(index),
                      controller: controller,
                      index: index,
                      child: GestureDetector(
                          onTap: () {
                            setState(() {
                              pageController.animateToPage(index, duration: Duration(seconds: 1), curve: Curves.ease);
                            });
                          },
                          child: Container(
                              height: MediaQuery.of(context).size.width*0.25,
                              width: MediaQuery.of(context).size.width*0.2,
                              decoration: BoxDecoration(
                                border:  _selectedIndex==index? Border.all(color: AppConfig.primaryColor,width: 1) : null,
                                color:  _selectedIndex==index?Colors.white: Colors.transparent,
                              ),
                              padding: EdgeInsets.all(5),

                              child: CachedNetworkImage(
                                  imageUrl: widget.portfolio.image[index].file))),
                    );
                  }else{
                    return AutoScrollTag(
                      key: ValueKey(index),
                      controller: controller,
                      index: index,
                      child: GestureDetector(
                          onTap: () {
                            setState(() {
                              pageController.animateToPage(index, duration: Duration(seconds: 1), curve: Curves.ease);
                            });
                          },
                          child: Container(
                              height: MediaQuery.of(context).size.width*0.25,
                              width: MediaQuery.of(context).size.width*0.2,
                              decoration: BoxDecoration(
                                border:  _selectedIndex==index? Border.all(color: AppConfig.primaryColor,width: 1) : null,
                                color:  _selectedIndex==index?Colors.white: Colors.transparent,
                              ),
                              padding: EdgeInsets.all(5),

                              child: Center(child: VideoTile(path: widget.portfolio.video[index-widget.portfolio.image.length].file,)))),
                    );
                  }

                },
              ),
            ),
          ),
          Positioned(
            top: 30,
            left: 0,
            child: IconButton(
              onPressed: (){
                if(Navigator.of(context).canPop()){
                  Navigator.of(context).pop();
                }
              },
              icon: SvgPicture.asset('assets/images/arrow_left.svg',
                color: AppConfig.white,
                height: 17,
                semanticsLabel: 'arrow_right',),
            ),
          ),
        ],
      ),
    );
  }
}
