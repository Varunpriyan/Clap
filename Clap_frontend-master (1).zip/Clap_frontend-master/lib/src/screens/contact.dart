import 'dart:ui';

import 'package:clap/src/blocs/app_navigator_cubit.dart';
import 'package:clap/src/blocs/profile_cubit.dart';
import 'package:clap/src/utils/app_config.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:url_launcher/url_launcher.dart';

class ContactScreen extends StatefulWidget {
  @override
  _ContactScreenState createState() => _ContactScreenState();
}

class _ContactScreenState extends State<ContactScreen> {

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 30),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                SizedBox(
                  height: 10,
                ),
                Row(
                  children: [
                    GestureDetector(onTap: (){
                      if(Navigator.of(context).canPop()){
                        Navigator.of(context).pop();
                      }
                    },child: Padding(
                      padding: const EdgeInsets.only(right: 15),
                      child: SvgPicture.asset('assets/images/arrow_left.svg',
                        color: AppConfig.white,
                        height: 17,
                        semanticsLabel: 'arrow_right',),
                    )),
                  ],
                ),
                SizedBox(
                  height: 40,
                ),
                Text(
                  'Contact Us',
                  style: GoogleFonts.montserrat(
                    fontSize: 28,
                    color: AppConfig.titleFontColor,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(
                  height: 40,
                ),
                Align(
                  alignment: Alignment.center,
                  child: Container(
                    padding: EdgeInsets.symmetric(vertical: 50),
                    child: Image.asset(
                      'assets/images/logo.png',
                      width: MediaQuery.of(context).size.width * 0.5,
                    ),
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                RichText(
                  text: new TextSpan(
                    children: [
                      new TextSpan(
                        text: 'Email us at: ',
                        style: GoogleFonts.montserrat(
                          fontSize: 18,
                          color: AppConfig.titleFontColor,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      new TextSpan(
                        text: 'info@getclap.in',
                        style: GoogleFonts.montserrat(
                          fontSize: 18,
                          color: AppConfig.blueUnderlineColor,
                          fontWeight: FontWeight.w600,
                        ),
                        recognizer: new TapGestureRecognizer()
                          ..onTap = () {
                            final Uri _emailLaunchUri = Uri(
                                scheme: 'mailto',
                                path: 'info@getclap.in',
                            );
                            launch(_emailLaunchUri.toString());
                          },
                      ),
                    ],
                  ),
                ),
                RichText(
                  text: new TextSpan(
                    children: [
                      new TextSpan(
                        text: 'Phone: ',
                        style: GoogleFonts.montserrat(
                          fontSize: 18,
                          color: AppConfig.titleFontColor,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      new TextSpan(
                        text: '9645555997',
                        style: GoogleFonts.montserrat(
                          fontSize: 18,
                          color: AppConfig.blueUnderlineColor,
                          fontWeight: FontWeight.w600,
                        ),
                        recognizer: new TapGestureRecognizer()
                          ..onTap = () {
                            final Uri _phoneLaunchUri = Uri(
                              scheme: 'tel',
                              path: '9645555997',
                            );
                            launch(_phoneLaunchUri.toString());
                          },
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

}
