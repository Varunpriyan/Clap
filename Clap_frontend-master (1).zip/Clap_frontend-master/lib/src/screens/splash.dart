import 'package:clap/src/blocs/app_navigator_cubit.dart';
import 'package:clap/src/blocs/user_cubit.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  UserCubit _userCubit;

  @override
  void initState() {
    _userCubit= UserCubit();
    super.initState();
  }

  @override
  void dispose() {
    _userCubit.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    //SystemChrome.setEnabledSystemUIOverlays([]);
    _userCubit.checkUserLoggedInStatus();
    return MultiBlocListener(
      listeners: [
        BlocListener<AppNavigatorCubit, AppNavigatorState>(
          listener: (BuildContext context, state) {
            if (state is AppNavigatorLogin) {
              print('login');
              Navigator.of(context).pushReplacementNamed(
                state.route,arguments: state.isRegister
              );
            }
            if (state is AppNavigatorIntro) {
              Navigator.of(context).pushReplacementNamed(
                state.route,
              );
            }
            if (state is AppNavigatorHome) {
              Navigator.of(context).pushNamedAndRemoveUntil(
                  state.route, (Route<dynamic> route) => false);
            }
            if (state is AppNavigatorCreateProfile) {
              Navigator.of(context).pushNamedAndRemoveUntil(
                  state.route, (Route<dynamic> route) => false);
            }
          },
        ),
        BlocListener(
          cubit: _userCubit,
          listener: (BuildContext context, state) {
            if (state is RegisteredUser) {
              if (state.registrationRequired)
                BlocProvider.of<AppNavigatorCubit>(context)
                    .routeToCreateProfile();
              else
                BlocProvider.of<AppNavigatorCubit>(context).routeToHome();
            }
            if (state is LoginRequired) {
              print('login need');
              BlocProvider.of<AppNavigatorCubit>(context)
                  .routeToIntro();
            }if (state is LoggedInStatusCheckInProgress) {
              print('login LoggedInStatusCheckInProgress');
            }
          },
        ),
      ],
      child: Scaffold(
        body: Stack(
          children: [
            Container(
              height: double.maxFinite,
              width: double.maxFinite,
              decoration: BoxDecoration(
                color: new Color(0xff622F74),
                gradient: LinearGradient(
                  colors: [const Color(0xff2F2B49),const Color(0xff1F3A5D), const Color(0xff05527D),const Color(0xff005683) ,const Color(0xff5C307F)],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  stops: [0.1,0.35, 0.6,0.65, 0.95],
                ),
              ),
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Align(alignment: Alignment.center,child: Image.asset('assets/images/logo.png',width: MediaQuery.of(context).size.width*0.5,))
              ],
            ),
          ],
        ),
      ),
    );
  }
}
