import 'package:clap/src/blocs/audition_cubit.dart';
import 'package:clap/src/utils/app_config.dart';
import 'package:clap/src/widgets/audition_item_tile.dart';
import 'package:clap/src/widgets/custom_appbar.dart';
import 'package:clap/src/widgets/empty.dart';
import 'package:clap/src/widgets/loadng.dart';
import 'package:flutter/material.dart';
import 'package:clap/src/models/applied_auditions_response.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
class AuditionStatusScreen extends StatefulWidget {
  @override
  _AuditionStatusScreenState createState() => _AuditionStatusScreenState();
}

class _AuditionStatusScreenState extends State<AuditionStatusScreen> {

  AuditionCubit _auditionCubit;
  ScrollController _scrollController;
  List<Application> applications;

  @override
  void initState() {
    _auditionCubit = AuditionCubit();
    _auditionCubit.getAppliedAuditions();
    _scrollController = ScrollController()..addListener(_scrollListener);
    applications = [];
    super.initState();
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }
  void _scrollListener() {
    if (_scrollController.position.pixels ==
        _scrollController.position.maxScrollExtent) {
      _auditionCubit.getAppliedAuditionsNext();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          controller: _scrollController,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CustomAppBar(
                  title: 'Auditions Status',
                  color: AppConfig.white,
                ),
                SizedBox(
                  height: 35,
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 30),
                  child: BlocBuilder(
                    cubit: _auditionCubit,
                    buildWhen: (previous, current) => current is AuditionInitial || current is AuditionLoading || current is AuditionAppliedLoadSuccess ||
                        current is AuditionAppliedLoadError || current is AuditionAppliedLoadEmpty,
                    builder: (context,state){
                      if (state is AuditionAppliedLoadSuccess) {
                        applications = state.applications;
                      }
                      if (state is AuditionAppliedLoadEmpty) {
                        if (state.applications != null) {
                          applications = state.applications;
                        } else
                          return EmptyWidget(
                            heading: 'Nothing yet.',
                          );
                      }
                      if (state is AuditionAppliedLoadError) {
                        return Center(
                          child: EmptyWidget(
                            heading: 'Nothing yet.',
                          ),
                        );
                      }
                      if(state is AuditionLoading){
                        if(applications.length==0){
                          return LoaderAnimation();
                        }
                      }
                      return ListView.separated(
                        shrinkWrap: true,
                        physics: NeverScrollableScrollPhysics(),
                        itemCount: applications.length,
                        separatorBuilder: (context, index) {
                          return Divider(
                            thickness: 0.15,
                            color: Colors.transparent,
                            height: 25,
                          );
                        },
                        itemBuilder: (context, index) {
                          return applications[index].audition!=null ? AuditionItemTile(audition: applications[index].audition,status: applications[index].status.toString(),) : Container();
                        },);
                    },
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
