import 'dart:async';

import 'package:clap/src/blocs/app_navigator_cubit.dart';
import 'package:clap/src/blocs/celebrity_cubit.dart';
import 'package:clap/src/blocs/firebase_auth_cubit.dart';
import 'package:clap/src/blocs/login_cubit.dart';
import 'package:clap/src/blocs/profile_cubit.dart';
import 'package:clap/src/models/models.dart';
import 'package:clap/src/utils/app_config.dart';
import 'package:clap/src/utils/constants.dart';
import 'package:clap/src/widgets/app_underline_input_field.dart';
import 'package:clap/src/widgets/round_app_button.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
class OtpScreen extends StatefulWidget {
  @override
  _LoginWidgetState createState() => _LoginWidgetState();
}

class _LoginWidgetState extends State<OtpScreen> {

  TextEditingController _textEditingControllerOtp;
  final FirebaseAuthCubit _firebaseAuthCubit = FirebaseAuthCubit();
  LoginCubit _loginCubit;
  CelebrityCubit _celebrityCubit;
  OtpData resendData;
  Timer _timer;
  int _start = 60;
  @override
  void initState() {
    _textEditingControllerOtp = TextEditingController();
    _loginCubit = LoginCubit();
    _celebrityCubit = CelebrityCubit();
    startTimer();
    super.initState();
  }

  void startTimer() {
    const oneSec = const Duration(seconds: 1);
    _timer = new Timer.periodic(
      oneSec,
          (Timer timer) => setState(
            () {
          if (_start < 1) {
            timer.cancel();
          } else {
            _start = _start - 1;
          }
        },
      ),
    );
  }
  @override
  void dispose() {
    _textEditingControllerOtp.dispose();
    _timer.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    OtpData data = ModalRoute.of(context).settings.arguments;
    return Scaffold(
      backgroundColor: AppConfig.scaffoldBackgroundColor,
      body: MultiBlocListener(
        listeners: [
          BlocListener(
            cubit: _loginCubit,
              listener:  (BuildContext context, state) {
                if (state is LoginSuccess) {
                  _timer.cancel();
                  if (state.registrationRequired)
                    BlocProvider.of<AppNavigatorCubit>(context)
                        .routeToCreateProfile();
                  else{
                    BlocProvider.of<ProfileCubit>(context).getProfile();
                    if(state.actionState!=null){
                      _celebrityCubit.clearCelebrityActionState();
                      if(state.actionState.actionType=="wish"){
                        BlocProvider.of<
                            AppNavigatorCubit>(
                            context)
                            .routeToMakeWishWhoFor(
                            state.actionState.celebrity,isLater: true);
                      }else{
                        BlocProvider.of<
                            AppNavigatorCubit>(
                            context)
                            .routeToAskQuestion(
                            state.actionState.celebrity,isLater: true);
                      }

                    }else{
                      BlocProvider.of<AppNavigatorCubit>(context).routeToHome(showComplete: !state.isComplete);
                    }
                  }
                }
                if (state is LoginError) {
                  Scaffold.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Login failed',style: TextStyle(color: AppConfig.primaryColorDark),),
                      backgroundColor: AppConfig.white,
                    ),
                  );
                }
          }),
          BlocListener(
            cubit: _firebaseAuthCubit,
            listener: (BuildContext context, state) {
              if (state is OtpVerificationSuccess) {
                _loginCubit.saveUser(state.user);
              }

              if (state is OtpVerificationFailure) {
                Scaffold.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Invalid OTP',style: TextStyle(color: AppConfig.primaryColorDark),),
                    backgroundColor: AppConfig.white,
                  ),
                );
              }
              if (state is OtpSent) {
                resendData = OtpData(isRegister: data.isRegister,mobile:data.mobile.toString(),token: state.verificationId);
                Scaffold.of(context).showSnackBar(
                  SnackBar(
                    content: Text('OTP Sent',style: TextStyle(color: AppConfig.primaryColorDark),),
                    backgroundColor: AppConfig.white,
                  ),
                );
                _start = 60;
                startTimer();
              }

              if (state is InvalidMobile) {
                Scaffold.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Maximum attempt reached, Try again later.',style: TextStyle(color: AppConfig.primaryColorDark),),
                    backgroundColor: AppConfig.white,
                  ),
                );
              }

            },
          ),
          BlocListener<AppNavigatorCubit, AppNavigatorState>(
            listener: (BuildContext context, state) {
              if (state is AppNavigatorHome) {
                Navigator.of(context)
                    .pushNamedAndRemoveUntil(state.route,(Route<dynamic> route) => false,arguments: state.showComplete);
              }

              if (state is AppNavigatorCreateProfile) {
                Navigator.of(context)
                    .pushNamedAndRemoveUntil(state.route,ModalRoute.withName(Constants.HOME));
              }
              if (state is AppNavigatorAskQuestion) {
                  Navigator.of(context).pushNamedAndRemoveUntil(
                      state.route, ModalRoute.withName(Constants.HOME),
                      arguments: state.celebrity);
              }
              if (state is AppNavigatorMakeWishWhoFor) {
                  Navigator.of(context).pushNamedAndRemoveUntil(
                      state.route, ModalRoute.withName(Constants.HOME),
                      arguments: state.celebrity);
              }
            },
          )
        ],
        child: SingleChildScrollView(
          child: Container(
            margin: EdgeInsets.symmetric(vertical: 35),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                IconButton(
                  onPressed: (){
                    if(Navigator.of(context).canPop()){
                      Navigator.of(context).pop();
                    }
                  },
                  icon: SvgPicture.asset('assets/images/arrow_left.svg',
                    color: AppConfig.white,
                    height: 17,
                    semanticsLabel: 'arrow_right',),
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 44),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        height: 10,
                      ),
                      Align(
                        alignment: Alignment.center,
                        child: Container(
                          padding: EdgeInsets.all(12),
                          child: Image.asset('assets/images/logo.png',width: MediaQuery.of(context).size.width*0.5,),
                        ),
                      ),
                      SizedBox(
                        height: 80,
                      ),
                      SizedBox(
                        height: 60,
                      ),
                      Text(
                        'Enter OTP',
                        style: TextStyle(
                          fontSize: 18,
                          color: AppConfig.white,
                          fontWeight: FontWeight.w100,
                        ),
                      ),
                      SizedBox(
                        height: 30,
                      ),
                      PinCodeTextField(
                        keyboardType: TextInputType.number,
                        appContext: context,
                        length: 6,
                        textStyle: TextStyle(color: AppConfig.white,fontSize: 22),
                        obscureText: false,
                        animationType: AnimationType.fade,
                        pinTheme: PinTheme(
                          shape: PinCodeFieldShape.underline,
                         activeColor: AppConfig.blueUnderlineColor,
                         selectedColor: AppConfig.blueUnderlineColor,
                         inactiveColor: AppConfig.blueUnderlineColor,
                         selectedFillColor: AppConfig.scaffoldBackgroundColor,
                         inactiveFillColor: AppConfig.scaffoldBackgroundColor,
                         /* borderRadius: BorderRadius.circular(5),*/
                          fieldHeight: 50,
                          fieldWidth: 40,
                          activeFillColor: AppConfig.scaffoldBackgroundColor,
                        ),
                        animationDuration: Duration(milliseconds: 300),
                        backgroundColor:AppConfig.scaffoldBackgroundColor,
                        enableActiveFill: true,
                        controller: _textEditingControllerOtp,
                        onCompleted: (v) {
                          print("Completed");
                        },
                        onChanged: (value) {
                          print(value);
                        },
                        beforeTextPaste: (text) {
                          return true;
                        },
                      ),
                      SizedBox(
                        height: 60,
                      ),
                      BlocBuilder(
                          cubit: _firebaseAuthCubit,
                          builder: (context, state) {
                            bool buttonEnabled = true;
                            if (state is OtpVerificationInProgress) {
                              buttonEnabled = false;
                            }
                            return RoundAppButton(
                              isBusy: !buttonEnabled,
                              onPressed: buttonEnabled
                                  ? () {
                                _firebaseAuthCubit.verifyOtp(
                                    otp: _textEditingControllerOtp.text,
                                    verificationId: resendData!=null ? resendData.token : data.token);


                                    }
                                  : null,
                              title: data.isRegister? 'Register' : 'Log In',
                              padding: 25,
                            );
                          }),
                      SizedBox(
                        height: 15.0,
                      ),
                      Center(child: InkWell(
                        onTap:_start >0 ?null : (){
                          _firebaseAuthCubit.verifyPhone(mobile: data.mobile);
                        },
                          child: Text("Resend OTP ${_start >0? "in $_start Sec" : ""}",style: TextStyle(decoration: _start >0 ? TextDecoration.none : TextDecoration.underline,color: Colors.white,fontSize: 18),))),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
