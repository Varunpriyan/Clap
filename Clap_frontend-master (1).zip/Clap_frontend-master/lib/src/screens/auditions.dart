import 'dart:async';

import 'package:clap/src/models/audition_response.dart';
import 'package:clap/src/utils/app_config.dart';
import 'package:clap/src/widgets/audition_item_tile.dart';
import 'package:clap/src/widgets/custom_appbar.dart';
import 'package:clap/src/blocs/audition_cubit.dart';
import 'package:clap/src/widgets/empty.dart';
import 'package:clap/src/widgets/loadng.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class AuditionsScreen extends StatefulWidget {
  @override
  _AuditionsScreenState createState() => _AuditionsScreenState();
}

class _AuditionsScreenState extends State<AuditionsScreen> {

  AuditionCubit _auditionCubit;
  ScrollController _scrollController;
  List<Audition> auditions;
  GlobalKey<RefreshIndicatorState> _globalKeyRefresh = GlobalKey<RefreshIndicatorState>();
  Completer<void> _refreshCompleter;
  @override
  void initState() {
    _refreshCompleter = Completer<void>();
    _auditionCubit = AuditionCubit();
    _auditionCubit.getAllAudition();
    _scrollController = ScrollController()..addListener(_scrollListener);
    auditions = [];
    super.initState();
  }

  void _refreshIndicatorHide() {
    _refreshCompleter?.complete();
    _refreshCompleter = Completer();
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }
  void _scrollListener() {
    if (_scrollController.position.pixels ==
        _scrollController.position.maxScrollExtent) {
      _auditionCubit.getAllAuditionNext();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: RefreshIndicator(
          color: Colors.white,
          key: _globalKeyRefresh,
          onRefresh: () {
            _auditionCubit.getAllAudition();
            return _refreshCompleter.future;
          },
          child: SingleChildScrollView(
            controller: _scrollController,
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 20),
              child: Column(
                children: [
                  CustomAppBar(
                    title: 'Auditions',
                    color: AppConfig.white,
                    showPop: false,
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 30,),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [

                        SizedBox(
                          height: 35,
                        ),
                        BlocBuilder(
                          cubit: _auditionCubit,
                          buildWhen: (previous, current) => current is AuditionInitial || current is AuditionLoading || current is AuditionLoadSuccess ||
                              current is AuditionLoadError || current is AuditionLoadEmpty,
                          builder: (context,state){
                            if (state is AuditionLoadSuccess) {
                              auditions = state.auditions;
                              _refreshIndicatorHide();
                            }
                            if (state is AuditionLoadEmpty) {
                              _refreshIndicatorHide();
                              if (state.auditions != null) {
                                auditions = state.auditions;
                              } else
                                return EmptyWidget(
                                  heading: 'No Auditions',
                                );
                            }
                            if (state is AuditionLoadError) {
                              _refreshIndicatorHide();
                              return Center(
                                child: EmptyWidget(
                                  heading: 'No Auditions',
                                ),
                              );
                            }
                            if(state is AuditionLoading){
                              if(auditions.length==0){
                                return LoaderAnimation();
                              }
                            }
                            return ListView.separated(
                              shrinkWrap: true,
                              physics: NeverScrollableScrollPhysics(),
                              itemCount: auditions.length,
                              separatorBuilder: (context, index) {
                                return Divider(
                                  thickness: 0.15,
                                  color: Colors.transparent,
                                  height: 25,
                                );
                              },
                              itemBuilder: (context, index) {
                                return AuditionItemTile(audition: auditions[index],);
                              },);
                          },
                        )

                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
