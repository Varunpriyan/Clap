import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:photo_view/photo_view.dart';

class HeroPhotoViewRouteWrapper extends StatefulWidget {
  const HeroPhotoViewRouteWrapper({
    this.imageProvider,
    this.backgroundDecoration,
    this.minScale,
    this.maxScale,
    this.tag,
  });

  final ImageProvider imageProvider;
  final Decoration backgroundDecoration;
  final dynamic minScale;
  final dynamic maxScale;
  final dynamic tag;

  @override
  _HeroPhotoViewRouteWrapperState createState() => _HeroPhotoViewRouteWrapperState();
}
const kTranslucentBlackColor = const Color(0x66000000);
const _kMaxDragSpeed = 400.0;

class _HeroPhotoViewRouteWrapperState extends State<HeroPhotoViewRouteWrapper> with TickerProviderStateMixin{
  int _pointersOnScreen = 0;
  bool _isLocked = false;
  AnimationController _offsetController ;
  Animation<Offset> _offsetAnimation;
  Tween<Offset> _offsetTween= Tween<Offset>();
  bool _isDragging = false;

  @override
  initState(){
   _offsetController = AnimationController(vsync:this);
   _opacityController = AnimationController(vsync:this);
    super.initState();
  }

  AnimationController _opacityController;
  Animation<double> _opacityAnimation;
  Tween<double> _opacityTween = Tween<double>();
  double _start;
  @override
  Widget build(BuildContext context) {
    return Listener(
      onPointerDown: (event) {
        _pointersOnScreen++;
        setState(() => _isLocked = _pointersOnScreen >= 2);
      },
      onPointerUp: (event) => _pointersOnScreen--,
      child: GestureDetector(
        dragStartBehavior: DragStartBehavior.down,
        onVerticalDragStart: _isLocked ? null : _onDragStart,
        onVerticalDragUpdate: _isLocked
            ? null
            : (details) {
          _onDrag(details.globalPosition.dy - _start);
        },
        onVerticalDragCancel: _isLocked ? null : () => _onDragEnd(0.0),
        onVerticalDragEnd: _isLocked
            ? null
            : (details) {
          _onDragEnd(details.velocity.pixelsPerSecond.dy);
        },
        child: Container(
          constraints: BoxConstraints.expand(
            height: MediaQuery.of(context).size.height,
          ),
          child: PhotoView(
            imageProvider: widget.imageProvider,
            backgroundDecoration: widget.backgroundDecoration,
            minScale: widget.minScale,
            maxScale: widget.maxScale,
            heroAttributes:  PhotoViewHeroAttributes(tag: "${widget.tag}"),
          ),
        ),
      ),
    );
  }
  void _onDragStart(DragStartDetails details) {
    _start = details.globalPosition.dy;

    setState(() => _isDragging = true);
  }

  void _onDragEnd(double velocity) {
    _start = null;

    if (velocity > _kMaxDragSpeed ||
        _offsetTween.end.dy >= MediaQuery.of(context).size.height / 2) {
      Navigator.of(context).pop();
    } else {
      _opacityTween.begin = _opacityTween.end;
      _opacityTween.end = 1.0;
      _opacityController.duration = Duration(milliseconds: 200);
      _opacityController.reset();
      _opacityController.forward();

      _offsetTween.begin = Offset(0, _offsetTween.end.dy);
      _offsetTween.end = Offset.zero;
      _offsetController.duration = Duration(milliseconds: 200);
      _offsetController.reset();
      _offsetController.forward();
    }

    setState(() => _isDragging = false);
  }
  void _onDrag(double dy) {
    if (dy < 0) {
      return;
    }
    _offsetTween.begin = Offset.zero;
    _offsetTween.end = Offset(0, dy);

    _offsetController.duration = Duration.zero;
    _offsetController.reset();
    _offsetController.forward();

    _opacityTween.begin = _opacityTween.end;
    _opacityTween.end = mapValue(dy, 0, MediaQuery.of(context).size.height, 1.0, 0.0);
    _opacityController.duration = Duration.zero;
    _opacityController.reset();
    _opacityController.forward();
  }
  double mapValue(double value, double low1, double high1, double low2, double high2) {
    return low2 + (high2 - low2) * (value - low1) / (high1 - low1);
  }
}