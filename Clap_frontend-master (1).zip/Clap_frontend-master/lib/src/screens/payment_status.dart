import 'package:clap/src/blocs/app_navigator_cubit.dart';
import 'package:clap/src/models/models.dart';
import 'package:clap/src/utils/app_config.dart';
import 'package:clap/src/widgets/round_app_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_fonts/google_fonts.dart';

class PaymentStatusScreen extends StatefulWidget {
  @override
  _PaymentStatusScreenState createState() => _PaymentStatusScreenState();
}

class _PaymentStatusScreenState extends State<PaymentStatusScreen> {
  @override
  Widget build(BuildContext context) {
    TempOrder order = ModalRoute.of(context).settings.arguments;
    return Scaffold(
      body: BlocListener<AppNavigatorCubit, AppNavigatorState>(
        listener: (BuildContext context, state) {
          if (state is AppNavigatorOrderDetail) {
            Navigator.of(context).pushNamed(
                state.route,arguments: state.order);
          }
          if (state is AppNavigatorHome) {
            Navigator.of(context).pushNamedAndRemoveUntil(
                state.route, (Route<dynamic> route) => false);
          }
        },
        child: SafeArea(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            mainAxisSize: MainAxisSize.max,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              SvgPicture.asset( order.status ? 'assets/images/done.svg' : 'assets/images/fail.svg',
                color: AppConfig.white,
                height: 60,
                semanticsLabel: 'done',),
              SizedBox(height: 30,),
              Text(order.status ? 'Payment Confirmed!' : 'Payment Failed!',style: GoogleFonts.montserrat(fontSize: 22.0,color: AppConfig.white,fontWeight: FontWeight.w500),textAlign: TextAlign.center,),
              SizedBox(height: 7,),
              Text(order.status ? 'Your video order will be sent to you on your email ID.\nProcessing time: 6 days' : 'If your account has been debited, please contact support',style: TextStyle(fontSize: 14.0,color: AppConfig.buttonSubtitleTextColor),textAlign: TextAlign.center,),
              SizedBox(height: 60,),
              RoundAppButton(
                  padding: MediaQuery.of(context).size.width*0.2,
                  title: "Check Order Status",
                  titleFontSize: 22.0,
                  onPressed: () {
                    Navigator.of(context).pop();
                    BlocProvider.of<AppNavigatorCubit>(context)
                        .routeToOrderDetail(order.order);
                  }),
              SizedBox(height: 20,),
              RoundAppButton(
                  padding: MediaQuery.of(context).size.width*0.2,
                  title: "Home Page",
                  titleFontSize: 22.0,
                  onPressed: () {
                     BlocProvider.of<AppNavigatorCubit>(context)
                        .routeToHome();
                  })
            ],
          ),
        ),
      ),
    );
  }
}
