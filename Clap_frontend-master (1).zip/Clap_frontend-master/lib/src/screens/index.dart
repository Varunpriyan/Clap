import 'package:clap/src/blocs/app_navigator_cubit.dart';
import 'package:clap/src/blocs/category_cubit.dart';
import 'package:clap/src/utils/app_config.dart';
import 'package:clap/src/widgets/horizontal_celebrity_list.dart';
import 'package:clap/src/widgets/loadng.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';

class IndexScreen extends StatefulWidget {
  @override
  _IndexScreenState createState() => _IndexScreenState();
}

class _IndexScreenState extends State<IndexScreen> {
  CategoryCubit _categoryCubit;
  @override
  void initState() {
    _categoryCubit = CategoryCubit();
    _categoryCubit.getCategories();
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: BlocBuilder(
        cubit: _categoryCubit,
        buildWhen: (previous, current) => current is CategoryInitial||current is CategoryLoading||current is CategoryLoadSuccess||
            current is CategoryLoadError||current is CategoryLoadEmpty,
        builder: (context,state){
          if(state is CategoryLoading){
            return LoaderAnimation();
          }
          if(state is CategoryLoadSuccess){
            return Column(
              children: [
                Align(
                  alignment: Alignment.center,
                  child: Container(
                    padding: EdgeInsets.only(top: 8),
                    child: Image.asset(
                      'assets/images/logo.png',
                      width: MediaQuery.of(context).size.width * 0.5,
                    ),
                  ),
                ),

                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 30,vertical: 10),
                  child: SizedBox(
                    height: 43,
                    child: TextField(
                      textInputAction: TextInputAction.search,
                      onSubmitted: (q){
                        BlocProvider.of<AppNavigatorCubit>(context)
                            .routeToSearch(q);
                      },
                      style: TextStyle(color: AppConfig.white),
                      decoration: InputDecoration(
                        contentPadding: EdgeInsets.symmetric(vertical: 0,horizontal: 20),
                        prefixIcon: Icon(CupertinoIcons.search,color: AppConfig.lightFontColor,),
                        hintText: "search categories, celebrities, etc",
                        hintStyle: TextStyle(color: AppConfig.lightFontColor,),
                        border: OutlineInputBorder(
                          borderSide: BorderSide(color: AppConfig.blueUnderlineColor,width: 0.3),
                          borderRadius: BorderRadius.circular(30.0),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: AppConfig.blueUnderlineColor,width: 0.3),
                          borderRadius: BorderRadius.circular(30.0),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: AppConfig.blueUnderlineColor,width: 0.3),
                          borderRadius: BorderRadius.circular(30.0),
                        ),
                      ),
                    ),
                  ),
                ),
                Wrap(
                  children: state.categories
                      .map<Widget>((category) => category.celebrities.length >0 ? HorizontalCelebrityList(onItemSelected: null,category: category,celebrities: category.celebrities,more: true,onSeeAllSelected: (){
          BlocProvider.of<AppNavigatorCubit>(context)
              .routeToCelebrityListByCategory(category);
          },):Container()).toList(),
                ),
              ],
            );
          }
         return Container();
        },
      ),
    );
  }
}
