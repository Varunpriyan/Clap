import 'package:cached_network_image/cached_network_image.dart';
import 'package:clap/src/blocs/app_navigator_cubit.dart';
import 'package:clap/src/blocs/make_wish_cubit.dart';
import 'package:clap/src/blocs/profile_cubit.dart';
import 'package:clap/src/models/celebrity.dart';
import 'package:clap/src/models/models.dart';
import 'package:clap/src/utils/app_config.dart';
import 'package:clap/src/utils/constants.dart';
import 'package:clap/src/widgets/app_rounded_input_field.dart';
import 'package:clap/src/widgets/custom_title_bar.dart';
import 'package:clap/src/widgets/image_error.dart';
import 'package:clap/src/widgets/loadng.dart';
import 'package:clap/src/widgets/round_app_button.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_fonts/google_fonts.dart';

class MakeWishInputDetailsScreen extends StatefulWidget {
  static const String routeName = Constants.CELEBRITY_MAKE_WISH_INPUT_DETAILS;
  final MakeWish makeWish;

  MakeWishInputDetailsScreen({Key key, this.makeWish}) : super(key: key);
  @override
  _MakeWishInputDetailsScreenState createState() => _MakeWishInputDetailsScreenState();
}

class _MakeWishInputDetailsScreenState extends State<MakeWishInputDetailsScreen> {
  ProfileCubit _profileCubit;
  MakeWish makeWish;
  MakeWishCubit _makeWishCubit;

  TextEditingController _textEditingControllerIntroduction;
  TextEditingController _textEditingControllerInstruction;

  @override
  void initState() {
    _profileCubit = ProfileCubit();
    _profileCubit.getProfileFromCache();
    makeWish = widget.makeWish;

    _makeWishCubit = MakeWishCubit();

    _textEditingControllerInstruction = TextEditingController();
    _textEditingControllerIntroduction = TextEditingController();
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: MultiBlocListener(
        listeners: [
          BlocListener<AppNavigatorCubit, AppNavigatorState>(
            listener: (BuildContext context, state) async {
              if (state is AppNavigatorMakeWishOccasion) {
                final result = await Navigator.of(context).pushNamed(state.route,arguments: makeWish);
                MakeWish tempWish =result;
                if (tempWish != null) {
                  makeWish.occasion = tempWish.occasion;
                  makeWish.otherInfo = tempWish.otherInfo;
                  setState(() {

                  });
                }
              }
            },
          ),
          BlocListener(
            cubit: _makeWishCubit,
              listener:  (BuildContext context, state) async {
                if (state is MakeWishValidationError) {
                  String message = 'Validation Error';
                  switch (state.field) {
                    case 1:
                      message = 'Please enter your introduction';
                      break;
                    case 2:
                      message = 'Please select a occasion';
                      break;
                    case 3:
                      message = 'Please enter your instructions';
                      break;
                  }
                  Scaffold.of(context).showSnackBar(
                    SnackBar(
                      content: Text("$message",style: TextStyle(color: AppConfig.primaryColorDark),),
                      backgroundColor: AppConfig.white,
                    ),
                  );
                }
                if(state is MakeWishValidationSuccess){
                  BlocProvider.of<AppNavigatorCubit>(context)
                      .routeToMakeWishConfirm(makeWish);
                }
          })
        ],
        child: SafeArea(
          child: BlocBuilder(
            cubit: _profileCubit,
            buildWhen: (previous, current) => current is ProfileInitial ||current is ProfileLoading || current is ProfileLoadSuccess||
                current is ProfileLoadEmpty||current is ProfileLoadError,
            builder: (context,state){
              if(state is ProfileLoadSuccess){
                makeWish.user = state.profile;
                print("im"+state.profile.profile+"age");
                return SingleChildScrollView(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 40,vertical: 20),
                    child: Column(
                      children: [
                        CustomTitleBarWidget(title: 'Request Form',buttonText: 'Cancel',),
                        SizedBox(height: 70,),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Column(
                              children: [
                                CircleAvatar(
                                  radius: 45,
                                  backgroundImage: CachedNetworkImageProvider(
                                    '${makeWish.celebrity.image}',
                                  ),
                                ),
                                SizedBox(height: 15,),
                                Text('${makeWish.celebrity.name}',style: GoogleFonts.montserrat(fontSize: 14.0,color: AppConfig.white,fontWeight: FontWeight.w500),),
                              ],
                            ),
                            Padding(
                              padding: EdgeInsets.only(top: 40),
                              child: SvgPicture.asset('assets/images/arrow_bi.svg',
                                color: AppConfig.blueBottomNavigationColor,
                                height: 15,
                                semanticsLabel: 'done',),
                            ),
                            Column(
                              children: [
                                CircleAvatar(
                                  radius: 45,
                                  backgroundImage: state.profile.profile.isNotEmpty ? NetworkImage(state.profile.profile) : AssetImage('assets/images/user.png'),
                                ),
                                SizedBox(height: 15,),
                                Text('${state.profile.displayName}',style: GoogleFonts.montserrat(fontSize: 14.0,color: AppConfig.white,fontWeight: FontWeight.w500),),
                              ],
                            ),
                          ],
                        ),
                        SizedBox(height: 30,),
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 12.0),
                          child: AppRoundedInputField(hint: makeWish.forWho=='me' ? 'Introduce yourself' : 'Introduce your friend',controller: _textEditingControllerIntroduction,maxLength: 200,),
                        ),
                        GestureDetector(onTap:(){
                          BlocProvider.of<AppNavigatorCubit>(context)
                              .routeToMakeWishOccasion(makeWish);
                        },child: Container(
                          padding: EdgeInsets.symmetric(vertical: 10.0,horizontal: 20.0),
                          margin: EdgeInsets.symmetric(vertical: 12.0),
                          height: 44,
                          width: double.infinity,
                          decoration: new BoxDecoration(
                            border: new Border.all(
                                width: 1, color: AppConfig.blueBottomNavigationColor),
                            borderRadius: const BorderRadius.all(
                                const Radius.circular(30.0)),
                            //color: new Color.fromRGBO(255, 255, 255, 0.5),// Specifies the background color and the opacity
                          ),
                          child: Text(makeWish.occasion==null ? 'Select Occasion' : makeWish.occasion.name,style:  TextStyle(fontSize: 18.0,color: makeWish.occasion==null ? AppConfig.lightFontColor :
                          AppConfig.white),),
                        )),

                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 12.0),
                          child: TextField(
                            controller: _textEditingControllerInstruction,
                            style: TextStyle(color: AppConfig.white),
                            minLines: 6,
                            maxLines: 10,
                            maxLength: 200,
                            onChanged: (s){
                              // workaround to fix the flutter bug
                              if(_textEditingControllerInstruction.text.length>200){
                                _textEditingControllerInstruction.text =  _textEditingControllerInstruction.text.substring(0,200);
                              }
                              setState(() {});
                            },
                            inputFormatters: [
                              new LengthLimitingTextInputFormatter(200),// for mobile
                            ],
                            decoration: new InputDecoration(
                              counterText: '${_textEditingControllerInstruction.text.length.toString()}/200',
                              counterStyle: TextStyle(color: AppConfig.white),
                              hintText: 'Add instructions (required)',
                              hintStyle: TextStyle(color: AppConfig.lightFontColor,),
                              /*counterText: '${_textEditingControllerInstruction.text.length}',*/
                              focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(color: AppConfig.blueUnderlineColor, width: 1),
                                borderRadius: const BorderRadius.all(
                                  const Radius.circular(15.0),
                                ),
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(color: AppConfig.blueUnderlineColor, width: 1),
                                borderRadius: const BorderRadius.all(
                                  const Radius.circular(15.0),
                                ),
                              ),
                            ),
                          ),
                        ),
                        /*Padding(
                          padding: const EdgeInsets.symmetric(vertical: 12.0),
                          child: AppRoundedInputField(hint: 'Other Info Button',readOnly: true,),
                        ),*/
                        SizedBox(height: 40,),
                        RoundAppButton(
                            padding: MediaQuery.of(context).size.width*0.2,
                            title: "Next",
                            titleFontSize: 22.0,
                            onPressed: () {
                              makeWish.introduction = _textEditingControllerIntroduction.text.trim();
                              makeWish.instruction = _textEditingControllerInstruction.text.trim();
                             _makeWishCubit.validateInput(instruction: _textEditingControllerInstruction.text.trim(),introduction: _textEditingControllerIntroduction.text.trim(),occasion: makeWish.occasion);
                            }),
                      ],
                    ),
                  ),
                );
              }
              return LoaderAnimation();
            },
          ),
        ),
      ),
    );
  }
}
