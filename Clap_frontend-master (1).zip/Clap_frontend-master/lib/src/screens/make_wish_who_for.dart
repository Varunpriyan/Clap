import 'package:cached_network_image/cached_network_image.dart';
import 'package:clap/src/blocs/app_navigator_cubit.dart';
import 'package:clap/src/models/celebrity.dart';
import 'package:clap/src/models/models.dart';
import 'package:clap/src/utils/app_config.dart';
import 'package:clap/src/widgets/custom_title_bar.dart';
import 'package:clap/src/widgets/image_error.dart';
import 'package:clap/src/widgets/round_app_button.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';

class MakeWishWhoForScreen extends StatefulWidget {
  @override
  _MakeWishWhoForScreenState createState() => _MakeWishWhoForScreenState();
}

class _MakeWishWhoForScreenState extends State<MakeWishWhoForScreen> {
  @override
  Widget build(BuildContext context) {
    Celebrity celebrity = ModalRoute.of(context).settings.arguments;
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 40,vertical: 20),
            child: Column(
              children: [
                CustomTitleBarWidget(title: 'Request Form',buttonText: 'Cancel',),
                SizedBox(height: 70,),
                CircleAvatar(
                  radius: 61.0,
                  backgroundImage: CachedNetworkImageProvider(
                    '${celebrity.image}',
                  ),
                ),
                SizedBox(height: 15,),
                Text('${celebrity.name}',style: GoogleFonts.montserrat(fontSize: 22.0,color: AppConfig.white,fontWeight: FontWeight.w500),),
                SizedBox(height: 70,),
                Text('Who is this Request for?',style: TextStyle(fontSize: 18.0,color: AppConfig.white)),
                SizedBox(height: 40,),
                RoundAppButton(
                    padding: MediaQuery.of(context).size.width*0.2,
                    title: "For Me",
                    titleFontSize: 22.0,
                    onPressed: () {
                      MakeWish makeWish = MakeWish(celebrity: celebrity,forWho: "me");
                      BlocProvider.of<AppNavigatorCubit>(context)
                          .routeToMakeWishInputDetails(makeWish);
                    }),
                SizedBox(height: 20,),
                RoundAppButton(
                    padding: MediaQuery.of(context).size.width*0.2,
                    title: "For A Friend",
                    titleFontSize: 22.0,
                    onPressed: () {
                      MakeWish makeWish = MakeWish(celebrity: celebrity,forWho: "friend");
                      BlocProvider.of<AppNavigatorCubit>(context)
                          .routeToMakeWishInputDetails(makeWish);
                    })
              ],
            ),
          ),
        ),
      ),
    );
  }
}
