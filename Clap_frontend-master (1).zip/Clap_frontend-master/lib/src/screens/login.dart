import 'package:clap/src/blocs/app_navigator_cubit.dart';
import 'package:clap/src/blocs/celebrity_cubit.dart';
import 'package:clap/src/blocs/firebase_auth_cubit.dart';
import 'package:clap/src/blocs/login_cubit.dart';
import 'package:clap/src/models/models.dart';
import 'package:clap/src/utils/app_config.dart';
import 'package:clap/src/utils/constants.dart';
import 'package:clap/src/widgets/app_underline_input_field.dart';
import 'package:clap/src/widgets/round_app_button.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl_phone_number_input/intl_phone_number_input.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginWidgetState createState() => _LoginWidgetState();
}

class _LoginWidgetState extends State<LoginScreen> {


  TextEditingController _mobileNumberController;

  String _mobileNumber;

  String _mobileIsoCode = 'IN';

  final FirebaseAuthCubit _firebaseAuthCubit = FirebaseAuthCubit();
  LoginCubit _loginCubit;

  CelebrityCubit _celebrityCubit;
  @override
  void initState() {
    _mobileNumberController = TextEditingController();
    _loginCubit = LoginCubit();
    _celebrityCubit = CelebrityCubit();
    super.initState();
  }

  @override
  void dispose() {
    _mobileNumberController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    bool isRegister = ModalRoute.of(context).settings.arguments ?? false;
    return Scaffold(
      backgroundColor: AppConfig.scaffoldBackgroundColor,
      body: MultiBlocListener(
        listeners: [
          BlocListener(
              cubit: _loginCubit,
              listener:  (BuildContext context, state) {
                if (state is LoginSuccess) {
                  _mobileNumberController.clear();
                  if (state.registrationRequired)
                    BlocProvider.of<AppNavigatorCubit>(context)
                        .routeToCreateProfile();
                  else{
                    if(state.actionState!=null){
                      _celebrityCubit.clearCelebrityActionState();
                      if(state.actionState.actionType=="wish"){
                        BlocProvider.of<
                            AppNavigatorCubit>(
                            context)
                            .routeToMakeWishWhoFor(
                            state.actionState.celebrity,isLater: true);
                      }else{
                        BlocProvider.of<
                            AppNavigatorCubit>(
                            context)
                            .routeToAskQuestion(
                            state.actionState.celebrity,isLater: true);
                      }

                    }else{
                      BlocProvider.of<AppNavigatorCubit>(context).routeToHome();
                    }
                  }

                }
                if (state is LoginError) {
                  Scaffold.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Login Failed'),
                    ),
                  );
                }
                if (state is LoginPhoneError) {
                  Scaffold.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Login Failed'),
                    ),
                  );
                }
                if (state is LoginPhoneCheckSuccess) {


                  if(isRegister){
                    if(state.status){
                      Scaffold.of(context).showSnackBar(
                        SnackBar(
                          content: Text('Number is already registered, Please Login.'),
                        ),
                      );
                    }else{
                      _firebaseAuthCubit.verifyPhone(mobile: _mobileNumber);
                    }
                  }else{
                    if(!state.status){
                      Scaffold.of(context).showSnackBar(
                        SnackBar(
                          content: Text('Number not registered, Please register.'),
                        ),
                      );
                    }else{
                      _firebaseAuthCubit.verifyPhone(mobile: _mobileNumber);
                    }
                  }

                }
              }),
          BlocListener(
            cubit: _firebaseAuthCubit,
            listener: (BuildContext context, state) {
              if (state is InvalidMobile) {
                Scaffold.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Please enter a valid mobile number',style: TextStyle(color: AppConfig.primaryColorDark),),
                    backgroundColor: AppConfig.white,
                  ),
                );
              }
              if (state is PhoneVerificationSuccess) {
                _loginCubit.saveUser(state.user);
              }

              if (state is OtpSent) {

                OtpData data = OtpData(isRegister: isRegister,mobile:_mobileNumber.toString(),token: state.verificationId);
                _mobileNumberController.clear();
                BlocProvider.of<AppNavigatorCubit>(context).routeToOtpVerification(data);
              }
            },
          ),
          BlocListener<AppNavigatorCubit, AppNavigatorState>(
            listener: (BuildContext context, state) {
              if (state is AppNavigatorLogin) {
                print(state.isRegister);
                Navigator.of(context).pushReplacementNamed(
                    state.route,arguments: state.isRegister
                );
              }
              if (state is AppNavigatorHome) {
                Navigator.of(context).pushNamedAndRemoveUntil(
                    state.route, (Route<dynamic> route) => false);
              }
              if (state is AppNavigatorOtpVerification) {
                Navigator.of(context)
                    .pushNamed(state.route, arguments: state.data);
              }
              if (state is AppNavigatorAskQuestion) {
                Navigator.of(context).pushNamedAndRemoveUntil(
                    state.route, ModalRoute.withName(Constants.HOME),
                    arguments: state.celebrity);
              }
              if (state is AppNavigatorMakeWishWhoFor) {
                Navigator.of(context).pushNamedAndRemoveUntil(
                    state.route, ModalRoute.withName(Constants.HOME),
                    arguments: state.celebrity);
              }
              if (state is AppNavigatorCreateProfile) {
                Navigator.of(context)
                    .pushNamedAndRemoveUntil(state.route,ModalRoute.withName(Constants.HOME));
              }
            },
          )
        ],
        child: SingleChildScrollView(
          child: Container(
            margin: EdgeInsets.symmetric(vertical: 35),
            child: Column(
              children: [
                Row(
                  children: [
                    IconButton(
                      onPressed: (){
                        if(Navigator.of(context).canPop()){
                          Navigator.of(context).pop();
                        }
                      },
                      icon: SvgPicture.asset('assets/images/arrow_left.svg',
                        color: AppConfig.white,
                        height: 17,
                        semanticsLabel: 'arrow_right',),
                    ),
                  ],
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 44),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        height: 10,
                      ),
                      Align(
                        alignment: Alignment.center,
                        child: Container(
                          padding: EdgeInsets.all(12),
                          child: Image.asset(
                            'assets/images/logo.png',
                            width: MediaQuery.of(context).size.width * 0.5,
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 80,
                      ),
                      Text(
                        isRegister ? "Sign Up" : "Log In",
                        style: GoogleFonts.montserrat(
                            color: AppConfig.titleFontColor,
                            fontSize: 22.0,
                            fontWeight: FontWeight.w500),
                      ),
                      SizedBox(
                        height: 60,
                      ),
                      Text(
                        'Enter Mobile No.',
                        style: TextStyle(
                          fontSize: 18,
                          color: AppConfig.white,
                          fontWeight: FontWeight.w100,
                        ),
                      ),
                      SizedBox(
                        height: 30,
                      ),
                      Container(
                        decoration: BoxDecoration(
                            border: Border(
                                bottom: BorderSide(
                          color: AppConfig.white,
                          width: 0.5,
                        ))),
                        child: InternationalPhoneNumberInput(
                          initialValue: PhoneNumber(isoCode: _mobileIsoCode),
                          onInputChanged: (input) {
                            _mobileNumber = input.toString().trim();
                            _mobileIsoCode = input.isoCode;
                          },
                          textFieldController: _mobileNumberController,
                          errorMessage: null,
                          selectorTextStyle: TextStyle(
                              fontSize: 18,
                              color: AppConfig.white,
                              backgroundColor: Colors.transparent,
                              fontWeight: FontWeight.w600),
                          selectorButtonOnErrorPadding: 0,
                          selectorConfig: SelectorConfig(
                              selectorType: PhoneInputSelectorType.BOTTOM_SHEET,
                          ),
                          textStyle: TextStyle(
                              fontSize: 18,
                              color: AppConfig.white,
                              fontWeight: FontWeight.w600),
                          inputDecoration: InputDecoration(
                            border: InputBorder.none,
                          ),
                        ),
                      ),
                      // Adobe XD layer: 'Button' (group)
                      SizedBox(
                        height: 60,
                      ),
                      BlocBuilder(
                          cubit: _firebaseAuthCubit,
                          builder: (context, state) {
                            bool buttonEnabled = true;
                            if (state is PhoneVerificationInProgress) {
                              buttonEnabled = false;
                            }
                            return RoundAppButton(
                              isBusy: !buttonEnabled,
                              onPressed: buttonEnabled
                                  ? () {
                                FocusScope.of(context).unfocus();
                                _loginCubit.checkPhoneNumber(_mobileNumber);
                                    }
                                  : null,
                              title: 'Generate OTP',
                              padding: 25,
                            );
                          }),
                      SizedBox(
                        height: 15.0,
                      ),
                      Center(
                          child: Text(
                              isRegister
                                  ? "Already signed up?"
                                  : "Haven’t signed up yet?",
                              style:
                                  TextStyle(color: AppConfig.white, fontSize: 16))),
                      SizedBox(
                        height: 5.0,
                      ),
                      Align(
                        alignment: Alignment.center,
                        child: GestureDetector(
                          onTap: () {
                            if (isRegister)
                              BlocProvider.of<AppNavigatorCubit>(context)
                                  .routeToLogin(false,true);
                            else
                              BlocProvider.of<AppNavigatorCubit>(context)
                                  .routeToLogin(true,true);
                          },
                          child: Text(
                            isRegister ? 'Log In' : 'Sign Up Now',
                            style: TextStyle(
                                color: AppConfig.labelBlueTextColor,
                                fontWeight: FontWeight.w500,
                                fontSize: 16),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
