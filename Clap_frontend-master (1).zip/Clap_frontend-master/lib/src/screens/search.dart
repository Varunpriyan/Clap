import 'package:cached_network_image/cached_network_image.dart';
import 'package:clap/src/blocs/app_navigator_cubit.dart';
import 'package:clap/src/blocs/category_cubit.dart';
import 'package:clap/src/blocs/search_cubit.dart';
import 'package:clap/src/utils/app_config.dart';
import 'package:clap/src/utils/constants.dart';
import 'package:clap/src/widgets/empty.dart';
import 'package:clap/src/widgets/horizontal_celebrity_list.dart';
import 'package:clap/src/widgets/loadng.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_fonts/google_fonts.dart';

class SearchScreen extends StatefulWidget {
  static const String routeName = Constants.SEARCH_ROUTE;
  final String query;

  SearchScreen({Key key, this.query}) : super(key: key);

  @override
  _SearchScreenState createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  SearchCubit _searchCubit;
  TextEditingController _textEditingControllerQuery;

  @override
  void initState() {
    _searchCubit = SearchCubit();
    _textEditingControllerQuery = TextEditingController();
    _textEditingControllerQuery.text = widget.query;
    _searchCubit.search(widget.query);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppConfig.scaffoldBackgroundColor,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(
                height: 15,
              ),
              Padding(
                padding: EdgeInsets.fromLTRB(10,10,30,10),
                child: Row(
                  children: [
                    GestureDetector(
                      behavior: HitTestBehavior.opaque,
                        onTap: () {
                          if (Navigator.of(context).canPop()) {
                            Navigator.of(context).pop();
                          }
                        },
                        child: SizedBox(
                          height: 17,
                          width: 17,
                          child: SvgPicture.asset(
                            'assets/images/arrow_left.svg',
                            color: AppConfig.white,
                            semanticsLabel: 'arrow_left',
                          ),
                        )),
                    SizedBox(width: 10,),
                    Expanded(
                      child: SizedBox(
                        height: 43,
                        child: TextField(
                          controller: _textEditingControllerQuery,
                          textInputAction: TextInputAction.search,
                          onSubmitted: (q) {
                            _searchCubit.search(q);
                          },
                          style: TextStyle(color: AppConfig.white),
                          decoration: InputDecoration(
                            contentPadding:
                                EdgeInsets.symmetric(vertical: 0, horizontal: 20),
                            prefixIcon: Icon(
                              CupertinoIcons.search,
                              color: AppConfig.lightFontColor,
                            ),
                            hintText: "search categories, celebrities, etc",
                            hintStyle: TextStyle(
                              color: AppConfig.lightFontColor,
                            ),
                            border: OutlineInputBorder(
                              borderSide: BorderSide(
                                  color: AppConfig.blueUnderlineColor, width: 0.3),
                              borderRadius: BorderRadius.circular(30.0),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide(
                                  color: AppConfig.blueUnderlineColor, width: 0.3),
                              borderRadius: BorderRadius.circular(30.0),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide: BorderSide(
                                  color: AppConfig.blueUnderlineColor, width: 0.3),
                              borderRadius: BorderRadius.circular(30.0),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 30, vertical: 10),
                child: BlocBuilder(
                  cubit: _searchCubit,
                  buildWhen: (previous, current) =>
                      current is SearchInitial ||
                      current is SearchLoading ||
                      current is SearchLoadSuccess ||
                      current is SearchLoadError ||
                      current is SearchLoadEmpty,
                  builder: (context, state) {
                    if (state is SearchLoading) {
                      return LoaderAnimation();
                    }
                    if (state is SearchLoadSuccess) {
                      print(state.searchResponse.categories.length);
                      return Column(
                        children: [
                          Align(
                            alignment: Alignment.centerLeft,
                            child: Text(
                              'Search Results',
                              style: TextStyle(
                                fontSize: 22,
                                color:AppConfig.titleFontColor,
                                fontWeight: FontWeight.w600,
                              ),
                              textAlign: TextAlign.left,
                            ),
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          ListView.builder(
                              itemCount: state.searchResponse.categories.length,
                              shrinkWrap: true,
                              physics: NeverScrollableScrollPhysics(),
                              itemBuilder: (context, index) {
                                return ListTile(
                                  leading: SizedBox(
                                    height: 60,
                                      width: 50,
                                  ),
                                  title: Text(
                                      '${state.searchResponse.categories[index].name}',style: TextStyle(color: AppConfig.white),),
                                  subtitle: Text("Category",style: TextStyle(color: AppConfig.white),),
                                  onTap: (){
                                    BlocProvider.of<AppNavigatorCubit>(context)
                                        .routeToCelebrityListByCategory(state.searchResponse.categories[index]);
                                  },
                                  trailing: SvgPicture.asset('assets/images/arrow_right.svg',
                                    color: AppConfig.white,
                                    height: 15,
                                    semanticsLabel: 'done',),
                                );
                              }),
                          ListView.builder(
                              itemCount:
                                  state.searchResponse.celebrities.length,
                              shrinkWrap: true,
                              physics: NeverScrollableScrollPhysics(),
                              itemBuilder: (context, index) {
                                return ListTile(
                                  leading: CachedNetworkImage(
                                    imageUrl: state.searchResponse.celebrities[index].image,
                                    height: 60,
                                    width: 50,
                                    fit: BoxFit.cover,
                                  ),
                                  title: Text(
                                      '${state.searchResponse.celebrities[index].name}',style: TextStyle(color: AppConfig.white),),
                                  subtitle: Text(
                                      "${state.searchResponse.celebrities[index].profession}",style: TextStyle(color: AppConfig.white),),
                                  onTap: (){
                                    BlocProvider.of<AppNavigatorCubit>(context)
                                        .routeToCelebrityDetail(state.searchResponse.celebrities[index]);
                                  },
                                  trailing: SvgPicture.asset('assets/images/arrow_right.svg',
                                    color: AppConfig.white,
                                    height: 15,
                                    semanticsLabel: 'done',),
                                );
                              })
                        ],
                      );
                    }
                    return EmptyWidget(heading: "No results found");
                  },
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
