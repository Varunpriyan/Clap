import 'package:clap/src/models/profile_response.dart';
import 'package:clap/src/utils/app_config.dart';
import 'package:clap/src/utils/constants.dart';
import 'package:clap/src/widgets/app_rounded_input_field_with_title.dart';
import 'package:clap/src/widgets/custom_appbar.dart';
import 'package:clap/src/widgets/loadng.dart';
import 'package:clap/src/widgets/round_app_button.dart';
import 'package:clap/src/widgets/select_formfield.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:clap/src/blocs/profile_cubit.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:toast/toast.dart';
class ProfileEditScreen extends StatefulWidget {
  static const String routeName = Constants.PROFILE_EDIT;
  final Profile profile;

  const ProfileEditScreen({Key key, this.profile}) : super(key: key);
  @override
  _ProfileEditScreenState createState() => _ProfileEditScreenState();
}

class _ProfileEditScreenState extends State<ProfileEditScreen> {

  ProfileCubit _profileCubit;

  Profile profile;

  TextEditingController _textEditingControllerFullName;
  TextEditingController _textEditingControllerMobile;
  TextEditingController _textEditingControllerEmail;
  TextEditingController _textEditingControllerAbout;
  TextEditingController _textEditingControllerAge;
  TextEditingController _textEditingControllerHeight;
  TextEditingController _textEditingControllerWeight;
  TextEditingController _textEditingControllerComplexion;
  TextEditingController _textEditingControllerHairColor;

  String _selectedGender;
  String _selectedLocation;

  @override
  void initState() {
    _profileCubit =  BlocProvider.of<ProfileCubit>(context);
    _textEditingControllerFullName = TextEditingController();
    _textEditingControllerMobile = TextEditingController();
    _textEditingControllerEmail = TextEditingController();
    _textEditingControllerAbout = TextEditingController();
    _textEditingControllerAge = TextEditingController();
    _textEditingControllerHeight = TextEditingController();
    _textEditingControllerWeight = TextEditingController();
    _textEditingControllerComplexion = TextEditingController();
    _textEditingControllerHairColor = TextEditingController();

    if(widget.profile!=null){
      profile = widget.profile;
      _textEditingControllerFullName.text = widget.profile.displayName;
      _textEditingControllerMobile.text = widget.profile.phoneNumber;
      _textEditingControllerEmail.text = widget.profile.email;
      _textEditingControllerAbout.text = widget.profile.aboutMe;
      _textEditingControllerAge.text = widget.profile.age==0 ? '' :  widget.profile.age.toString();
      _textEditingControllerHeight.text = widget.profile.height=="0.00" ? '' :  widget.profile.height;
      _textEditingControllerWeight.text = widget.profile.weight=="0.00" ? '' :  widget.profile.weight;
      _selectedLocation = widget.profile.location;
      _textEditingControllerHairColor.text = widget.profile.hairColour;
      _selectedGender = widget.profile.gender;
    }else{

      if(!(_profileCubit.state is ProfileLoadSuccess)){
        print('here');
        _profileCubit.getProfile();
      }
    }

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppConfig.buttonSubtitleTextColor,
      body: SafeArea(
        child: MultiBlocListener(
          listeners: [
            BlocListener(
              cubit: _profileCubit,
              listener: (BuildContext context, state) {
                if (state is ProfileValidationError) {
                  String message = 'Please fill all fields to update your profile';
                  /*switch (state.field) {
                    case 1:
                      message = 'Invalid Name';
                      break;
                    case 2:
                      message = 'Invalid Email';
                      break;
                    case 3:
                      message = 'Invalid Age';
                      break;
                    case 4:
                      message = 'Invalid Gender';
                      break;
                    case 5:
                      message = 'Invalid Height';
                      break;
                    case 6:
                      message = 'Invalid Weight';
                      break;
                    case 7:
                      message = 'Invalid Complexion';
                      break;
                    case 8:
                      message = 'Invalid Hair color';
                      break;
                    case 9:
                      message = 'Invalid About me';
                      break;
                  }*/
                  Scaffold.of(context).showSnackBar(
                    SnackBar(
                      content: Text(message,style: TextStyle(color: AppConfig.primaryColorDark),),
                      backgroundColor: AppConfig.white,
                    ),
                  );
                }
                if (state is ProfileSuccess) {
                  Toast.show("Profile updated successfully.", context, duration: Toast.LENGTH_LONG, gravity:  Toast.BOTTOM);
                  _profileCubit.getProfile(showLoader: true);
                  Navigator.of(context).pop();
                }
                if (state is ProfileError) {
                  Scaffold.of(context).showSnackBar(
                    SnackBar(
                      content: Text(state.msg,style: TextStyle(color: AppConfig.primaryColorDark),),
                      backgroundColor: AppConfig.white,
                    ),
                  );
                }
              },
            ),
          ],
          child: SingleChildScrollView(
              child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 20),
            child: BlocBuilder(
              cubit: _profileCubit,
              builder: (context, state) {
                if(state is ProfileLoadSuccess){
                  if(state.profile!=null && profile==null){
                    profile = state.profile;
                    _textEditingControllerFullName.text = state.profile.displayName;
                    _textEditingControllerMobile.text = state.profile.phoneNumber;
                    _textEditingControllerEmail.text = state.profile.email;
                    _textEditingControllerAbout.text = state.profile.aboutMe;
                    _textEditingControllerAge.text = state.profile.age==0 ? '' :  state.profile.age.toString();
                    _textEditingControllerHeight.text = state.profile.height=="0.00" ? '' :  state.profile.height;
                    _textEditingControllerWeight.text = state.profile.weight=="0.00" ? '' :  state.profile.weight;
                    _selectedLocation= state.profile.location;
                    _textEditingControllerHairColor.text = state.profile.hairColour;
                    _selectedGender = state.profile.gender;
                  }

                }
                if(profile!=null){
                  return Column(
                    children: [
                      CustomAppBar(
                        title: 'Update Profile',
                        color: AppConfig.titleBlueFontColor,
                        isClose: true,
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 30,),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [

                            SizedBox(
                              height: 35,
                            ),
                            Text(
                              'Personal Details',
                              style: GoogleFonts.montserrat(
                                  fontSize: 18,
                                  color: AppConfig.titleBlueFontColor,
                                  fontWeight: FontWeight.w600,
                                  fontStyle: FontStyle.normal),
                            ),
                            AppRoundedInputFieldWithTitle(title: 'Full Name*',controller: _textEditingControllerFullName,keyboardType: TextInputType.text,),
                            AppRoundedInputFieldWithTitle(title: 'Registered Mobile',controller: _textEditingControllerMobile,keyboardType: TextInputType.text,readOnly: true,),
                            AppRoundedInputFieldWithTitle(title: 'Email ID*',controller: _textEditingControllerEmail,keyboardType: TextInputType.text,),
                            SizedBox(
                              height: 25,
                            ),
                            Text(
                              'Audition Application Details',
                              style: GoogleFonts.montserrat(
                                  fontSize: 18,
                                  color: AppConfig.titleBlueFontColor,
                                  fontWeight: FontWeight.w600,
                                  fontStyle: FontStyle.normal),
                            ),
                            Row(
                              children: [
                                Expanded(child: AppRoundedInputFieldWithTitle(title: 'Age',controller: _textEditingControllerAge,keyboardType: TextInputType.number,)),
                                SizedBox(width: 20,),
                                Expanded(child: SelectFormField(
                                  contentPadding: EdgeInsets.symmetric(horizontal: 20,vertical: 0),
                                  hintText: '',
                                  titleText: "Gender",
                                  value: _selectedGender,
                                  onSaved: (value) {
                                    setState(() {
                                      _selectedGender = value;
                                    });
                                  },
                                  onChanged: (value) {
                                    setState(() {
                                      _selectedGender = value;
                                    });
                                  },
                                  dataSource: _genderSource(),
                                  textField: 'display',
                                  valueField: 'value',
                                ),),
                              ],
                            ),
                            Row(
                              children: [
                                Expanded(child: AppRoundedInputFieldWithTitle(title: 'Height',controller: _textEditingControllerHeight,keyboardType: TextInputType.number,suffixText: "cm",)),
                                SizedBox(width: 20,),
                                Expanded(child: AppRoundedInputFieldWithTitle(title: 'Weight',controller: _textEditingControllerWeight,keyboardType: TextInputType.number,suffixText: "kg",)),
                              ],
                            ),
                            Row(
                              children: [
                                /*Expanded(child: AppRoundedInputFieldWithTitle(title: 'Complexion',controller: _textEditingControllerComplexion,keyboardType: TextInputType.text,)),
                                SizedBox(width: 20,),*/
                                Expanded(child: AppRoundedInputFieldWithTitle(title: 'Hair Colour',controller: _textEditingControllerHairColor,keyboardType: TextInputType.text,)),
                              ],
                            ),
                            Row(
                              children: [
                                Expanded(child: SelectFormField(
                                  contentPadding: EdgeInsets.symmetric(horizontal: 20,vertical: 0),
                                  hintText: 'Your location',
                                  titleText: "Location",
                                  value: _selectedLocation,
                                  onSaved: (value) {
                                    setState(() {
                                      _selectedLocation = value;
                                    });
                                  },
                                  onChanged: (value) {
                                    setState(() {
                                      _selectedLocation = value;
                                    });
                                  },
                                  dataSource: _locationSource(),
                                  textField: 'display',
                                  valueField: 'value',
                                ),),
                              ],
                            ),
                            SizedBox(height: 20,),

                            Text(
                              'About Me',
                              style: TextStyle(fontSize: 15, color: AppConfig.textFieldTitleColor,fontWeight: FontWeight.normal),
                            ),
                            SizedBox(height: 6,),
                            TextField(
                              controller: _textEditingControllerAbout,
                              style: TextStyle(color:  Colors.black87),
                              minLines: 6,
                              maxLines: 10,
                              maxLength: 200,
                              onChanged: (s){
                                // workaround to fix the flutter bug
                                if(_textEditingControllerAbout.text.length>200){
                                  _textEditingControllerAbout.text =  _textEditingControllerAbout.text.substring(0,200);
                                  FocusScope.of(context).unfocus();
                                }
                                setState(() {

                                });
                              },
                              inputFormatters: [
                                new LengthLimitingTextInputFormatter(200),// for mobile
                              ],
                              decoration: new InputDecoration(
                                filled: true,
                                fillColor: Colors.white,
                                counterText: '${_textEditingControllerAbout.text.length.toString()}/200',
                                counterStyle: TextStyle(color: AppConfig.hintTextColor),
                                focusedBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                      color: AppConfig.blueUnderlineColor, width: 1),
                                  borderRadius: const BorderRadius.all(
                                    const Radius.circular(15.0),
                                  ),
                                ),
                                enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                      color: AppConfig.white, width: 1),
                                  borderRadius: const BorderRadius.all(
                                    const Radius.circular(15.0),
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(height: 30,),
                            BlocBuilder(
                                cubit: _profileCubit,
                                builder: (context, state) {
                                  bool buttonEnabled = true;
                                  if (state is ProfileBusy) {
                                    buttonEnabled = false;
                                  }
                                  return RoundAppButton(
                                    isBusy: !buttonEnabled,
                                    onPressed: buttonEnabled
                                        ? () {
                                      _profileCubit.updateProfile(
                                          email: _textEditingControllerEmail.text.trim(),
                                          name: _textEditingControllerFullName.text.trim(),
                                          age: _textEditingControllerAge.text.isNotEmpty ? int.parse(_textEditingControllerAge.text.trim()) : null,
                                          gender: _selectedGender,
                                          height: _textEditingControllerHeight.text.trim(),
                                          weight: _textEditingControllerWeight.text.trim(),
                                          complexion: _selectedLocation,
                                          hairColor: _textEditingControllerHairColor.text.trim(),
                                          aboutMe: _textEditingControllerAbout.text.trim()
                                      );
                                    }
                                        : null,
                                    title: "Update",padding: MediaQuery.of(context).size.width*0.15,
                                  );
                                }
                            )
                          ],
                        ),
                      ),
                    ],
                  );
                }
                return LoaderAnimation();
              },
            ),
          )),
        ),
      ),
    );
  }

  _genderSource(){
    return [
    {
      "display": "Female",
    "value": "Female",
    },
    {
    "display": "Male",
    "value": "Male",
    },
    {
    "display": "Other",
    "value": "Other",
    },
  ];
  }


  _locationSource(){
    return [
      {
        "display": "Alappuzha",
        "value": "Alappuzha",
      },
      {
        "display": "Ernakulam",
        "value": "Ernakulam",
      },
      {
        "display": "Idukki",
        "value": "Idukki",
      },
      {
        "display": "Kannur",
        "value": "Kannur",
      },
      {
        "display": "Kasaragod",
        "value": "Kasaragod",
      },
      {
        "display": "Kollam",
        "value": "Kollam",
      },{
        "display": "Kottayam",
        "value": "Kottayam",
      },
      {
        "display": "Kozhikode",
        "value": "Kozhikode",
      },
      {
        "display": "Malappuram",
        "value": "Malappuram",
      },
      {
        "display": "Palakkad",
        "value": "Palakkad",
      },
      {
        "display": "Pathanamthitta",
        "value": "Pathanamthitta",
      },{
        "display": "Thiruvananthapuram",
        "value": "Thiruvananthapuram",
      },
      {
        "display": "Thrissur",
        "value": "Thrissur",
      },{
        "display": "Wayanad",
        "value": "Wayanad",
      }
    ];
  }
}
