import 'dart:io';

import 'package:clap/src/blocs/app_navigator_cubit.dart';
import 'package:clap/src/blocs/celebrity_cubit.dart';
import 'package:clap/src/blocs/user_cubit.dart';
import 'package:clap/src/models/models.dart';
import 'package:clap/src/utils/app_config.dart';
import 'package:clap/src/widgets/round_app_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';

class LoginLaterScreen extends StatefulWidget {
  @override
  _LoginLaterScreenState createState() => _LoginLaterScreenState();
}

class _LoginLaterScreenState extends State<LoginLaterScreen>
    with SingleTickerProviderStateMixin {
  UserCubit _userCubit;
  ActionState actionState;
  CelebrityCubit _celebrityCubit;

  @override
  void initState() {
    super.initState();
    _userCubit = UserCubit();
    _celebrityCubit = CelebrityCubit();
  }

  @override
  Widget build(BuildContext context) {
    actionState = ModalRoute.of(context).settings.arguments;
    return BlocListener(
      cubit: _celebrityCubit,
      listener: (BuildContext context, state) {
        if(state is CelebrityActionStateSaved){
          bool isRegister = false;
          if(state.authType=="register") isRegister = true;
          print(isRegister);
          BlocProvider.of<AppNavigatorCubit>(context)
              .routeToLogin(isRegister, true);
        }
      },
      child: Scaffold(
        backgroundColor: AppConfig.scaffoldBackgroundColor,
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                Row(
                  children: [
                    actionState!=null ? GestureDetector(onTap: (){
                      if(Navigator.of(context).canPop()){
                        Navigator.of(context).pop();
                      }
                    },child: Padding(
                      padding: const EdgeInsets.only(right: 15),
                      child: SvgPicture.asset('assets/images/arrow_left.svg',
                        color: AppConfig.white,
                        height: 17,
                        semanticsLabel: 'arrow_right',),
                    )) : Container(),
                  ],
                ),
                SizedBox(
                  height: MediaQuery.of(context).size.height*0.8,
                  child: Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(
                            'Login/Register to continue',
                            style: TextStyle(
                              fontSize: 24,
                              color: AppConfig.titleFontColor,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                        SizedBox(height: 100,),
                        Row(
                          children: [
                            Flexible(
                              child: RoundAppButton(
                                  title: "Login",
                                  onPressed: () {
                                    if(actionState!=null)
                                     _celebrityCubit.saveCelebrityActionState(celebrity: actionState.celebrity,actionType: actionState.actionType,authType: "login");
                                    else
                                     BlocProvider.of<AppNavigatorCubit>(context)
                                        .routeToLogin(false, true);
                                  }),
                            ),
                            Flexible(
                              child: RoundAppButton(
                                  title: "Sign Up",
                                  onPressed: () {
                                    if(actionState!=null)
                                      _celebrityCubit.saveCelebrityActionState(celebrity: actionState.celebrity,actionType: actionState.actionType,authType: "register");
                                    else
                                     BlocProvider.of<AppNavigatorCubit>(context)
                                        .routeToLogin(true, true);
                                  }),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        //backgroundColor: Colors.transparent,
      ),
    );
  }
}
