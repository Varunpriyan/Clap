import 'package:clap/src/blocs/profile_cubit.dart';
import 'package:clap/src/models/analytics_response.dart';
import 'package:clap/src/widgets/empty.dart';
import 'package:clap/src/widgets/loadng.dart';
import 'package:flutter/material.dart';
import 'package:clap/src/utils/app_config.dart';
import 'package:clap/src/widgets/view_count_widget.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:clap/src/blocs/app_navigator_cubit.dart';
class AuditionAnalyticsScreen extends StatefulWidget {
  @override
  _AuditionAnalyticsScreenState createState() => _AuditionAnalyticsScreenState();
}

class _AuditionAnalyticsScreenState extends State<AuditionAnalyticsScreen> {
  ProfileCubit _profileCubit;
  AnalyticsResponse analytics;

  @override
  void initState() {
    _profileCubit = BlocProvider.of<ProfileCubit>(context);
    _profileCubit.getAnalytics();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 35,vertical: 20),
      child: BlocBuilder(
        cubit: _profileCubit,
        buildWhen: (previous, current) =>  current is ProfileAnalyticsLoading || current is ProfileAnalyticsLoadError || current is ProfileAnalyticsLoadSuccess || current is ProfileInitial,
        builder: (context, state) {
          if (state is ProfileAnalyticsLoading || state is ProfileInitial) {
            return CircularProgressIndicator();
          }
          if (state is ProfileAnalyticsLoadError) {
            return Center(
              child: EmptyWidget(
                heading: 'Nothing yet!',
              ),
            );
          }
          if (state is ProfileAnalyticsLoadSuccess) {
            analytics = state.analytics;
          }
          if(analytics!=null){
            print('building');
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                InkWell(
                  onTap: () {
                    BlocProvider.of<AppNavigatorCubit>(context).routeToAuditionStatus();
                  },
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 15),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Check Applied Audition Status',
                          style: TextStyle(fontSize: 14, color: AppConfig.white),
                        ),
                        Icon(
                          Icons.arrow_forward_ios_rounded,
                          color: AppConfig.white,
                          size: 10,
                        )
                      ],
                    ),
                  ),
                ),
                ExpansionTile(
                  tilePadding: EdgeInsets.zero,
                  expandedCrossAxisAlignment: CrossAxisAlignment.start,
                  expandedAlignment: Alignment.centerLeft,
                  title: Text(
                    'Profile View Count',
                    style: TextStyle(fontSize: 14, color: AppConfig.white),
                  ),
                  trailing: Icon(
                    Icons.arrow_forward_ios_rounded,
                    color: AppConfig.white,
                    size: 10,
                  ),
                  children: [
                    Text(
                      '${analytics.profileViewCount} Views',
                      style: TextStyle(fontSize: 14, color: AppConfig.grey,fontWeight: FontWeight.w400),
                      textAlign: TextAlign.left,
                    ),
                  ],
                ),
                analytics.viewedUsers.length>0 ? ExpansionTile(
                  tilePadding: EdgeInsets.zero,
                  expandedCrossAxisAlignment: CrossAxisAlignment.start,
                  expandedAlignment: Alignment.centerLeft,
                  title: Text(
                    'Profile Viewed By',
                    style: TextStyle(fontSize: 14, color: AppConfig.white),
                  ),
                  trailing: Icon(
                    Icons.arrow_forward_ios_rounded,
                    color: AppConfig.white,
                    size: 10,
                  ),
                  children: [
                    ListView.separated(
                      shrinkWrap: true,
                      physics: NeverScrollableScrollPhysics(),
                      itemCount: analytics.viewedUsers.length,
                      separatorBuilder: (context, index) {
                        return Divider(
                          color: Colors.white,
                          thickness: 0.15,
                        );
                      },
                      itemBuilder: (context, index) {
                        return ViewCount(name: '${analytics.viewedUsers[index].user}',count: '${analytics.viewedUsers[index].count}',);
                      },),
                  ],
                ) : Container(),
              ],
            );
          }
          return Container();
        },
      ),
    );
  }
}
