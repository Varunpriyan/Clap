import 'package:intl/intl.dart';

class AppFormatter {
  static String dateToString(DateTime dateTime) {
    final DateFormat formatter = DateFormat('dd-MM-yyyy');
    final String formatted = formatter.format(dateTime);
    return formatted;
  } static dateToDateMonthTimeString(DateTime dateTime) {
    final DateFormat formatter = DateFormat('EEE, dd MMM hh:mm a');
    final String formatted = formatter.format(dateTime);
    return formatted;
  }
  static dateToDateMonthString(DateTime dateTime) {
    final DateFormat formatter = DateFormat('EEE, dd MMM');
    final String formatted = formatter.format(dateTime);
    return formatted;
  }
  static String dateToTimeString(DateTime deliveryDate) {
    final DateFormat formatter =
    DateFormat().add_jm();
    final String formatted = formatter.format(deliveryDate);
    return formatted;
  }

  static DateTime stringToDate(String deliveryDate) {
    final DateFormat formatter = DateFormat('dd-MM-yyyy');
    DateTime dateTime = formatter.parse(deliveryDate);
    return dateTime;
  }

  static DateTime timestampToDateTime(int timestamp) {
    var date = new DateTime.fromMillisecondsSinceEpoch(timestamp * 1000);
    return date;
  }


}
