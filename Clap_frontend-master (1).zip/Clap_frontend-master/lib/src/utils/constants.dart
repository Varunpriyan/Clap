class Constants {

  ///API constants
  static const String SERVER = 'http://api.getclap.in/api/';

  //////////////////////APIs//////////////////////////////////

  ///[USER] POST method
  static const String USER = SERVER + 'users/me/';
  ///[CHECK_PHONE] POST method
  static const String CHECK_PHONE = SERVER + 'check-phonenumber/';

  ///[UPDATE_PROFILE] POST method
  static const String UPDATE_PROFILE = SERVER + 'users/me/';
  ///[CATEGORIES] POST method
  static const String CATEGORIES = SERVER + 'celebrity_categories/';
  ///[CATEGORIES] POST method
  static const String CELEBRITIES = SERVER + 'celebrities/';
  ///[ASK_QUESTION] POST method
  static const String ASK_QUESTION = SERVER + 'ask_a_questions/';
  ///[MAKE_WISH] POST method
  static const String MAKE_WISH = SERVER + 'make_a_wish/';
  ///[UPDATE_PAYMENT] POST method
  static const String UPDATE_PAYMENT = SERVER + 'payments/';
  ///[ORDERS] POST method
  static const String ORDERS = SERVER + 'order_status/';
  ///[OCCASIONS] POST method
  static const String OCCASIONS = SERVER + 'occasions/';
  ///[SEARCH] POST method
  static const String SEARCH = SERVER + 'search/';
  ///[ADD_PORTFOLIO] POST method
  static const String ADD_PORTFOLIO = SERVER + 'myportfolio/';
  ///[DELETE_PORTFOLIO] POST method
  static const String DELETE_PORTFOLIO = SERVER + 'myportfolio/';

  ///[API_AUDITIONS] POST method
  static const String API_AUDITIONS = SERVER + 'auditions/';
  ///[APPLY_AUDITION] POST method
  static const String APPLY_AUDITION = SERVER + 'applyauditions/';
  ///[ANALYTICS] POST method
  static const String ANALYTICS = SERVER + 'analytics/';
  ///[PROFILE_DELETE] POST method
  static const String PROFILE_DELETE = SERVER + 'account_delete/';


  /// All the routing constants used within the app
  static const String SPLASH_ROUTE = '/';
  static const String LOGIN = '/login';
  static const String INTRO = '/intro';
  static const String OTP_VERIFICATION_ROUTE = '/otp_verification';
  static const String TERMS_CONDITIONS_ROUTE = '/terms_conditions';
  static const String CONTACT_ROUTE = '/contact';
  static const String HOME = '/home';
  static const String CREATE_PROFILE = '/create_profile';
  static const String CELEBRITY_LIST_BY_CATEGORY = '/celebrity_list_category';
  static const String CELEBRITY_DETAIL_ROUTE = '/celebrity_detail';
  static const String CELEBRITY_ASK_QUESTION = '/celebrity_ask_question';
  static const String CELEBRITY_ASK_QUESTION_CONFIRM = '/celebrity_ask_question_confirm';
  static const String CELEBRITY_MAKE_WISH_WHO_FOR = '/celebrity_make_wish_who_for';
  static const String CELEBRITY_MAKE_WISH_INPUT_DETAILS = '/celebrity_make_wish_input_details';
  static const String CELEBRITY_MAKE_WISH_OCCASION = '/celebrity_make_wish_occasion';
  static const String CELEBRITY_MAKE_WISH_CONFIRM = '/celebrity_make_wish_confirm';
  static const String PAYMENT_STATUS = '/payment_status';
  static const String ORDER_DETAIL = '/order_detail';
  static const String ORDERS_ROUTE = '/orders';
  static const String SEARCH_ROUTE = '/search';
  static const String LATER_AUTH = '/later_auth';
  static const String PROFILE_EDIT = '/profile_edit';
  static const String AUDITIONS = '/auditions';
  static const String AUDITION_STATUS = '/audition_status';
  static const String AUDITION_DETAIL = '/audition_detail';
  static const String GALLERY_ROUTE = '/gallery';
}
