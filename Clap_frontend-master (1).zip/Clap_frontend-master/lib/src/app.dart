
import 'package:clap/src/models/categories_response.dart';
import 'package:clap/src/models/celebrity.dart';
import 'package:clap/src/models/models.dart';
import 'package:clap/src/models/profile_response.dart';
import 'package:clap/src/screens/ask_question.dart';
import 'package:clap/src/screens/ask_question_confirm.dart';
import 'package:clap/src/screens/audition_detail.dart';
import 'package:clap/src/screens/audition_status.dart';
import 'package:clap/src/screens/auditions.dart';
import 'package:clap/src/screens/celebrity_detail.dart';
import 'package:clap/src/screens/celebrity_list_by_category.dart';
import 'package:clap/src/screens/contact.dart';
import 'package:clap/src/screens/create_profile.dart';
import 'package:clap/src/screens/home.dart';
import 'package:clap/src/screens/intro.dart';
import 'package:clap/src/screens/login.dart';
import 'package:clap/src/screens/loginLater.dart';
import 'package:clap/src/screens/make_wish_confirm.dart';
import 'package:clap/src/screens/make_wish_input_details.dart';
import 'package:clap/src/screens/make_wish_occasion.dart';
import 'package:clap/src/screens/make_wish_who_for.dart';
import 'package:clap/src/screens/order_detail.dart';
import 'package:clap/src/screens/orders.dart';
import 'package:clap/src/screens/otp.dart';
import 'package:clap/src/screens/payment_status.dart';
import 'package:clap/src/screens/profile_edit.dart';
import 'package:clap/src/screens/search.dart';
import 'package:clap/src/screens/splash.dart';
import 'package:clap/src/utils/app_config.dart';
import 'package:clap/src/utils/constants.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';

import 'blocs/app_alert_cubit.dart';
import 'blocs/app_navigator_cubit.dart';
import 'blocs/profile_cubit.dart';


class App extends StatelessWidget {
  final AppNavigatorCubit _appNavigatorCubit = AppNavigatorCubit();
  final AppAlertCubit _appAlertCubit = AppAlertCubit();
  final ProfileCubit _profileCubit = ProfileCubit();
  @override
  Widget build(BuildContext context) {
    /*SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
      *//* statusBarColor: AppConfig.primaryColorDark,*//*
        statusBarIconBrightness: Brightness.light));*/

    return MultiBlocProvider(
      providers: [
        BlocProvider(
          create: (BuildContext context) => _appNavigatorCubit,
        ),
        BlocProvider(
          create: (context) => _appAlertCubit,
        ),
        BlocProvider(
          create: (context) => _profileCubit,
        ),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        builder: (context, child) {
          return MediaQuery(
            data: MediaQuery.of(context).copyWith(textScaleFactor: 1),
            child: child,
          );
        },
        title: 'Clap',
        theme: ThemeData(
          scaffoldBackgroundColor: AppConfig.scaffoldBackgroundColor,
            visualDensity: VisualDensity.adaptivePlatformDensity,
            cursorColor: AppConfig.primaryColor,
            canvasColor: AppConfig.primaryColor,
            inputDecorationTheme: InputDecorationTheme(
              border: InputBorder.none,
            ),
          textTheme: GoogleFonts.interTextTheme(
            Theme.of(context).textTheme,
          ), // Decoration theme for TextFormField
        ),
        routes: {
          Constants.SPLASH_ROUTE: (context) => SplashScreen(),
          Constants.CONTACT_ROUTE: (context) => ContactScreen(),
          Constants.LOGIN: (context) => LoginScreen(),
         // Constants.HOME: (context) => HomeScreen(),
          Constants.INTRO: (context) => IntroScreen(),
          Constants.OTP_VERIFICATION_ROUTE: (context) => OtpScreen(),
          Constants.CREATE_PROFILE: (context) => CreateProfileScreen(),
         // Constants.CELEBRITY_LIST_BY_CATEGORY: (context) => CelebrityListByCategoryScreen(),
          //Constants.CELEBRITY_DETAIL_ROUTE: (context) => CelebrityDetailScreen(),
          Constants.CELEBRITY_ASK_QUESTION: (context) => AskQuestionScreen(),
          Constants.CELEBRITY_ASK_QUESTION_CONFIRM: (context) => AskQuestionConfirmScreen(),
          Constants.CELEBRITY_MAKE_WISH_WHO_FOR: (context) => MakeWishWhoForScreen(),
         // Constants.CELEBRITY_MAKE_WISH_INPUT_DETAILS: (context) => MakeWishInputDetailsScreen(),
          //Constants.CELEBRITY_MAKE_WISH_OCCASION: (context) => MakeWishInputOccasionScreen(),
          Constants.CELEBRITY_MAKE_WISH_CONFIRM: (context) => MakeWishConfirmScreen(),
          Constants.PAYMENT_STATUS: (context) => PaymentStatusScreen(),
          //Constants.ORDER_DETAIL: (context) => OrderDetailScreen(),
          Constants.ORDERS_ROUTE: (context) => OrdersScreen(),
          Constants.LATER_AUTH: (context) => LoginLaterScreen(),
          //Constants.PROFILE_EDIT: (context) => ProfileEditScreen(),
          Constants.AUDITIONS: (context) => AuditionsScreen(),
          Constants.AUDITION_STATUS: (context) => AuditionStatusScreen(),
          //Constants.AUDITION_DETAIL: (context) => AuditionDetailScreen(),
        },
        initialRoute: Constants.SPLASH_ROUTE,
          onGenerateRoute: (settings) {
            if (settings.name == HomeScreen.routeName) {
              final bool args = settings.arguments;
              return MaterialPageRoute(
                builder: (context) {
                  return HomeScreen(showComplete: args ?? false,);
                },
              );
            }

            if (settings.name == CelebrityListByCategoryScreen.routeName) {
              final Category args = settings.arguments;
              return MaterialPageRoute(
                builder: (context) {
                  return CelebrityListByCategoryScreen(category: args,);
                },
              );
            }
            if (settings.name == CelebrityDetailScreen.routeName) {
              final Celebrity args = settings.arguments;
              return MaterialPageRoute(
                builder: (context) {
                  return CelebrityDetailScreen(celebrity: args,);
                },
              );
            }
            if (settings.name == MakeWishInputDetailsScreen.routeName) {
              final MakeWish args = settings.arguments;
              return MaterialPageRoute(
                builder: (context) {
                  return MakeWishInputDetailsScreen(makeWish: args,);
                },
              );
            }
            if (settings.name == MakeWishInputOccasionScreen.routeName) {
              final MakeWish args = settings.arguments;
              return MaterialPageRoute(
                builder: (context) {
                  return MakeWishInputOccasionScreen(makeWish: args,);
                },
              );
            }
            if (settings.name == OrderDetailScreen.routeName) {
              final int args = settings.arguments;
              return MaterialPageRoute(
                builder: (context) {
                  return OrderDetailScreen(order: args,);
                },
              );
            }
            if (settings.name == SearchScreen.routeName) {
              final String args = settings.arguments;
              return MaterialPageRoute(
                builder: (context) {
                  return SearchScreen(query: args,);
                },
              );
            }
            // phase 2
            if (settings.name == ProfileEditScreen.routeName) {
              final Profile args = settings.arguments;
              return MaterialPageRoute(
                builder: (context) {
                  return ProfileEditScreen(profile: args,);
                },
              );
            }
            if (settings.name == AuditionDetailScreen.routeName) {
              final int args = settings.arguments;
              return MaterialPageRoute(
                builder: (context) {
                  return AuditionDetailScreen(audition: args,);
                },
              );
            }
            assert(false, 'Need to implement ${settings.name}');
            return null;
          }
      ),
    );
  }
}
